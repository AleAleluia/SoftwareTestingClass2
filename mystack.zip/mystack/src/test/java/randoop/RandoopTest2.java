package randoop;

import junit.framework.*;

public class RandoopTest2 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test1");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    boolean var4 = var1.empty();
    br.ufal.ic.test.mystack.Stack var6 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var7 = new java.lang.Object();
    java.lang.Object var8 = var6.push(var7);
    java.lang.Object var9 = var1.push(var7);
    java.lang.Object var10 = var1.peek();
    boolean var11 = var1.empty();
    java.lang.Object var13 = var1.push((java.lang.Object)0);
    java.lang.Object var14 = var1.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 0+ "'", var13.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test2() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test2");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var3 = var1.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var5 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var6 = new java.lang.Object();
    java.lang.Object var7 = var5.push(var6);
    java.lang.Object var8 = var5.peek();
    boolean var9 = var5.empty();
    java.lang.Object var10 = var5.peek();
    java.lang.Object var11 = var1.push(var10);
    java.lang.Object var12 = var1.peek();
    br.ufal.ic.test.mystack.Stack var14 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var15 = new java.lang.Object();
    java.lang.Object var16 = var14.push(var15);
    java.lang.Object var17 = var14.peek();
    java.lang.Object var19 = var14.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var21 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var22 = new java.lang.Object();
    java.lang.Object var23 = var21.push(var22);
    java.lang.Object var24 = var21.pop();
    boolean var25 = var21.empty();
    java.lang.Object var27 = var21.push((java.lang.Object)(-1.0d));
    java.lang.Object var28 = var21.pop();
    br.ufal.ic.test.mystack.Stack var30 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var31 = new java.lang.Object();
    java.lang.Object var32 = var30.push(var31);
    boolean var33 = var30.empty();
    br.ufal.ic.test.mystack.Stack var35 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var36 = new java.lang.Object();
    java.lang.Object var37 = var35.push(var36);
    java.lang.Object var38 = var30.push(var36);
    java.lang.Object var39 = var21.push((java.lang.Object)var30);
    java.lang.Object var40 = var14.push((java.lang.Object)var30);
    java.lang.Object var41 = var1.push((java.lang.Object)var30);
    br.ufal.ic.test.mystack.Stack var43 = new br.ufal.ic.test.mystack.Stack(100);
    br.ufal.ic.test.mystack.Stack var45 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var47 = var45.push((java.lang.Object)(short)0);
    br.ufal.ic.test.mystack.Stack var49 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var50 = new java.lang.Object();
    java.lang.Object var51 = var49.push(var50);
    java.lang.Object var52 = var49.pop();
    java.lang.Object var53 = var45.push((java.lang.Object)var49);
    br.ufal.ic.test.mystack.Stack var55 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var56 = new java.lang.Object();
    java.lang.Object var57 = var55.push(var56);
    java.lang.Object var58 = var55.peek();
    java.lang.Object var59 = var49.push((java.lang.Object)var55);
    boolean var60 = var55.empty();
    java.lang.Object var61 = var43.push((java.lang.Object)var55);
    java.lang.Object var62 = var55.pop();
    boolean var63 = var55.empty();
    java.lang.Object var64 = var1.push((java.lang.Object)var55);
    java.lang.Object var65 = var1.peek();
    java.lang.Object var66 = var1.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 100.0d+ "'", var3.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100.0d+ "'", var12.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + (-1)+ "'", var19.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + (-1.0d)+ "'", var27.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + (-1.0d)+ "'", var28.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + (short)0+ "'", var47.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var65 + "' != '" + 100.0d+ "'", var65.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var66 + "' != '" + 100.0d+ "'", var66.equals(100.0d));

  }

  public void test3() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test3");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(-1));
    boolean var5 = var1.empty();
    java.lang.Object var6 = var1.peek();
    boolean var7 = var1.empty();
    java.lang.Object var8 = var1.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1)+ "'", var4.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1)+ "'", var8.equals((-1)));

  }

  public void test4() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test4");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)"hi!");
    br.ufal.ic.test.mystack.Stack var6 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var7 = new java.lang.Object();
    java.lang.Object var8 = var6.push(var7);
    java.lang.Object var9 = var6.pop();
    boolean var10 = var6.empty();
    java.lang.Object var12 = var6.push((java.lang.Object)(-1.0d));
    java.lang.Object var14 = var6.push((java.lang.Object)(-1L));
    java.lang.Object var15 = var1.push(var14);
    java.lang.Object var16 = var1.pop();
    boolean var17 = var1.empty();
    java.lang.Object var18 = var1.peek();
    br.ufal.ic.test.mystack.Stack var20 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var22 = var20.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var24 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var25 = new java.lang.Object();
    java.lang.Object var26 = var24.push(var25);
    java.lang.Object var27 = var24.peek();
    boolean var28 = var24.empty();
    java.lang.Object var29 = var24.peek();
    java.lang.Object var30 = var20.push(var29);
    boolean var31 = var20.empty();
    java.lang.Object var32 = var1.push((java.lang.Object)var31);
    java.lang.Object var33 = var1.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "hi!"+ "'", var4.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (-1.0d)+ "'", var12.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1L)+ "'", var14.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1L)+ "'", var15.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "hi!"+ "'", var16.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + (-1L)+ "'", var18.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + 100.0d+ "'", var22.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + false+ "'", var32.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + (-1L)+ "'", var33.equals((-1L)));

  }

  public void test5() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test5");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(-1));
    java.lang.Object var5 = var1.peek();
    boolean var6 = var1.empty();
    java.lang.Object var7 = var1.peek();
    boolean var8 = var1.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1)+ "'", var4.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1)+ "'", var5.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1)+ "'", var7.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test6() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test6");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(-1));
    java.lang.Object var5 = var1.peek();
    java.lang.Object var6 = var1.peek();
    boolean var7 = var1.empty();
    br.ufal.ic.test.mystack.Stack var9 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var10 = var9.empty();
    java.lang.Object var12 = var9.push((java.lang.Object)(byte)0);
    boolean var13 = var9.empty();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var16 = new java.lang.Object();
    java.lang.Object var17 = var15.push(var16);
    boolean var18 = var15.empty();
    br.ufal.ic.test.mystack.Stack var20 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var21 = new java.lang.Object();
    java.lang.Object var22 = var20.push(var21);
    java.lang.Object var23 = var15.push(var21);
    java.lang.Object var24 = var15.pop();
    java.lang.Object var25 = var15.peek();
    java.lang.Object var26 = var9.push((java.lang.Object)var15);
    java.lang.Object var28 = var9.push((java.lang.Object)0.0d);
    java.lang.Object var29 = var1.push(var28);
    java.lang.Object var30 = var1.peek();
    boolean var31 = var1.empty();
    br.ufal.ic.test.mystack.Stack var33 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var34 = var33.empty();
    java.lang.Object var36 = var33.push((java.lang.Object)(-1));
    java.lang.Object var37 = var33.peek();
    java.lang.Object var39 = var33.push((java.lang.Object)(short)(-1));
    br.ufal.ic.test.mystack.Stack var41 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var42 = new java.lang.Object();
    java.lang.Object var43 = var41.push(var42);
    java.lang.Object var44 = var41.peek();
    java.lang.Object var45 = var33.push(var44);
    br.ufal.ic.test.mystack.Stack var47 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var48 = new java.lang.Object();
    java.lang.Object var49 = var47.push(var48);
    boolean var50 = var47.empty();
    br.ufal.ic.test.mystack.Stack var52 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var53 = new java.lang.Object();
    java.lang.Object var54 = var52.push(var53);
    java.lang.Object var55 = var47.push(var53);
    java.lang.Object var56 = var33.push((java.lang.Object)var47);
    boolean var57 = var33.empty();
    boolean var58 = var33.empty();
    java.lang.Object var59 = var33.pop();
    java.lang.Object var60 = var1.push((java.lang.Object)var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1)+ "'", var4.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1)+ "'", var5.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (byte)0+ "'", var12.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + 0.0d+ "'", var28.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + 0.0d+ "'", var29.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + (-1)+ "'", var30.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + (-1)+ "'", var36.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + (-1)+ "'", var37.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + (short)(-1)+ "'", var39.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var59 + "' != '" + (-1)+ "'", var59.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test7() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test7");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    boolean var8 = var1.empty();
    boolean var9 = var1.empty();
    br.ufal.ic.test.mystack.Stack var11 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var12 = new java.lang.Object();
    java.lang.Object var13 = var11.push(var12);
    java.lang.Object var14 = var11.peek();
    java.lang.Object var16 = var11.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var18 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var19 = var18.empty();
    java.lang.Object var21 = var18.push((java.lang.Object)(-1));
    java.lang.Object var22 = var18.peek();
    java.lang.Object var24 = var18.push((java.lang.Object)(short)(-1));
    br.ufal.ic.test.mystack.Stack var26 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var27 = new java.lang.Object();
    java.lang.Object var28 = var26.push(var27);
    java.lang.Object var29 = var26.peek();
    java.lang.Object var30 = var18.push(var29);
    java.lang.Object var31 = var18.peek();
    java.lang.Object var32 = var11.push(var31);
    java.lang.Object var33 = var11.peek();
    java.lang.Object var34 = var1.push((java.lang.Object)var11);
    boolean var35 = var1.empty();
    java.lang.Object var36 = var1.peek();
    java.lang.Object var37 = var1.pop();
    br.ufal.ic.test.mystack.Stack var39 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var40 = new java.lang.Object();
    java.lang.Object var41 = var39.push(var40);
    boolean var42 = var39.empty();
    br.ufal.ic.test.mystack.Stack var44 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var45 = new java.lang.Object();
    java.lang.Object var46 = var44.push(var45);
    java.lang.Object var47 = var39.push(var45);
    java.lang.Object var48 = var39.pop();
    java.lang.Object var49 = var39.peek();
    br.ufal.ic.test.mystack.Stack var51 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var52 = new java.lang.Object();
    java.lang.Object var53 = var51.push(var52);
    boolean var54 = var51.empty();
    br.ufal.ic.test.mystack.Stack var56 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var57 = new java.lang.Object();
    java.lang.Object var58 = var56.push(var57);
    java.lang.Object var59 = var51.push(var57);
    boolean var60 = var51.empty();
    br.ufal.ic.test.mystack.Stack var62 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var63 = new java.lang.Object();
    java.lang.Object var64 = var62.push(var63);
    java.lang.Object var65 = var62.pop();
    boolean var66 = var62.empty();
    java.lang.Object var68 = var62.push((java.lang.Object)(-1.0d));
    boolean var69 = var62.empty();
    boolean var70 = var62.empty();
    java.lang.Object var71 = var51.push((java.lang.Object)var70);
    java.lang.Object var72 = var39.push((java.lang.Object)var51);
    java.lang.Object var73 = var39.pop();
    java.lang.Object var74 = var1.push((java.lang.Object)var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (-1)+ "'", var16.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (-1)+ "'", var21.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + (-1)+ "'", var22.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (short)(-1)+ "'", var24.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + (-1)+ "'", var31.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + (-1)+ "'", var32.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + (-1.0d)+ "'", var36.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + (-1.0d)+ "'", var37.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var68 + "' != '" + (-1.0d)+ "'", var68.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var71 + "' != '" + false+ "'", var71.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test8() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test8");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var3 = var1.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var5 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var6 = new java.lang.Object();
    java.lang.Object var7 = var5.push(var6);
    java.lang.Object var8 = var5.peek();
    boolean var9 = var5.empty();
    java.lang.Object var10 = var5.peek();
    java.lang.Object var11 = var1.push(var10);
    boolean var12 = var1.empty();
    br.ufal.ic.test.mystack.Stack var14 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var15 = new java.lang.Object();
    java.lang.Object var16 = var14.push(var15);
    java.lang.Object var17 = var1.push((java.lang.Object)var14);
    java.lang.Object var18 = var1.pop();
    boolean var19 = var1.empty();
    boolean var20 = var1.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 100.0d+ "'", var3.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + 100.0d+ "'", var18.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test9() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test9");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(-1));
    java.lang.Object var5 = var1.peek();
    java.lang.Object var6 = var1.peek();
    java.lang.Object var7 = var1.peek();
    br.ufal.ic.test.mystack.Stack var9 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var10 = new java.lang.Object();
    java.lang.Object var11 = var9.push(var10);
    java.lang.Object var12 = var9.pop();
    boolean var13 = var9.empty();
    java.lang.Object var15 = var9.push((java.lang.Object)(-1.0d));
    boolean var16 = var9.empty();
    boolean var17 = var9.empty();
    br.ufal.ic.test.mystack.Stack var19 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var20 = new java.lang.Object();
    java.lang.Object var21 = var19.push(var20);
    boolean var22 = var19.empty();
    br.ufal.ic.test.mystack.Stack var24 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var25 = new java.lang.Object();
    java.lang.Object var26 = var24.push(var25);
    java.lang.Object var27 = var19.push(var25);
    java.lang.Object var28 = var9.push(var25);
    java.lang.Object var29 = var1.push((java.lang.Object)var9);
    br.ufal.ic.test.mystack.Stack var31 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var33 = var31.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var35 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var36 = new java.lang.Object();
    java.lang.Object var37 = var35.push(var36);
    java.lang.Object var38 = var35.peek();
    boolean var39 = var35.empty();
    java.lang.Object var40 = var35.peek();
    java.lang.Object var41 = var31.push(var40);
    java.lang.Object var42 = var31.pop();
    java.lang.Object var43 = var31.peek();
    boolean var44 = var31.empty();
    boolean var45 = var31.empty();
    boolean var46 = var31.empty();
    java.lang.Object var47 = var31.peek();
    boolean var48 = var31.empty();
    java.lang.Object var49 = var9.push((java.lang.Object)var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1)+ "'", var4.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1)+ "'", var5.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1)+ "'", var7.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1.0d)+ "'", var15.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + 100.0d+ "'", var33.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + 100.0d+ "'", var42.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + false+ "'", var49.equals(false));

  }

  public void test10() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test10");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var3 = var1.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var5 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var6 = new java.lang.Object();
    java.lang.Object var7 = var5.push(var6);
    java.lang.Object var8 = var5.peek();
    boolean var9 = var5.empty();
    java.lang.Object var10 = var5.peek();
    java.lang.Object var11 = var1.push(var10);
    java.lang.Object var12 = var1.peek();
    br.ufal.ic.test.mystack.Stack var14 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var16 = var14.push((java.lang.Object)(short)0);
    boolean var17 = var14.empty();
    java.lang.Object var18 = var14.pop();
    br.ufal.ic.test.mystack.Stack var20 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var21 = var20.empty();
    java.lang.Object var23 = var20.push((java.lang.Object)(-1));
    java.lang.Object var24 = var20.peek();
    java.lang.Object var25 = var20.peek();
    boolean var26 = var20.empty();
    br.ufal.ic.test.mystack.Stack var28 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var29 = var28.empty();
    java.lang.Object var31 = var28.push((java.lang.Object)"hi!");
    java.lang.Object var32 = var20.push((java.lang.Object)var28);
    br.ufal.ic.test.mystack.Stack var34 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var35 = var34.empty();
    java.lang.Object var37 = var34.push((java.lang.Object)(-1));
    java.lang.Object var38 = var34.pop();
    boolean var39 = var34.empty();
    br.ufal.ic.test.mystack.Stack var41 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var42 = new java.lang.Object();
    java.lang.Object var43 = var41.push(var42);
    java.lang.Object var44 = var41.peek();
    boolean var45 = var41.empty();
    java.lang.Object var46 = var41.peek();
    java.lang.Object var47 = var34.push((java.lang.Object)var41);
    java.lang.Object var48 = var28.push((java.lang.Object)var41);
    java.lang.Object var49 = var14.push((java.lang.Object)var28);
    java.lang.Object var50 = var1.push((java.lang.Object)var28);
    java.lang.Object var51 = var1.peek();
    br.ufal.ic.test.mystack.Stack var53 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var54 = var1.push((java.lang.Object)(-1));
    java.lang.Object var55 = var1.peek();
    java.lang.Object var56 = var1.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 100.0d+ "'", var3.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100.0d+ "'", var12.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (short)0+ "'", var16.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + (short)0+ "'", var18.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + (-1)+ "'", var23.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (-1)+ "'", var24.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + (-1)+ "'", var25.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "hi!"+ "'", var31.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + (-1)+ "'", var37.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + (-1)+ "'", var38.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + 100.0d+ "'", var51.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + (-1)+ "'", var54.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + 100.0d+ "'", var55.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var56 + "' != '" + 100.0d+ "'", var56.equals(100.0d));

  }

  public void test11() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test11");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(-1));
    boolean var5 = var1.empty();
    boolean var6 = var1.empty();
    boolean var7 = var1.empty();
    br.ufal.ic.test.mystack.Stack var9 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var10 = new java.lang.Object();
    java.lang.Object var11 = var9.push(var10);
    java.lang.Object var12 = var9.peek();
    boolean var13 = var9.empty();
    java.lang.Object var14 = var9.peek();
    java.lang.Object var15 = var9.peek();
    java.lang.Object var16 = var9.pop();
    java.lang.Object var17 = var1.push(var16);
    boolean var18 = var1.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1)+ "'", var4.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test12() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test12");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.peek();
    boolean var5 = var1.empty();
    java.lang.Object var6 = var1.pop();
    br.ufal.ic.test.mystack.Stack var8 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var9 = new java.lang.Object();
    java.lang.Object var10 = var8.push(var9);
    java.lang.Object var11 = var8.pop();
    boolean var12 = var8.empty();
    java.lang.Object var14 = var8.push((java.lang.Object)(-1.0d));
    java.lang.Object var16 = var8.push((java.lang.Object)(-1L));
    java.lang.Object var17 = var8.pop();
    br.ufal.ic.test.mystack.Stack var19 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var20 = var19.empty();
    java.lang.Object var22 = var19.push((java.lang.Object)(-1));
    java.lang.Object var23 = var19.pop();
    boolean var24 = var19.empty();
    boolean var25 = var19.empty();
    br.ufal.ic.test.mystack.Stack var27 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var28 = var27.empty();
    java.lang.Object var29 = var19.push((java.lang.Object)var27);
    java.lang.Object var30 = var8.push((java.lang.Object)var27);
    boolean var31 = var8.empty();
    java.lang.Object var32 = var8.peek();
    java.lang.Object var33 = var8.pop();
    java.lang.Object var34 = var1.push((java.lang.Object)var8);
    java.lang.Object var35 = var8.peek();
    boolean var36 = var8.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1.0d)+ "'", var14.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (-1L)+ "'", var16.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + (-1.0d)+ "'", var17.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + (-1)+ "'", var22.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + (-1)+ "'", var23.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + (-1L)+ "'", var32.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + (-1L)+ "'", var33.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test13() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test13");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.peek();
    java.lang.Object var6 = var1.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var8 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var9 = new java.lang.Object();
    java.lang.Object var10 = var8.push(var9);
    java.lang.Object var11 = var8.pop();
    boolean var12 = var8.empty();
    java.lang.Object var14 = var8.push((java.lang.Object)(-1.0d));
    java.lang.Object var15 = var8.pop();
    br.ufal.ic.test.mystack.Stack var17 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var18 = new java.lang.Object();
    java.lang.Object var19 = var17.push(var18);
    boolean var20 = var17.empty();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var17.push(var23);
    java.lang.Object var26 = var8.push((java.lang.Object)var17);
    java.lang.Object var27 = var1.push((java.lang.Object)var17);
    java.lang.Object var28 = var17.pop();
    boolean var29 = var17.empty();
    java.lang.Object var30 = var17.pop();
    boolean var31 = var17.empty();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var32 = var17.pop();
      fail("Expected exception of type java.util.EmptyStackException");
    } catch (java.util.EmptyStackException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1.0d)+ "'", var14.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1.0d)+ "'", var15.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);

  }

  public void test14() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test14");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var3 = var1.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var5 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var6 = new java.lang.Object();
    java.lang.Object var7 = var5.push(var6);
    java.lang.Object var8 = var5.peek();
    boolean var9 = var5.empty();
    java.lang.Object var10 = var5.peek();
    java.lang.Object var11 = var1.push(var10);
    java.lang.Object var12 = var1.pop();
    java.lang.Object var13 = var1.peek();
    java.lang.Object var14 = var1.peek();
    br.ufal.ic.test.mystack.Stack var16 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var17 = new java.lang.Object();
    java.lang.Object var18 = var16.push(var17);
    java.lang.Object var19 = var16.pop();
    boolean var20 = var16.empty();
    java.lang.Object var22 = var16.push((java.lang.Object)(-1.0d));
    boolean var23 = var16.empty();
    boolean var24 = var16.empty();
    java.lang.Object var25 = var16.pop();
    java.lang.Object var26 = var1.push(var25);
    boolean var27 = var1.empty();
    br.ufal.ic.test.mystack.Stack var29 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var31 = var29.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var33 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var34 = new java.lang.Object();
    java.lang.Object var35 = var33.push(var34);
    java.lang.Object var36 = var33.peek();
    boolean var37 = var33.empty();
    java.lang.Object var38 = var33.peek();
    java.lang.Object var39 = var29.push(var38);
    boolean var40 = var29.empty();
    br.ufal.ic.test.mystack.Stack var42 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var43 = new java.lang.Object();
    java.lang.Object var44 = var42.push(var43);
    java.lang.Object var45 = var29.push((java.lang.Object)var42);
    java.lang.Object var46 = var29.peek();
    java.lang.Object var47 = var29.pop();
    java.lang.Object var48 = var29.pop();
    java.lang.Object var49 = var29.pop();
    java.lang.Object var50 = var1.push((java.lang.Object)var29);
    java.lang.Object var51 = var1.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 100.0d+ "'", var3.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100.0d+ "'", var12.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + (-1.0d)+ "'", var22.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + (-1.0d)+ "'", var25.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + (-1.0d)+ "'", var26.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + 100.0d+ "'", var31.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + 100.0d+ "'", var46.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + 100.0d+ "'", var47.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test15() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test15");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.peek();
    boolean var5 = var1.empty();
    java.lang.Object var6 = var1.peek();
    java.lang.Object var7 = var1.pop();
    boolean var8 = var1.empty();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var9 = var1.pop();
      fail("Expected exception of type java.util.EmptyStackException");
    } catch (java.util.EmptyStackException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test16() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test16");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var8 = var1.pop();
    br.ufal.ic.test.mystack.Stack var10 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var11 = new java.lang.Object();
    java.lang.Object var12 = var10.push(var11);
    boolean var13 = var10.empty();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var16 = new java.lang.Object();
    java.lang.Object var17 = var15.push(var16);
    java.lang.Object var18 = var10.push(var16);
    java.lang.Object var19 = var1.push((java.lang.Object)var10);
    br.ufal.ic.test.mystack.Stack var21 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var22 = var21.empty();
    java.lang.Object var24 = var21.push((java.lang.Object)(-1));
    java.lang.Object var25 = var21.peek();
    java.lang.Object var26 = var21.peek();
    boolean var27 = var21.empty();
    br.ufal.ic.test.mystack.Stack var29 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var30 = var29.empty();
    java.lang.Object var32 = var29.push((java.lang.Object)(byte)0);
    boolean var33 = var29.empty();
    br.ufal.ic.test.mystack.Stack var35 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var36 = new java.lang.Object();
    java.lang.Object var37 = var35.push(var36);
    boolean var38 = var35.empty();
    br.ufal.ic.test.mystack.Stack var40 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var41 = new java.lang.Object();
    java.lang.Object var42 = var40.push(var41);
    java.lang.Object var43 = var35.push(var41);
    java.lang.Object var44 = var35.pop();
    java.lang.Object var45 = var35.peek();
    java.lang.Object var46 = var29.push((java.lang.Object)var35);
    java.lang.Object var48 = var29.push((java.lang.Object)0.0d);
    java.lang.Object var49 = var21.push(var48);
    java.lang.Object var50 = var1.push((java.lang.Object)var21);
    boolean var51 = var21.empty();
    java.lang.Object var52 = var21.pop();
    java.lang.Object var53 = var21.peek();
    br.ufal.ic.test.mystack.Stack var55 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var56 = var55.empty();
    java.lang.Object var58 = var55.push((java.lang.Object)(-1));
    java.lang.Object var59 = var55.peek();
    java.lang.Object var60 = var55.peek();
    java.lang.Object var61 = var55.peek();
    br.ufal.ic.test.mystack.Stack var63 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var64 = new java.lang.Object();
    java.lang.Object var65 = var63.push(var64);
    java.lang.Object var66 = var63.pop();
    boolean var67 = var63.empty();
    java.lang.Object var69 = var63.push((java.lang.Object)(-1.0d));
    boolean var70 = var63.empty();
    boolean var71 = var63.empty();
    br.ufal.ic.test.mystack.Stack var73 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var74 = new java.lang.Object();
    java.lang.Object var75 = var73.push(var74);
    boolean var76 = var73.empty();
    br.ufal.ic.test.mystack.Stack var78 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var79 = new java.lang.Object();
    java.lang.Object var80 = var78.push(var79);
    java.lang.Object var81 = var73.push(var79);
    java.lang.Object var82 = var63.push(var79);
    java.lang.Object var83 = var55.push((java.lang.Object)var63);
    br.ufal.ic.test.mystack.Stack var85 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var86 = new java.lang.Object();
    java.lang.Object var87 = var85.push(var86);
    java.lang.Object var88 = var63.push(var86);
    java.lang.Object var89 = var21.push(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (-1)+ "'", var24.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + (-1)+ "'", var25.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + (byte)0+ "'", var32.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + 0.0d+ "'", var48.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + 0.0d+ "'", var49.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var52 + "' != '" + (-1)+ "'", var52.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + 0.0d+ "'", var53.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var58 + "' != '" + (-1)+ "'", var58.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var59 + "' != '" + (-1)+ "'", var59.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var60 + "' != '" + (-1)+ "'", var60.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var61 + "' != '" + (-1)+ "'", var61.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var69 + "' != '" + (-1.0d)+ "'", var69.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);

  }

  public void test17() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test17");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)"hi!");
    br.ufal.ic.test.mystack.Stack var6 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var7 = new java.lang.Object();
    java.lang.Object var8 = var6.push(var7);
    java.lang.Object var9 = var6.pop();
    boolean var10 = var6.empty();
    java.lang.Object var12 = var6.push((java.lang.Object)(-1.0d));
    java.lang.Object var14 = var6.push((java.lang.Object)(-1L));
    java.lang.Object var15 = var1.push(var14);
    br.ufal.ic.test.mystack.Stack var17 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var18 = new java.lang.Object();
    java.lang.Object var19 = var17.push(var18);
    java.lang.Object var20 = var17.pop();
    boolean var21 = var17.empty();
    java.lang.Object var23 = var17.push((java.lang.Object)(-1.0d));
    java.lang.Object var24 = var17.pop();
    br.ufal.ic.test.mystack.Stack var26 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var27 = new java.lang.Object();
    java.lang.Object var28 = var26.push(var27);
    boolean var29 = var26.empty();
    br.ufal.ic.test.mystack.Stack var31 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var32 = new java.lang.Object();
    java.lang.Object var33 = var31.push(var32);
    java.lang.Object var34 = var26.push(var32);
    java.lang.Object var35 = var17.push((java.lang.Object)var26);
    java.lang.Object var36 = var26.pop();
    br.ufal.ic.test.mystack.Stack var38 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var39 = new java.lang.Object();
    java.lang.Object var40 = var38.push(var39);
    java.lang.Object var41 = var38.pop();
    java.lang.Object var42 = var26.push((java.lang.Object)var38);
    java.lang.Object var43 = var1.push((java.lang.Object)var26);
    br.ufal.ic.test.mystack.Stack var45 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var46 = new java.lang.Object();
    java.lang.Object var47 = var45.push(var46);
    boolean var48 = var45.empty();
    br.ufal.ic.test.mystack.Stack var50 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var51 = new java.lang.Object();
    java.lang.Object var52 = var50.push(var51);
    java.lang.Object var53 = var45.push(var51);
    java.lang.Object var54 = var45.pop();
    java.lang.Object var55 = var45.pop();
    java.lang.Object var56 = var1.push(var55);
    java.lang.Object var57 = var1.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "hi!"+ "'", var4.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (-1.0d)+ "'", var12.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1L)+ "'", var14.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1L)+ "'", var15.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + (-1.0d)+ "'", var23.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (-1.0d)+ "'", var24.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var57 + "' != '" + "hi!"+ "'", var57.equals("hi!"));

  }

  public void test18() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test18");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.peek();
    java.lang.Object var6 = var1.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var8 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var9 = new java.lang.Object();
    java.lang.Object var10 = var8.push(var9);
    java.lang.Object var11 = var8.pop();
    boolean var12 = var8.empty();
    java.lang.Object var14 = var8.push((java.lang.Object)(-1.0d));
    java.lang.Object var15 = var8.pop();
    br.ufal.ic.test.mystack.Stack var17 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var18 = new java.lang.Object();
    java.lang.Object var19 = var17.push(var18);
    boolean var20 = var17.empty();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var17.push(var23);
    java.lang.Object var26 = var8.push((java.lang.Object)var17);
    java.lang.Object var27 = var1.push((java.lang.Object)var17);
    java.lang.Object var28 = var17.peek();
    br.ufal.ic.test.mystack.Stack var30 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var31 = var30.empty();
    java.lang.Object var33 = var30.push((java.lang.Object)(-1));
    boolean var34 = var30.empty();
    boolean var35 = var30.empty();
    br.ufal.ic.test.mystack.Stack var37 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var38 = new java.lang.Object();
    java.lang.Object var39 = var37.push(var38);
    boolean var40 = var37.empty();
    br.ufal.ic.test.mystack.Stack var42 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var43 = new java.lang.Object();
    java.lang.Object var44 = var42.push(var43);
    java.lang.Object var45 = var37.push(var43);
    java.lang.Object var46 = var37.pop();
    java.lang.Object var47 = var30.push((java.lang.Object)var37);
    java.lang.Object var48 = var17.push((java.lang.Object)var30);
    java.lang.Object var49 = var30.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1.0d)+ "'", var14.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1.0d)+ "'", var15.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + (-1)+ "'", var33.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + (-1)+ "'", var49.equals((-1)));

  }

  public void test19() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test19");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    boolean var8 = var1.empty();
    boolean var9 = var1.empty();
    br.ufal.ic.test.mystack.Stack var11 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var12 = new java.lang.Object();
    java.lang.Object var13 = var11.push(var12);
    java.lang.Object var14 = var11.peek();
    java.lang.Object var16 = var11.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var18 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var19 = var18.empty();
    java.lang.Object var21 = var18.push((java.lang.Object)(-1));
    java.lang.Object var22 = var18.peek();
    java.lang.Object var24 = var18.push((java.lang.Object)(short)(-1));
    br.ufal.ic.test.mystack.Stack var26 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var27 = new java.lang.Object();
    java.lang.Object var28 = var26.push(var27);
    java.lang.Object var29 = var26.peek();
    java.lang.Object var30 = var18.push(var29);
    java.lang.Object var31 = var18.peek();
    java.lang.Object var32 = var11.push(var31);
    java.lang.Object var33 = var11.peek();
    java.lang.Object var34 = var1.push((java.lang.Object)var11);
    br.ufal.ic.test.mystack.Stack var36 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var37 = new java.lang.Object();
    java.lang.Object var38 = var36.push(var37);
    java.lang.Object var39 = var36.pop();
    boolean var40 = var36.empty();
    java.lang.Object var42 = var36.push((java.lang.Object)(-1.0d));
    java.lang.Object var44 = var36.push((java.lang.Object)(-1L));
    java.lang.Object var45 = var36.pop();
    br.ufal.ic.test.mystack.Stack var47 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var48 = new java.lang.Object();
    java.lang.Object var49 = var47.push(var48);
    java.lang.Object var50 = var47.pop();
    boolean var51 = var47.empty();
    java.lang.Object var53 = var47.push((java.lang.Object)(-1.0d));
    java.lang.Object var54 = var47.pop();
    br.ufal.ic.test.mystack.Stack var56 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var57 = new java.lang.Object();
    java.lang.Object var58 = var56.push(var57);
    boolean var59 = var56.empty();
    br.ufal.ic.test.mystack.Stack var61 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var62 = new java.lang.Object();
    java.lang.Object var63 = var61.push(var62);
    java.lang.Object var64 = var56.push(var62);
    java.lang.Object var65 = var47.push((java.lang.Object)var56);
    java.lang.Object var66 = var56.pop();
    java.lang.Object var67 = var36.push((java.lang.Object)var56);
    java.lang.Object var68 = var36.peek();
    java.lang.Object var69 = var36.peek();
    java.lang.Object var70 = var11.push(var69);
    boolean var71 = var11.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (-1)+ "'", var16.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (-1)+ "'", var21.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + (-1)+ "'", var22.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (short)(-1)+ "'", var24.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + (-1)+ "'", var31.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + (-1)+ "'", var32.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + (-1.0d)+ "'", var42.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + (-1L)+ "'", var44.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + (-1.0d)+ "'", var45.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + (-1.0d)+ "'", var53.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + (-1.0d)+ "'", var54.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var68 + "' != '" + (-1L)+ "'", var68.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var69 + "' != '" + (-1L)+ "'", var69.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var70 + "' != '" + (-1L)+ "'", var70.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);

  }

  public void test20() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test20");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var8 = var1.pop();
    br.ufal.ic.test.mystack.Stack var10 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var11 = var10.empty();
    java.lang.Object var13 = var10.push((java.lang.Object)(-1));
    java.lang.Object var14 = var10.peek();
    java.lang.Object var16 = var10.push((java.lang.Object)(short)(-1));
    br.ufal.ic.test.mystack.Stack var18 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var19 = new java.lang.Object();
    java.lang.Object var20 = var18.push(var19);
    java.lang.Object var21 = var18.peek();
    java.lang.Object var22 = var10.push(var21);
    java.lang.Object var23 = var1.push(var21);
    java.lang.Object var24 = var1.pop();
    br.ufal.ic.test.mystack.Stack var26 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var28 = var26.push((java.lang.Object)(short)0);
    java.lang.Object var29 = var26.peek();
    boolean var30 = var26.empty();
    java.lang.Object var31 = var1.push((java.lang.Object)var26);
    java.lang.Object var32 = var1.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + (-1)+ "'", var13.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (short)(-1)+ "'", var16.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + (short)0+ "'", var28.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + (short)0+ "'", var29.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test21() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test21");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    boolean var4 = var1.empty();
    java.lang.Object var5 = var1.peek();
    boolean var6 = var1.empty();
    java.lang.Object var7 = var1.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test22() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test22");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.peek();
    java.lang.Object var6 = var1.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var8 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var9 = new java.lang.Object();
    java.lang.Object var10 = var8.push(var9);
    java.lang.Object var11 = var8.pop();
    boolean var12 = var8.empty();
    java.lang.Object var14 = var8.push((java.lang.Object)(-1.0d));
    java.lang.Object var15 = var8.pop();
    br.ufal.ic.test.mystack.Stack var17 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var18 = new java.lang.Object();
    java.lang.Object var19 = var17.push(var18);
    boolean var20 = var17.empty();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var17.push(var23);
    java.lang.Object var26 = var8.push((java.lang.Object)var17);
    java.lang.Object var27 = var1.push((java.lang.Object)var17);
    java.lang.Object var28 = var17.pop();
    boolean var29 = var17.empty();
    boolean var30 = var17.empty();
    java.lang.Object var31 = var17.pop();
    br.ufal.ic.test.mystack.Stack var33 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var34 = var33.empty();
    java.lang.Object var36 = var33.push((java.lang.Object)(-1));
    java.lang.Object var37 = var33.pop();
    boolean var38 = var33.empty();
    java.lang.Object var40 = var33.push((java.lang.Object)"");
    java.lang.Object var41 = var33.peek();
    boolean var42 = var33.empty();
    java.lang.Object var43 = var17.push((java.lang.Object)var42);
    java.lang.Object var44 = var17.pop();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var45 = var17.peek();
      fail("Expected exception of type java.util.EmptyStackException");
    } catch (java.util.EmptyStackException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1.0d)+ "'", var14.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1.0d)+ "'", var15.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + (-1)+ "'", var36.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + (-1)+ "'", var37.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var40 + "' != '" + ""+ "'", var40.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + ""+ "'", var41.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + false+ "'", var43.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + false+ "'", var44.equals(false));

  }

  public void test23() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test23");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)"hi!");
    java.lang.Object var5 = var1.peek();
    java.lang.Object var6 = var1.peek();
    java.lang.Object var7 = var1.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "hi!"+ "'", var4.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "hi!"+ "'", var5.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "hi!"+ "'", var6.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "hi!"+ "'", var7.equals("hi!"));

  }

  public void test24() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test24");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(-1));
    boolean var5 = var1.empty();
    br.ufal.ic.test.mystack.Stack var7 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var8 = new java.lang.Object();
    java.lang.Object var9 = var7.push(var8);
    java.lang.Object var10 = var7.pop();
    boolean var11 = var7.empty();
    java.lang.Object var13 = var7.push((java.lang.Object)(-1.0d));
    java.lang.Object var14 = var7.pop();
    br.ufal.ic.test.mystack.Stack var16 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var17 = new java.lang.Object();
    java.lang.Object var18 = var16.push(var17);
    boolean var19 = var16.empty();
    br.ufal.ic.test.mystack.Stack var21 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var22 = new java.lang.Object();
    java.lang.Object var23 = var21.push(var22);
    java.lang.Object var24 = var16.push(var22);
    java.lang.Object var25 = var7.push((java.lang.Object)var16);
    java.lang.Object var26 = var1.push((java.lang.Object)var7);
    java.lang.Object var27 = var7.peek();
    java.lang.Object var29 = var7.push((java.lang.Object)(-1.0f));
    java.lang.Object var30 = var7.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1)+ "'", var4.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + (-1.0d)+ "'", var13.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1.0d)+ "'", var14.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + (-1.0f)+ "'", var29.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test25() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test25");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)"hi!");
    br.ufal.ic.test.mystack.Stack var6 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var7 = new java.lang.Object();
    java.lang.Object var8 = var6.push(var7);
    java.lang.Object var9 = var6.pop();
    boolean var10 = var6.empty();
    java.lang.Object var12 = var6.push((java.lang.Object)(-1.0d));
    java.lang.Object var14 = var6.push((java.lang.Object)(-1L));
    java.lang.Object var15 = var1.push(var14);
    br.ufal.ic.test.mystack.Stack var17 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var18 = new java.lang.Object();
    java.lang.Object var19 = var17.push(var18);
    java.lang.Object var20 = var17.pop();
    boolean var21 = var17.empty();
    java.lang.Object var23 = var17.push((java.lang.Object)(-1.0d));
    java.lang.Object var24 = var17.pop();
    br.ufal.ic.test.mystack.Stack var26 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var27 = new java.lang.Object();
    java.lang.Object var28 = var26.push(var27);
    boolean var29 = var26.empty();
    br.ufal.ic.test.mystack.Stack var31 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var32 = new java.lang.Object();
    java.lang.Object var33 = var31.push(var32);
    java.lang.Object var34 = var26.push(var32);
    java.lang.Object var35 = var17.push((java.lang.Object)var26);
    java.lang.Object var36 = var26.pop();
    br.ufal.ic.test.mystack.Stack var38 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var39 = new java.lang.Object();
    java.lang.Object var40 = var38.push(var39);
    java.lang.Object var41 = var38.pop();
    java.lang.Object var42 = var26.push((java.lang.Object)var38);
    java.lang.Object var43 = var1.push((java.lang.Object)var26);
    boolean var44 = var26.empty();
    java.lang.Object var45 = var26.peek();
    java.lang.Object var46 = var26.peek();
    br.ufal.ic.test.mystack.Stack var48 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var49 = new java.lang.Object();
    java.lang.Object var50 = var48.push(var49);
    java.lang.Object var51 = var48.peek();
    java.lang.Object var53 = var48.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var55 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var56 = var55.empty();
    java.lang.Object var58 = var55.push((java.lang.Object)(-1));
    java.lang.Object var59 = var55.peek();
    java.lang.Object var61 = var55.push((java.lang.Object)(short)(-1));
    br.ufal.ic.test.mystack.Stack var63 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var64 = new java.lang.Object();
    java.lang.Object var65 = var63.push(var64);
    java.lang.Object var66 = var63.peek();
    java.lang.Object var67 = var55.push(var66);
    java.lang.Object var68 = var55.peek();
    java.lang.Object var69 = var48.push(var68);
    java.lang.Object var70 = var48.peek();
    java.lang.Object var71 = var48.pop();
    java.lang.Object var72 = var26.push((java.lang.Object)var48);
    java.lang.Object var73 = var26.peek();
    java.lang.Object var74 = var26.pop();
    java.lang.Object var75 = var26.peek();
    java.lang.Object var76 = var26.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "hi!"+ "'", var4.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (-1.0d)+ "'", var12.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1L)+ "'", var14.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1L)+ "'", var15.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + (-1.0d)+ "'", var23.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (-1.0d)+ "'", var24.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + (-1)+ "'", var53.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var58 + "' != '" + (-1)+ "'", var58.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var59 + "' != '" + (-1)+ "'", var59.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var61 + "' != '" + (short)(-1)+ "'", var61.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var68 + "' != '" + (-1)+ "'", var68.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var69 + "' != '" + (-1)+ "'", var69.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test26() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test26");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var8 = var1.pop();
    br.ufal.ic.test.mystack.Stack var10 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var11 = new java.lang.Object();
    java.lang.Object var12 = var10.push(var11);
    boolean var13 = var10.empty();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var16 = new java.lang.Object();
    java.lang.Object var17 = var15.push(var16);
    java.lang.Object var18 = var10.push(var16);
    java.lang.Object var19 = var1.push((java.lang.Object)var10);
    java.lang.Object var20 = var10.pop();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var22.pop();
    java.lang.Object var26 = var10.push((java.lang.Object)var22);
    java.lang.Object var27 = var10.pop();
    boolean var28 = var10.empty();
    boolean var29 = var10.empty();
    java.lang.Object var30 = var10.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test27() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test27");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var3 = var1.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var5 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var6 = new java.lang.Object();
    java.lang.Object var7 = var5.push(var6);
    java.lang.Object var8 = var5.peek();
    boolean var9 = var5.empty();
    java.lang.Object var10 = var5.peek();
    java.lang.Object var11 = var1.push(var10);
    java.lang.Object var12 = var1.peek();
    java.lang.Object var13 = var1.pop();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var16 = new java.lang.Object();
    java.lang.Object var17 = var15.push(var16);
    java.lang.Object var18 = var15.peek();
    java.lang.Object var20 = var15.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var22.pop();
    boolean var26 = var22.empty();
    java.lang.Object var28 = var22.push((java.lang.Object)(-1.0d));
    java.lang.Object var29 = var22.pop();
    br.ufal.ic.test.mystack.Stack var31 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var32 = new java.lang.Object();
    java.lang.Object var33 = var31.push(var32);
    boolean var34 = var31.empty();
    br.ufal.ic.test.mystack.Stack var36 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var37 = new java.lang.Object();
    java.lang.Object var38 = var36.push(var37);
    java.lang.Object var39 = var31.push(var37);
    java.lang.Object var40 = var22.push((java.lang.Object)var31);
    java.lang.Object var41 = var15.push((java.lang.Object)var31);
    boolean var42 = var31.empty();
    br.ufal.ic.test.mystack.Stack var44 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var45 = new java.lang.Object();
    java.lang.Object var46 = var44.push(var45);
    java.lang.Object var47 = var44.peek();
    boolean var48 = var44.empty();
    java.lang.Object var49 = var31.push((java.lang.Object)var44);
    java.lang.Object var50 = var31.peek();
    java.lang.Object var51 = var1.push((java.lang.Object)var31);
    java.lang.Object var52 = var31.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 100.0d+ "'", var3.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100.0d+ "'", var12.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 100.0d+ "'", var13.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + (-1)+ "'", var20.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + (-1.0d)+ "'", var28.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + (-1.0d)+ "'", var29.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test28() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test28");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    boolean var4 = var1.empty();
    br.ufal.ic.test.mystack.Stack var6 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var7 = new java.lang.Object();
    java.lang.Object var8 = var6.push(var7);
    java.lang.Object var9 = var1.push(var7);
    java.lang.Object var10 = var1.peek();
    boolean var11 = var1.empty();
    java.lang.Object var12 = var1.pop();
    java.lang.Object var13 = var1.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test29() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test29");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)"hi!");
    br.ufal.ic.test.mystack.Stack var6 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var7 = new java.lang.Object();
    java.lang.Object var8 = var6.push(var7);
    java.lang.Object var9 = var6.pop();
    boolean var10 = var6.empty();
    java.lang.Object var12 = var6.push((java.lang.Object)(-1.0d));
    java.lang.Object var14 = var6.push((java.lang.Object)(-1L));
    java.lang.Object var15 = var1.push(var14);
    br.ufal.ic.test.mystack.Stack var17 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var18 = new java.lang.Object();
    java.lang.Object var19 = var17.push(var18);
    java.lang.Object var20 = var17.pop();
    boolean var21 = var17.empty();
    java.lang.Object var23 = var17.push((java.lang.Object)(-1.0d));
    java.lang.Object var24 = var17.pop();
    br.ufal.ic.test.mystack.Stack var26 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var27 = new java.lang.Object();
    java.lang.Object var28 = var26.push(var27);
    boolean var29 = var26.empty();
    br.ufal.ic.test.mystack.Stack var31 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var32 = new java.lang.Object();
    java.lang.Object var33 = var31.push(var32);
    java.lang.Object var34 = var26.push(var32);
    java.lang.Object var35 = var17.push((java.lang.Object)var26);
    java.lang.Object var36 = var26.pop();
    br.ufal.ic.test.mystack.Stack var38 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var39 = new java.lang.Object();
    java.lang.Object var40 = var38.push(var39);
    java.lang.Object var41 = var38.pop();
    java.lang.Object var42 = var26.push((java.lang.Object)var38);
    java.lang.Object var43 = var1.push((java.lang.Object)var26);
    br.ufal.ic.test.mystack.Stack var45 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var46 = new java.lang.Object();
    java.lang.Object var47 = var45.push(var46);
    java.lang.Object var48 = var45.pop();
    boolean var49 = var45.empty();
    java.lang.Object var51 = var45.push((java.lang.Object)(-1.0d));
    java.lang.Object var53 = var45.push((java.lang.Object)(-1L));
    java.lang.Object var54 = var45.pop();
    br.ufal.ic.test.mystack.Stack var56 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var57 = var56.empty();
    java.lang.Object var59 = var56.push((java.lang.Object)"hi!");
    br.ufal.ic.test.mystack.Stack var61 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var62 = new java.lang.Object();
    java.lang.Object var63 = var61.push(var62);
    java.lang.Object var64 = var61.pop();
    boolean var65 = var61.empty();
    java.lang.Object var67 = var61.push((java.lang.Object)(-1.0d));
    java.lang.Object var69 = var61.push((java.lang.Object)(-1L));
    java.lang.Object var70 = var56.push(var69);
    java.lang.Object var71 = var45.push(var70);
    br.ufal.ic.test.mystack.Stack var73 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var75 = var73.push((java.lang.Object)(short)0);
    java.lang.Object var76 = var73.pop();
    br.ufal.ic.test.mystack.Stack var78 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var79 = new java.lang.Object();
    java.lang.Object var80 = var78.push(var79);
    boolean var81 = var78.empty();
    br.ufal.ic.test.mystack.Stack var83 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var84 = new java.lang.Object();
    java.lang.Object var85 = var83.push(var84);
    java.lang.Object var86 = var78.push(var84);
    java.lang.Object var87 = var78.pop();
    java.lang.Object var88 = var78.peek();
    java.lang.Object var89 = var73.push((java.lang.Object)var78);
    java.lang.Object var90 = var45.push(var89);
    java.lang.Object var91 = var26.push(var89);
    java.lang.Object var92 = var26.pop();
    boolean var93 = var26.empty();
    boolean var94 = var26.empty();
    boolean var95 = var26.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "hi!"+ "'", var4.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (-1.0d)+ "'", var12.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1L)+ "'", var14.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1L)+ "'", var15.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + (-1.0d)+ "'", var23.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (-1.0d)+ "'", var24.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + (-1.0d)+ "'", var51.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + (-1L)+ "'", var53.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + (-1.0d)+ "'", var54.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var59 + "' != '" + "hi!"+ "'", var59.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var67 + "' != '" + (-1.0d)+ "'", var67.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var69 + "' != '" + (-1L)+ "'", var69.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var70 + "' != '" + (-1L)+ "'", var70.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var71 + "' != '" + (-1L)+ "'", var71.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var75 + "' != '" + (short)0+ "'", var75.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var76 + "' != '" + (short)0+ "'", var76.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == false);

  }

  public void test30() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test30");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.peek();
    java.lang.Object var6 = var1.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var8 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var9 = var8.empty();
    java.lang.Object var11 = var8.push((java.lang.Object)(-1));
    java.lang.Object var12 = var8.peek();
    java.lang.Object var14 = var8.push((java.lang.Object)(short)(-1));
    br.ufal.ic.test.mystack.Stack var16 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var17 = new java.lang.Object();
    java.lang.Object var18 = var16.push(var17);
    java.lang.Object var19 = var16.peek();
    java.lang.Object var20 = var8.push(var19);
    java.lang.Object var21 = var8.peek();
    java.lang.Object var22 = var1.push(var21);
    java.lang.Object var23 = var1.peek();
    br.ufal.ic.test.mystack.Stack var25 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var26 = var25.empty();
    java.lang.Object var28 = var25.push((java.lang.Object)(byte)0);
    boolean var29 = var25.empty();
    br.ufal.ic.test.mystack.Stack var31 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var32 = new java.lang.Object();
    java.lang.Object var33 = var31.push(var32);
    boolean var34 = var31.empty();
    br.ufal.ic.test.mystack.Stack var36 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var37 = new java.lang.Object();
    java.lang.Object var38 = var36.push(var37);
    java.lang.Object var39 = var31.push(var37);
    java.lang.Object var40 = var31.pop();
    java.lang.Object var41 = var31.peek();
    java.lang.Object var42 = var25.push((java.lang.Object)var31);
    br.ufal.ic.test.mystack.Stack var44 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var45 = new java.lang.Object();
    java.lang.Object var46 = var44.push(var45);
    boolean var47 = var44.empty();
    boolean var48 = var44.empty();
    br.ufal.ic.test.mystack.Stack var50 = new br.ufal.ic.test.mystack.Stack(1);
    java.lang.Object var51 = var44.push((java.lang.Object)1);
    java.lang.Object var52 = var44.peek();
    java.lang.Object var53 = var31.push(var52);
    java.lang.Object var54 = var1.push(var52);
    java.lang.Object var55 = var1.peek();
    java.lang.Object var56 = var1.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (-1)+ "'", var11.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (-1)+ "'", var12.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (short)(-1)+ "'", var14.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (-1)+ "'", var21.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + (-1)+ "'", var22.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + (byte)0+ "'", var28.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + 1+ "'", var51.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test31() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test31");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var8 = var1.pop();
    br.ufal.ic.test.mystack.Stack var10 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var11 = new java.lang.Object();
    java.lang.Object var12 = var10.push(var11);
    boolean var13 = var10.empty();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var16 = new java.lang.Object();
    java.lang.Object var17 = var15.push(var16);
    java.lang.Object var18 = var10.push(var16);
    java.lang.Object var19 = var1.push((java.lang.Object)var10);
    br.ufal.ic.test.mystack.Stack var21 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var22 = var21.empty();
    java.lang.Object var24 = var21.push((java.lang.Object)(-1));
    java.lang.Object var25 = var21.peek();
    java.lang.Object var26 = var21.peek();
    boolean var27 = var21.empty();
    br.ufal.ic.test.mystack.Stack var29 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var30 = var29.empty();
    java.lang.Object var32 = var29.push((java.lang.Object)(byte)0);
    boolean var33 = var29.empty();
    br.ufal.ic.test.mystack.Stack var35 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var36 = new java.lang.Object();
    java.lang.Object var37 = var35.push(var36);
    boolean var38 = var35.empty();
    br.ufal.ic.test.mystack.Stack var40 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var41 = new java.lang.Object();
    java.lang.Object var42 = var40.push(var41);
    java.lang.Object var43 = var35.push(var41);
    java.lang.Object var44 = var35.pop();
    java.lang.Object var45 = var35.peek();
    java.lang.Object var46 = var29.push((java.lang.Object)var35);
    java.lang.Object var48 = var29.push((java.lang.Object)0.0d);
    java.lang.Object var49 = var21.push(var48);
    java.lang.Object var50 = var1.push((java.lang.Object)var21);
    boolean var51 = var21.empty();
    java.lang.Object var52 = var21.pop();
    boolean var53 = var21.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (-1)+ "'", var24.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + (-1)+ "'", var25.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + (byte)0+ "'", var32.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + 0.0d+ "'", var48.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + 0.0d+ "'", var49.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var52 + "' != '" + (-1)+ "'", var52.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);

  }

  public void test32() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test32");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var9 = var1.push((java.lang.Object)(-1L));
    java.lang.Object var10 = var1.pop();
    br.ufal.ic.test.mystack.Stack var12 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var13 = new java.lang.Object();
    java.lang.Object var14 = var12.push(var13);
    java.lang.Object var15 = var12.pop();
    boolean var16 = var12.empty();
    java.lang.Object var18 = var12.push((java.lang.Object)(-1.0d));
    java.lang.Object var19 = var12.pop();
    br.ufal.ic.test.mystack.Stack var21 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var22 = new java.lang.Object();
    java.lang.Object var23 = var21.push(var22);
    boolean var24 = var21.empty();
    br.ufal.ic.test.mystack.Stack var26 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var27 = new java.lang.Object();
    java.lang.Object var28 = var26.push(var27);
    java.lang.Object var29 = var21.push(var27);
    java.lang.Object var30 = var12.push((java.lang.Object)var21);
    java.lang.Object var31 = var21.pop();
    java.lang.Object var32 = var1.push((java.lang.Object)var21);
    java.lang.Object var33 = var1.peek();
    br.ufal.ic.test.mystack.Stack var35 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var37 = var35.push((java.lang.Object)(short)0);
    br.ufal.ic.test.mystack.Stack var39 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var40 = new java.lang.Object();
    java.lang.Object var41 = var39.push(var40);
    java.lang.Object var42 = var39.pop();
    java.lang.Object var43 = var35.push((java.lang.Object)var39);
    br.ufal.ic.test.mystack.Stack var45 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var46 = new java.lang.Object();
    java.lang.Object var47 = var45.push(var46);
    java.lang.Object var48 = var45.peek();
    java.lang.Object var49 = var39.push((java.lang.Object)var45);
    java.lang.Object var50 = var1.push((java.lang.Object)var45);
    br.ufal.ic.test.mystack.Stack var52 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var53 = var52.empty();
    java.lang.Object var55 = var52.push((java.lang.Object)(-1));
    java.lang.Object var56 = var52.peek();
    java.lang.Object var57 = var52.peek();
    java.lang.Object var58 = var52.peek();
    br.ufal.ic.test.mystack.Stack var60 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var61 = new java.lang.Object();
    java.lang.Object var62 = var60.push(var61);
    java.lang.Object var63 = var60.pop();
    boolean var64 = var60.empty();
    java.lang.Object var66 = var60.push((java.lang.Object)(-1.0d));
    boolean var67 = var60.empty();
    boolean var68 = var60.empty();
    br.ufal.ic.test.mystack.Stack var70 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var71 = new java.lang.Object();
    java.lang.Object var72 = var70.push(var71);
    boolean var73 = var70.empty();
    br.ufal.ic.test.mystack.Stack var75 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var76 = new java.lang.Object();
    java.lang.Object var77 = var75.push(var76);
    java.lang.Object var78 = var70.push(var76);
    java.lang.Object var79 = var60.push(var76);
    java.lang.Object var80 = var52.push((java.lang.Object)var60);
    java.lang.Object var81 = var1.push((java.lang.Object)var60);
    java.lang.Object var82 = var1.peek();
    br.ufal.ic.test.mystack.Stack var84 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var85 = new java.lang.Object();
    java.lang.Object var86 = var84.push(var85);
    boolean var87 = var84.empty();
    br.ufal.ic.test.mystack.Stack var89 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var90 = new java.lang.Object();
    java.lang.Object var91 = var89.push(var90);
    java.lang.Object var92 = var84.push(var90);
    java.lang.Object var93 = var84.pop();
    java.lang.Object var94 = var84.peek();
    java.lang.Object var95 = var1.push(var94);
    java.lang.Object var96 = var1.peek();
    java.lang.Object var97 = var1.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (-1L)+ "'", var9.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (-1.0d)+ "'", var10.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + (-1.0d)+ "'", var18.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + (-1.0d)+ "'", var19.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + (-1L)+ "'", var33.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + (short)0+ "'", var37.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + (-1)+ "'", var55.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var56 + "' != '" + (-1)+ "'", var56.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var57 + "' != '" + (-1)+ "'", var57.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var58 + "' != '" + (-1)+ "'", var58.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var66 + "' != '" + (-1.0d)+ "'", var66.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var82 + "' != '" + (-1L)+ "'", var82.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var96 + "' != '" + (-1L)+ "'", var96.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var97 + "' != '" + (-1L)+ "'", var97.equals((-1L)));

  }

  public void test33() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test33");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.peek();
    boolean var5 = var1.empty();
    java.lang.Object var6 = var1.peek();
    java.lang.Object var7 = var1.peek();
    java.lang.Object var8 = var1.peek();
    java.lang.Object var9 = var1.peek();
    boolean var10 = var1.empty();
    java.lang.Object var11 = var1.peek();
    boolean var12 = var1.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test34() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test34");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.peek();
    java.lang.Object var6 = var1.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var8 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var9 = new java.lang.Object();
    java.lang.Object var10 = var8.push(var9);
    java.lang.Object var11 = var8.pop();
    boolean var12 = var8.empty();
    java.lang.Object var14 = var8.push((java.lang.Object)(-1.0d));
    java.lang.Object var15 = var8.pop();
    br.ufal.ic.test.mystack.Stack var17 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var18 = new java.lang.Object();
    java.lang.Object var19 = var17.push(var18);
    boolean var20 = var17.empty();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var17.push(var23);
    java.lang.Object var26 = var8.push((java.lang.Object)var17);
    java.lang.Object var27 = var1.push((java.lang.Object)var17);
    boolean var28 = var17.empty();
    br.ufal.ic.test.mystack.Stack var30 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var31 = new java.lang.Object();
    java.lang.Object var32 = var30.push(var31);
    java.lang.Object var33 = var30.peek();
    boolean var34 = var30.empty();
    java.lang.Object var35 = var17.push((java.lang.Object)var30);
    java.lang.Object var36 = var30.peek();
    java.lang.Object var37 = var30.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1.0d)+ "'", var14.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1.0d)+ "'", var15.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test35() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test35");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var3 = var1.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var5 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var6 = new java.lang.Object();
    java.lang.Object var7 = var5.push(var6);
    java.lang.Object var8 = var5.peek();
    boolean var9 = var5.empty();
    java.lang.Object var10 = var5.peek();
    java.lang.Object var11 = var1.push(var10);
    boolean var12 = var1.empty();
    br.ufal.ic.test.mystack.Stack var14 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var15 = new java.lang.Object();
    java.lang.Object var16 = var14.push(var15);
    java.lang.Object var17 = var1.push((java.lang.Object)var14);
    br.ufal.ic.test.mystack.Stack var19 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var20 = new java.lang.Object();
    java.lang.Object var21 = var19.push(var20);
    java.lang.Object var22 = var19.pop();
    boolean var23 = var19.empty();
    java.lang.Object var25 = var19.push((java.lang.Object)(-1.0d));
    boolean var26 = var19.empty();
    java.lang.Object var27 = var19.pop();
    br.ufal.ic.test.mystack.Stack var29 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var31 = var29.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var33 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var34 = new java.lang.Object();
    java.lang.Object var35 = var33.push(var34);
    java.lang.Object var36 = var33.peek();
    boolean var37 = var33.empty();
    java.lang.Object var38 = var33.peek();
    java.lang.Object var39 = var29.push(var38);
    boolean var40 = var29.empty();
    br.ufal.ic.test.mystack.Stack var42 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var43 = new java.lang.Object();
    java.lang.Object var44 = var42.push(var43);
    java.lang.Object var45 = var29.push((java.lang.Object)var42);
    java.lang.Object var46 = var19.push((java.lang.Object)var42);
    java.lang.Object var47 = var14.push(var46);
    java.lang.Object var48 = var14.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 100.0d+ "'", var3.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + (-1.0d)+ "'", var25.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + (-1.0d)+ "'", var27.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + 100.0d+ "'", var31.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test36() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test36");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.peek();
    java.lang.Object var6 = var1.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var8 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var9 = new java.lang.Object();
    java.lang.Object var10 = var8.push(var9);
    java.lang.Object var11 = var8.pop();
    boolean var12 = var8.empty();
    java.lang.Object var14 = var8.push((java.lang.Object)(-1.0d));
    java.lang.Object var15 = var8.pop();
    br.ufal.ic.test.mystack.Stack var17 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var18 = new java.lang.Object();
    java.lang.Object var19 = var17.push(var18);
    boolean var20 = var17.empty();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var17.push(var23);
    java.lang.Object var26 = var8.push((java.lang.Object)var17);
    java.lang.Object var27 = var1.push((java.lang.Object)var17);
    java.lang.Object var28 = var17.pop();
    boolean var29 = var17.empty();
    br.ufal.ic.test.mystack.Stack var31 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var32 = var31.empty();
    java.lang.Object var34 = var31.push((java.lang.Object)(-1));
    java.lang.Object var35 = var31.peek();
    java.lang.Object var36 = var31.peek();
    java.lang.Object var37 = var31.peek();
    br.ufal.ic.test.mystack.Stack var39 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var40 = new java.lang.Object();
    java.lang.Object var41 = var39.push(var40);
    java.lang.Object var42 = var39.pop();
    boolean var43 = var39.empty();
    java.lang.Object var45 = var39.push((java.lang.Object)(-1.0d));
    boolean var46 = var39.empty();
    boolean var47 = var39.empty();
    br.ufal.ic.test.mystack.Stack var49 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var50 = new java.lang.Object();
    java.lang.Object var51 = var49.push(var50);
    boolean var52 = var49.empty();
    br.ufal.ic.test.mystack.Stack var54 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var55 = new java.lang.Object();
    java.lang.Object var56 = var54.push(var55);
    java.lang.Object var57 = var49.push(var55);
    java.lang.Object var58 = var39.push(var55);
    java.lang.Object var59 = var31.push((java.lang.Object)var39);
    java.lang.Object var60 = var17.push((java.lang.Object)var31);
    br.ufal.ic.test.mystack.Stack var62 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var63 = var62.empty();
    java.lang.Object var65 = var62.push((java.lang.Object)(-1));
    java.lang.Object var66 = var62.peek();
    java.lang.Object var68 = var62.push((java.lang.Object)(short)(-1));
    boolean var69 = var62.empty();
    java.lang.Object var70 = var31.push((java.lang.Object)var62);
    br.ufal.ic.test.mystack.Stack var72 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var74 = var72.push((java.lang.Object)(short)0);
    java.lang.Object var75 = var72.pop();
    br.ufal.ic.test.mystack.Stack var77 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var78 = new java.lang.Object();
    java.lang.Object var79 = var77.push(var78);
    boolean var80 = var77.empty();
    br.ufal.ic.test.mystack.Stack var82 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var83 = new java.lang.Object();
    java.lang.Object var84 = var82.push(var83);
    java.lang.Object var85 = var77.push(var83);
    java.lang.Object var86 = var77.pop();
    java.lang.Object var87 = var77.peek();
    java.lang.Object var88 = var72.push((java.lang.Object)var77);
    java.lang.Object var89 = var72.pop();
    java.lang.Object var90 = var62.push(var89);
    java.lang.Object var91 = var62.pop();
    boolean var92 = var62.empty();
    java.lang.Object var93 = var62.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1.0d)+ "'", var14.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1.0d)+ "'", var15.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + (-1)+ "'", var34.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + (-1)+ "'", var35.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + (-1)+ "'", var36.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + (-1)+ "'", var37.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + (-1.0d)+ "'", var45.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var65 + "' != '" + (-1)+ "'", var65.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var66 + "' != '" + (-1)+ "'", var66.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var68 + "' != '" + (short)(-1)+ "'", var68.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var74 + "' != '" + (short)0+ "'", var74.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var75 + "' != '" + (short)0+ "'", var75.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var91 + "' != '" + (-1)+ "'", var91.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var93 + "' != '" + (short)(-1)+ "'", var93.equals((short)(-1)));

  }

  public void test37() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test37");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var8 = var1.pop();
    br.ufal.ic.test.mystack.Stack var10 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var11 = new java.lang.Object();
    java.lang.Object var12 = var10.push(var11);
    boolean var13 = var10.empty();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var16 = new java.lang.Object();
    java.lang.Object var17 = var15.push(var16);
    java.lang.Object var18 = var10.push(var16);
    java.lang.Object var19 = var1.push((java.lang.Object)var10);
    java.lang.Object var20 = var10.pop();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var22.pop();
    java.lang.Object var26 = var10.push((java.lang.Object)var22);
    java.lang.Object var27 = var10.peek();
    java.lang.Object var28 = var10.peek();
    boolean var29 = var10.empty();
    java.lang.Object var30 = var10.pop();
    java.lang.Object var31 = var10.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test38() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test38");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(-1));
    java.lang.Object var5 = var1.peek();
    java.lang.Object var7 = var1.push((java.lang.Object)(short)(-1));
    br.ufal.ic.test.mystack.Stack var9 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var10 = new java.lang.Object();
    java.lang.Object var11 = var9.push(var10);
    java.lang.Object var12 = var9.peek();
    java.lang.Object var13 = var1.push(var12);
    java.lang.Object var14 = var1.peek();
    boolean var15 = var1.empty();
    java.lang.Object var16 = var1.peek();
    java.lang.Object var17 = var1.pop();
    boolean var18 = var1.empty();
    br.ufal.ic.test.mystack.Stack var20 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var22 = var20.push((java.lang.Object)(short)0);
    br.ufal.ic.test.mystack.Stack var24 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var25 = new java.lang.Object();
    java.lang.Object var26 = var24.push(var25);
    java.lang.Object var27 = var24.pop();
    boolean var28 = var24.empty();
    java.lang.Object var30 = var24.push((java.lang.Object)(-1.0d));
    java.lang.Object var31 = var24.pop();
    br.ufal.ic.test.mystack.Stack var33 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var34 = new java.lang.Object();
    java.lang.Object var35 = var33.push(var34);
    boolean var36 = var33.empty();
    br.ufal.ic.test.mystack.Stack var38 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var39 = new java.lang.Object();
    java.lang.Object var40 = var38.push(var39);
    java.lang.Object var41 = var33.push(var39);
    java.lang.Object var42 = var24.push((java.lang.Object)var33);
    java.lang.Object var43 = var33.pop();
    br.ufal.ic.test.mystack.Stack var45 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var46 = new java.lang.Object();
    java.lang.Object var47 = var45.push(var46);
    java.lang.Object var48 = var45.pop();
    java.lang.Object var49 = var33.push((java.lang.Object)var45);
    java.lang.Object var50 = var33.peek();
    java.lang.Object var51 = var33.peek();
    java.lang.Object var52 = var20.push(var51);
    java.lang.Object var53 = var20.peek();
    java.lang.Object var54 = var1.push(var53);
    java.lang.Object var55 = var1.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1)+ "'", var4.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1)+ "'", var5.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)(-1)+ "'", var7.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (-1)+ "'", var16.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + (-1)+ "'", var17.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + (short)0+ "'", var22.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + (-1.0d)+ "'", var30.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + (-1.0d)+ "'", var31.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + (short)0+ "'", var53.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + (short)0+ "'", var54.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + (short)(-1)+ "'", var55.equals((short)(-1)));

  }

  public void test39() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test39");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var8 = var1.pop();
    br.ufal.ic.test.mystack.Stack var10 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var11 = new java.lang.Object();
    java.lang.Object var12 = var10.push(var11);
    boolean var13 = var10.empty();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var16 = new java.lang.Object();
    java.lang.Object var17 = var15.push(var16);
    java.lang.Object var18 = var10.push(var16);
    java.lang.Object var19 = var1.push((java.lang.Object)var10);
    java.lang.Object var20 = var10.pop();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var22.pop();
    java.lang.Object var26 = var10.push((java.lang.Object)var22);
    java.lang.Object var27 = var10.peek();
    java.lang.Object var28 = var10.peek();
    boolean var29 = var10.empty();
    boolean var30 = var10.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test40() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test40");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    br.ufal.ic.test.mystack.Stack var3 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var5 = var3.push((java.lang.Object)(short)0);
    br.ufal.ic.test.mystack.Stack var7 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var8 = new java.lang.Object();
    java.lang.Object var9 = var7.push(var8);
    java.lang.Object var10 = var7.pop();
    java.lang.Object var11 = var3.push((java.lang.Object)var7);
    br.ufal.ic.test.mystack.Stack var13 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var14 = new java.lang.Object();
    java.lang.Object var15 = var13.push(var14);
    java.lang.Object var16 = var13.peek();
    java.lang.Object var17 = var7.push((java.lang.Object)var13);
    boolean var18 = var13.empty();
    java.lang.Object var19 = var1.push((java.lang.Object)var13);
    java.lang.Object var20 = var13.pop();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var22.peek();
    java.lang.Object var27 = var22.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var29 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var30 = new java.lang.Object();
    java.lang.Object var31 = var29.push(var30);
    java.lang.Object var32 = var29.pop();
    boolean var33 = var29.empty();
    java.lang.Object var35 = var29.push((java.lang.Object)(-1.0d));
    java.lang.Object var36 = var29.pop();
    br.ufal.ic.test.mystack.Stack var38 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var39 = new java.lang.Object();
    java.lang.Object var40 = var38.push(var39);
    boolean var41 = var38.empty();
    br.ufal.ic.test.mystack.Stack var43 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var44 = new java.lang.Object();
    java.lang.Object var45 = var43.push(var44);
    java.lang.Object var46 = var38.push(var44);
    java.lang.Object var47 = var29.push((java.lang.Object)var38);
    java.lang.Object var48 = var22.push((java.lang.Object)var38);
    boolean var49 = var38.empty();
    java.lang.Object var50 = var38.pop();
    java.lang.Object var51 = var38.peek();
    boolean var52 = var38.empty();
    boolean var53 = var38.empty();
    java.lang.Object var54 = var38.peek();
    java.lang.Object var55 = var13.push(var54);
    br.ufal.ic.test.mystack.Stack var57 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var58 = var57.empty();
    java.lang.Object var60 = var57.push((java.lang.Object)(-1));
    boolean var61 = var57.empty();
    boolean var62 = var57.empty();
    java.lang.Object var63 = var57.pop();
    boolean var64 = var57.empty();
    java.lang.Object var65 = var13.push((java.lang.Object)var64);
    java.lang.Object var66 = var13.pop();
    boolean var67 = var13.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)0+ "'", var5.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + (-1)+ "'", var27.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + (-1.0d)+ "'", var35.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + (-1.0d)+ "'", var36.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var60 + "' != '" + (-1)+ "'", var60.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var63 + "' != '" + (-1)+ "'", var63.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var65 + "' != '" + true+ "'", var65.equals(true));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);

  }

  public void test41() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test41");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var9 = var1.push((java.lang.Object)(-1L));
    java.lang.Object var10 = var1.pop();
    br.ufal.ic.test.mystack.Stack var12 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var13 = var12.empty();
    java.lang.Object var15 = var12.push((java.lang.Object)(-1));
    java.lang.Object var16 = var12.pop();
    boolean var17 = var12.empty();
    boolean var18 = var12.empty();
    br.ufal.ic.test.mystack.Stack var20 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var21 = var20.empty();
    java.lang.Object var22 = var12.push((java.lang.Object)var20);
    java.lang.Object var23 = var1.push((java.lang.Object)var20);
    boolean var24 = var1.empty();
    java.lang.Object var25 = var1.peek();
    java.lang.Object var26 = var1.pop();
    boolean var27 = var1.empty();
    boolean var28 = var1.empty();
    boolean var29 = var1.empty();
    java.lang.Object var30 = var1.pop();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var31 = var1.peek();
      fail("Expected exception of type java.util.EmptyStackException");
    } catch (java.util.EmptyStackException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (-1L)+ "'", var9.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (-1.0d)+ "'", var10.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1)+ "'", var15.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (-1)+ "'", var16.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + (-1L)+ "'", var25.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + (-1L)+ "'", var26.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test42() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test42");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var3 = var1.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var5 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var6 = new java.lang.Object();
    java.lang.Object var7 = var5.push(var6);
    java.lang.Object var8 = var5.peek();
    boolean var9 = var5.empty();
    java.lang.Object var10 = var5.peek();
    java.lang.Object var11 = var1.push(var10);
    java.lang.Object var12 = var1.pop();
    java.lang.Object var13 = var1.peek();
    boolean var14 = var1.empty();
    boolean var15 = var1.empty();
    boolean var16 = var1.empty();
    java.lang.Object var17 = var1.peek();
    boolean var18 = var1.empty();
    boolean var19 = var1.empty();
    java.lang.Object var20 = var1.pop();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var22.pop();
    boolean var26 = var22.empty();
    java.lang.Object var28 = var22.push((java.lang.Object)(-1.0d));
    java.lang.Object var29 = var22.pop();
    br.ufal.ic.test.mystack.Stack var31 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var32 = new java.lang.Object();
    java.lang.Object var33 = var31.push(var32);
    boolean var34 = var31.empty();
    br.ufal.ic.test.mystack.Stack var36 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var37 = new java.lang.Object();
    java.lang.Object var38 = var36.push(var37);
    java.lang.Object var39 = var31.push(var37);
    java.lang.Object var40 = var22.push((java.lang.Object)var31);
    java.lang.Object var41 = var31.pop();
    br.ufal.ic.test.mystack.Stack var43 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var44 = new java.lang.Object();
    java.lang.Object var45 = var43.push(var44);
    java.lang.Object var46 = var43.pop();
    java.lang.Object var47 = var31.push((java.lang.Object)var43);
    java.lang.Object var48 = var31.pop();
    boolean var49 = var31.empty();
    br.ufal.ic.test.mystack.Stack var51 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var53 = var51.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var55 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var56 = new java.lang.Object();
    java.lang.Object var57 = var55.push(var56);
    java.lang.Object var58 = var55.peek();
    boolean var59 = var55.empty();
    java.lang.Object var60 = var55.peek();
    java.lang.Object var61 = var51.push(var60);
    boolean var62 = var51.empty();
    java.lang.Object var63 = var51.peek();
    java.lang.Object var64 = var31.push(var63);
    java.lang.Object var65 = var1.push(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 100.0d+ "'", var3.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100.0d+ "'", var12.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + (-1.0d)+ "'", var28.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + (-1.0d)+ "'", var29.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + 100.0d+ "'", var53.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var63 + "' != '" + 100.0d+ "'", var63.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var64 + "' != '" + 100.0d+ "'", var64.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var65 + "' != '" + 100.0d+ "'", var65.equals(100.0d));

  }

  public void test43() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test43");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(-1));
    boolean var5 = var1.empty();
    boolean var6 = var1.empty();
    boolean var7 = var1.empty();
    java.lang.Object var8 = var1.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1)+ "'", var4.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1)+ "'", var8.equals((-1)));

  }

  public void test44() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test44");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var8 = var1.pop();
    br.ufal.ic.test.mystack.Stack var10 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var11 = new java.lang.Object();
    java.lang.Object var12 = var10.push(var11);
    boolean var13 = var10.empty();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var16 = new java.lang.Object();
    java.lang.Object var17 = var15.push(var16);
    java.lang.Object var18 = var10.push(var16);
    java.lang.Object var19 = var1.push((java.lang.Object)var10);
    java.lang.Object var20 = var10.pop();
    java.lang.Object var21 = var10.peek();
    java.lang.Object var22 = var10.peek();
    br.ufal.ic.test.mystack.Stack var24 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var26 = var24.push((java.lang.Object)(short)0);
    br.ufal.ic.test.mystack.Stack var28 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var29 = new java.lang.Object();
    java.lang.Object var30 = var28.push(var29);
    java.lang.Object var31 = var28.pop();
    boolean var32 = var28.empty();
    java.lang.Object var34 = var28.push((java.lang.Object)(-1.0d));
    java.lang.Object var35 = var28.pop();
    br.ufal.ic.test.mystack.Stack var37 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var38 = new java.lang.Object();
    java.lang.Object var39 = var37.push(var38);
    boolean var40 = var37.empty();
    br.ufal.ic.test.mystack.Stack var42 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var43 = new java.lang.Object();
    java.lang.Object var44 = var42.push(var43);
    java.lang.Object var45 = var37.push(var43);
    java.lang.Object var46 = var28.push((java.lang.Object)var37);
    java.lang.Object var47 = var37.pop();
    br.ufal.ic.test.mystack.Stack var49 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var50 = new java.lang.Object();
    java.lang.Object var51 = var49.push(var50);
    java.lang.Object var52 = var49.pop();
    java.lang.Object var53 = var37.push((java.lang.Object)var49);
    java.lang.Object var54 = var37.peek();
    java.lang.Object var55 = var37.peek();
    java.lang.Object var56 = var24.push(var55);
    java.lang.Object var57 = var10.push(var55);
    java.lang.Object var58 = var10.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + (short)0+ "'", var26.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + (-1.0d)+ "'", var34.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + (-1.0d)+ "'", var35.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test45() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test45");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.peek();
    java.lang.Object var6 = var1.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var8 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var9 = var8.empty();
    java.lang.Object var11 = var8.push((java.lang.Object)(-1));
    java.lang.Object var12 = var8.peek();
    java.lang.Object var14 = var8.push((java.lang.Object)(short)(-1));
    br.ufal.ic.test.mystack.Stack var16 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var17 = new java.lang.Object();
    java.lang.Object var18 = var16.push(var17);
    java.lang.Object var19 = var16.peek();
    java.lang.Object var20 = var8.push(var19);
    java.lang.Object var21 = var8.peek();
    java.lang.Object var22 = var1.push(var21);
    boolean var23 = var1.empty();
    boolean var24 = var1.empty();
    java.lang.Object var25 = var1.pop();
    br.ufal.ic.test.mystack.Stack var27 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var28 = var27.empty();
    java.lang.Object var30 = var27.push((java.lang.Object)(-1));
    java.lang.Object var31 = var27.pop();
    boolean var32 = var27.empty();
    boolean var33 = var27.empty();
    br.ufal.ic.test.mystack.Stack var35 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var36 = var35.empty();
    java.lang.Object var37 = var27.push((java.lang.Object)var35);
    br.ufal.ic.test.mystack.Stack var39 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var40 = new java.lang.Object();
    java.lang.Object var41 = var39.push(var40);
    java.lang.Object var42 = var39.pop();
    boolean var43 = var39.empty();
    java.lang.Object var45 = var39.push((java.lang.Object)(-1.0d));
    java.lang.Object var46 = var39.pop();
    br.ufal.ic.test.mystack.Stack var48 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var49 = new java.lang.Object();
    java.lang.Object var50 = var48.push(var49);
    boolean var51 = var48.empty();
    br.ufal.ic.test.mystack.Stack var53 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var54 = new java.lang.Object();
    java.lang.Object var55 = var53.push(var54);
    java.lang.Object var56 = var48.push(var54);
    java.lang.Object var57 = var39.push((java.lang.Object)var48);
    java.lang.Object var58 = var48.peek();
    java.lang.Object var59 = var48.peek();
    br.ufal.ic.test.mystack.Stack var61 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var63 = var61.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var65 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var66 = new java.lang.Object();
    java.lang.Object var67 = var65.push(var66);
    java.lang.Object var68 = var65.peek();
    boolean var69 = var65.empty();
    java.lang.Object var70 = var65.peek();
    java.lang.Object var71 = var61.push(var70);
    java.lang.Object var72 = var61.pop();
    java.lang.Object var73 = var61.peek();
    java.lang.Object var74 = var48.push((java.lang.Object)var61);
    java.lang.Object var75 = var27.push((java.lang.Object)var61);
    java.lang.Object var76 = var61.pop();
    java.lang.Object var77 = var1.push((java.lang.Object)var61);
    java.lang.Object var78 = var1.pop();
    boolean var79 = var1.empty();
    java.lang.Object var80 = var1.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (-1)+ "'", var11.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (-1)+ "'", var12.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (short)(-1)+ "'", var14.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (-1)+ "'", var21.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + (-1)+ "'", var22.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + (-1)+ "'", var30.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + (-1)+ "'", var31.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + (-1.0d)+ "'", var45.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + (-1.0d)+ "'", var46.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var63 + "' != '" + 100.0d+ "'", var63.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var72 + "' != '" + 100.0d+ "'", var72.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var78 + "' != '" + (-1)+ "'", var78.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var80 + "' != '" + (-1)+ "'", var80.equals((-1)));

  }

  public void test46() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test46");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(byte)0);
    boolean var5 = var1.empty();
    br.ufal.ic.test.mystack.Stack var7 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var8 = new java.lang.Object();
    java.lang.Object var9 = var7.push(var8);
    boolean var10 = var7.empty();
    br.ufal.ic.test.mystack.Stack var12 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var13 = new java.lang.Object();
    java.lang.Object var14 = var12.push(var13);
    java.lang.Object var15 = var7.push(var13);
    java.lang.Object var16 = var7.pop();
    java.lang.Object var17 = var7.peek();
    java.lang.Object var18 = var1.push((java.lang.Object)var7);
    java.lang.Object var20 = var1.push((java.lang.Object)0.0d);
    java.lang.Object var21 = var1.peek();
    br.ufal.ic.test.mystack.Stack var23 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var24 = new java.lang.Object();
    java.lang.Object var25 = var23.push(var24);
    java.lang.Object var26 = var23.pop();
    boolean var27 = var23.empty();
    java.lang.Object var29 = var23.push((java.lang.Object)(-1.0d));
    java.lang.Object var30 = var23.pop();
    br.ufal.ic.test.mystack.Stack var32 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var33 = new java.lang.Object();
    java.lang.Object var34 = var32.push(var33);
    boolean var35 = var32.empty();
    br.ufal.ic.test.mystack.Stack var37 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var38 = new java.lang.Object();
    java.lang.Object var39 = var37.push(var38);
    java.lang.Object var40 = var32.push(var38);
    java.lang.Object var41 = var23.push((java.lang.Object)var32);
    java.lang.Object var42 = var32.pop();
    boolean var43 = var32.empty();
    java.lang.Object var44 = var1.push((java.lang.Object)var43);
    boolean var45 = var1.empty();
    java.lang.Object var47 = var1.push((java.lang.Object)1.0d);
    br.ufal.ic.test.mystack.Stack var49 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var50 = new java.lang.Object();
    java.lang.Object var51 = var49.push(var50);
    boolean var52 = var49.empty();
    br.ufal.ic.test.mystack.Stack var54 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var55 = new java.lang.Object();
    java.lang.Object var56 = var54.push(var55);
    java.lang.Object var57 = var49.push(var55);
    boolean var58 = var49.empty();
    br.ufal.ic.test.mystack.Stack var60 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var61 = var60.empty();
    java.lang.Object var63 = var60.push((java.lang.Object)(byte)0);
    boolean var64 = var60.empty();
    br.ufal.ic.test.mystack.Stack var66 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var67 = new java.lang.Object();
    java.lang.Object var68 = var66.push(var67);
    boolean var69 = var66.empty();
    br.ufal.ic.test.mystack.Stack var71 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var72 = new java.lang.Object();
    java.lang.Object var73 = var71.push(var72);
    java.lang.Object var74 = var66.push(var72);
    java.lang.Object var75 = var66.pop();
    java.lang.Object var76 = var66.peek();
    java.lang.Object var77 = var60.push((java.lang.Object)var66);
    boolean var78 = var60.empty();
    java.lang.Object var79 = var49.push((java.lang.Object)var60);
    boolean var80 = var60.empty();
    boolean var81 = var60.empty();
    java.lang.Object var82 = var1.push((java.lang.Object)var60);
    boolean var83 = var60.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)0+ "'", var4.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + 0.0d+ "'", var20.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (byte)0+ "'", var21.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + (-1.0d)+ "'", var29.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + (-1.0d)+ "'", var30.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + false+ "'", var44.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + 1.0d+ "'", var47.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var63 + "' != '" + (byte)0+ "'", var63.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);

  }

  public void test47() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test47");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    boolean var4 = var1.empty();
    br.ufal.ic.test.mystack.Stack var6 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var7 = new java.lang.Object();
    java.lang.Object var8 = var6.push(var7);
    java.lang.Object var9 = var1.push(var7);
    java.lang.Object var10 = var1.pop();
    java.lang.Object var11 = var1.peek();
    br.ufal.ic.test.mystack.Stack var13 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var14 = new java.lang.Object();
    java.lang.Object var15 = var13.push(var14);
    boolean var16 = var13.empty();
    br.ufal.ic.test.mystack.Stack var18 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var19 = new java.lang.Object();
    java.lang.Object var20 = var18.push(var19);
    java.lang.Object var21 = var13.push(var19);
    boolean var22 = var13.empty();
    br.ufal.ic.test.mystack.Stack var24 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var25 = new java.lang.Object();
    java.lang.Object var26 = var24.push(var25);
    java.lang.Object var27 = var24.pop();
    boolean var28 = var24.empty();
    java.lang.Object var30 = var24.push((java.lang.Object)(-1.0d));
    boolean var31 = var24.empty();
    boolean var32 = var24.empty();
    java.lang.Object var33 = var13.push((java.lang.Object)var32);
    java.lang.Object var34 = var1.push((java.lang.Object)var13);
    br.ufal.ic.test.mystack.Stack var36 = new br.ufal.ic.test.mystack.Stack(10);
    java.lang.Object var37 = var1.push((java.lang.Object)10);
    br.ufal.ic.test.mystack.Stack var39 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var40 = var39.empty();
    java.lang.Object var42 = var39.push((java.lang.Object)"hi!");
    java.lang.Object var43 = var39.peek();
    java.lang.Object var44 = var1.push(var43);
    br.ufal.ic.test.mystack.Stack var46 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var47 = new java.lang.Object();
    java.lang.Object var48 = var46.push(var47);
    java.lang.Object var49 = var46.peek();
    boolean var50 = var46.empty();
    java.lang.Object var51 = var46.peek();
    java.lang.Object var52 = var46.peek();
    java.lang.Object var53 = var46.peek();
    java.lang.Object var54 = var46.peek();
    boolean var55 = var46.empty();
    java.lang.Object var56 = var1.push((java.lang.Object)var55);
    boolean var57 = var1.empty();
    boolean var58 = var1.empty();
    boolean var59 = var1.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + (-1.0d)+ "'", var30.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + false+ "'", var33.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + 10+ "'", var37.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "hi!"+ "'", var42.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "hi!"+ "'", var43.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "hi!"+ "'", var44.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var56 + "' != '" + false+ "'", var56.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);

  }

  public void test48() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test48");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.peek();
    java.lang.Object var5 = var1.pop();
    java.lang.Object var7 = var1.push((java.lang.Object)false);
    java.lang.Object var9 = var1.push((java.lang.Object)0);
    boolean var10 = var1.empty();
    br.ufal.ic.test.mystack.Stack var12 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var14 = var12.push((java.lang.Object)(short)0);
    br.ufal.ic.test.mystack.Stack var16 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var17 = new java.lang.Object();
    java.lang.Object var18 = var16.push(var17);
    java.lang.Object var19 = var16.pop();
    java.lang.Object var20 = var12.push((java.lang.Object)var16);
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var22.peek();
    java.lang.Object var26 = var16.push((java.lang.Object)var22);
    br.ufal.ic.test.mystack.Stack var28 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var29 = new java.lang.Object();
    java.lang.Object var30 = var28.push(var29);
    boolean var31 = var28.empty();
    br.ufal.ic.test.mystack.Stack var33 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var34 = new java.lang.Object();
    java.lang.Object var35 = var33.push(var34);
    java.lang.Object var36 = var28.push(var34);
    java.lang.Object var37 = var16.push(var36);
    br.ufal.ic.test.mystack.Stack var39 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var40 = var39.empty();
    java.lang.Object var42 = var39.push((java.lang.Object)"hi!");
    br.ufal.ic.test.mystack.Stack var44 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var45 = new java.lang.Object();
    java.lang.Object var46 = var44.push(var45);
    java.lang.Object var47 = var44.pop();
    boolean var48 = var44.empty();
    java.lang.Object var50 = var44.push((java.lang.Object)(-1.0d));
    java.lang.Object var52 = var44.push((java.lang.Object)(-1L));
    java.lang.Object var53 = var39.push(var52);
    java.lang.Object var54 = var39.pop();
    java.lang.Object var55 = var39.pop();
    br.ufal.ic.test.mystack.Stack var57 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var58 = new java.lang.Object();
    java.lang.Object var59 = var57.push(var58);
    java.lang.Object var60 = var57.peek();
    java.lang.Object var62 = var57.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var64 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var65 = var64.empty();
    java.lang.Object var67 = var64.push((java.lang.Object)(-1));
    java.lang.Object var68 = var64.peek();
    java.lang.Object var70 = var64.push((java.lang.Object)(short)(-1));
    br.ufal.ic.test.mystack.Stack var72 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var73 = new java.lang.Object();
    java.lang.Object var74 = var72.push(var73);
    java.lang.Object var75 = var72.peek();
    java.lang.Object var76 = var64.push(var75);
    java.lang.Object var77 = var64.peek();
    java.lang.Object var78 = var57.push(var77);
    boolean var79 = var57.empty();
    boolean var80 = var57.empty();
    java.lang.Object var81 = var57.peek();
    java.lang.Object var82 = var39.push(var81);
    java.lang.Object var83 = var39.peek();
    java.lang.Object var84 = var39.peek();
    java.lang.Object var85 = var16.push((java.lang.Object)var39);
    java.lang.Object var86 = var1.push(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + false+ "'", var7.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 0+ "'", var9.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (short)0+ "'", var14.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "hi!"+ "'", var42.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var50 + "' != '" + (-1.0d)+ "'", var50.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var52 + "' != '" + (-1L)+ "'", var52.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + (-1L)+ "'", var53.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + "hi!"+ "'", var54.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + (-1L)+ "'", var55.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var62 + "' != '" + (-1)+ "'", var62.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var67 + "' != '" + (-1)+ "'", var67.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var68 + "' != '" + (-1)+ "'", var68.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var70 + "' != '" + (short)(-1)+ "'", var70.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var77 + "' != '" + (-1)+ "'", var77.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var78 + "' != '" + (-1)+ "'", var78.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);

  }

  public void test49() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test49");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var8 = var1.pop();
    br.ufal.ic.test.mystack.Stack var10 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var11 = new java.lang.Object();
    java.lang.Object var12 = var10.push(var11);
    boolean var13 = var10.empty();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var16 = new java.lang.Object();
    java.lang.Object var17 = var15.push(var16);
    java.lang.Object var18 = var10.push(var16);
    java.lang.Object var19 = var1.push((java.lang.Object)var10);
    java.lang.Object var20 = var10.pop();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var22.pop();
    java.lang.Object var26 = var10.push((java.lang.Object)var22);
    br.ufal.ic.test.mystack.Stack var28 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var29 = new java.lang.Object();
    java.lang.Object var30 = var28.push(var29);
    java.lang.Object var31 = var28.peek();
    java.lang.Object var33 = var28.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var35 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var36 = new java.lang.Object();
    java.lang.Object var37 = var35.push(var36);
    java.lang.Object var38 = var35.pop();
    boolean var39 = var35.empty();
    java.lang.Object var41 = var35.push((java.lang.Object)(-1.0d));
    java.lang.Object var42 = var35.pop();
    br.ufal.ic.test.mystack.Stack var44 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var45 = new java.lang.Object();
    java.lang.Object var46 = var44.push(var45);
    boolean var47 = var44.empty();
    br.ufal.ic.test.mystack.Stack var49 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var50 = new java.lang.Object();
    java.lang.Object var51 = var49.push(var50);
    java.lang.Object var52 = var44.push(var50);
    java.lang.Object var53 = var35.push((java.lang.Object)var44);
    java.lang.Object var54 = var28.push((java.lang.Object)var44);
    java.lang.Object var55 = var22.push(var54);
    java.lang.Object var56 = var22.pop();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var57 = var22.pop();
      fail("Expected exception of type java.util.EmptyStackException");
    } catch (java.util.EmptyStackException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + (-1)+ "'", var33.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + (-1.0d)+ "'", var41.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + (-1.0d)+ "'", var42.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test50() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test50");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var3 = var1.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var5 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var6 = new java.lang.Object();
    java.lang.Object var7 = var5.push(var6);
    java.lang.Object var8 = var5.peek();
    boolean var9 = var5.empty();
    java.lang.Object var10 = var5.peek();
    java.lang.Object var11 = var1.push(var10);
    boolean var12 = var1.empty();
    br.ufal.ic.test.mystack.Stack var14 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var15 = new java.lang.Object();
    java.lang.Object var16 = var14.push(var15);
    java.lang.Object var17 = var1.push((java.lang.Object)var14);
    java.lang.Object var18 = var1.peek();
    java.lang.Object var19 = var1.pop();
    boolean var20 = var1.empty();
    java.lang.Object var21 = var1.peek();
    boolean var22 = var1.empty();
    java.lang.Object var23 = var1.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 100.0d+ "'", var3.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + 100.0d+ "'", var18.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + 100.0d+ "'", var19.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test51() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test51");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    boolean var4 = var1.empty();
    br.ufal.ic.test.mystack.Stack var6 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var7 = new java.lang.Object();
    java.lang.Object var8 = var6.push(var7);
    java.lang.Object var9 = var1.push(var7);
    java.lang.Object var10 = var1.pop();
    java.lang.Object var11 = var1.peek();
    br.ufal.ic.test.mystack.Stack var13 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var14 = new java.lang.Object();
    java.lang.Object var15 = var13.push(var14);
    boolean var16 = var13.empty();
    br.ufal.ic.test.mystack.Stack var18 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var19 = new java.lang.Object();
    java.lang.Object var20 = var18.push(var19);
    java.lang.Object var21 = var13.push(var19);
    boolean var22 = var13.empty();
    br.ufal.ic.test.mystack.Stack var24 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var25 = new java.lang.Object();
    java.lang.Object var26 = var24.push(var25);
    java.lang.Object var27 = var24.pop();
    boolean var28 = var24.empty();
    java.lang.Object var30 = var24.push((java.lang.Object)(-1.0d));
    boolean var31 = var24.empty();
    boolean var32 = var24.empty();
    java.lang.Object var33 = var13.push((java.lang.Object)var32);
    java.lang.Object var34 = var1.push((java.lang.Object)var13);
    java.lang.Object var35 = var13.peek();
    boolean var36 = var13.empty();
    java.lang.Object var37 = var13.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + (-1.0d)+ "'", var30.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + false+ "'", var33.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test52() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test52");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var9 = var1.push((java.lang.Object)(-1L));
    br.ufal.ic.test.mystack.Stack var11 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var12 = new java.lang.Object();
    java.lang.Object var13 = var11.push(var12);
    java.lang.Object var14 = var11.peek();
    java.lang.Object var15 = var11.pop();
    java.lang.Object var16 = var1.push(var15);
    java.lang.Object var17 = var1.pop();
    java.lang.Object var18 = var1.pop();
    java.lang.Object var19 = var1.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (-1L)+ "'", var9.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + (-1.0d)+ "'", var17.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + (-1L)+ "'", var18.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test53() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test53");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    boolean var4 = var1.empty();
    br.ufal.ic.test.mystack.Stack var6 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var7 = new java.lang.Object();
    java.lang.Object var8 = var6.push(var7);
    java.lang.Object var9 = var1.push(var7);
    boolean var10 = var1.empty();
    br.ufal.ic.test.mystack.Stack var12 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var13 = new java.lang.Object();
    java.lang.Object var14 = var12.push(var13);
    java.lang.Object var15 = var12.pop();
    boolean var16 = var12.empty();
    java.lang.Object var18 = var12.push((java.lang.Object)(-1.0d));
    boolean var19 = var12.empty();
    boolean var20 = var12.empty();
    java.lang.Object var21 = var1.push((java.lang.Object)var20);
    java.lang.Object var22 = var1.pop();
    java.lang.Object var23 = var1.pop();
    br.ufal.ic.test.mystack.Stack var25 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var26 = var25.empty();
    java.lang.Object var28 = var25.push((java.lang.Object)(-1));
    java.lang.Object var29 = var25.peek();
    java.lang.Object var30 = var25.peek();
    java.lang.Object var32 = var25.push((java.lang.Object)10.0f);
    java.lang.Object var33 = var25.pop();
    boolean var34 = var25.empty();
    boolean var35 = var25.empty();
    br.ufal.ic.test.mystack.Stack var37 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var38 = var37.empty();
    java.lang.Object var40 = var37.push((java.lang.Object)(byte)0);
    br.ufal.ic.test.mystack.Stack var42 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var44 = var42.push((java.lang.Object)(short)0);
    br.ufal.ic.test.mystack.Stack var46 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var47 = new java.lang.Object();
    java.lang.Object var48 = var46.push(var47);
    java.lang.Object var49 = var46.pop();
    java.lang.Object var50 = var42.push((java.lang.Object)var46);
    java.lang.Object var51 = var37.push((java.lang.Object)var42);
    br.ufal.ic.test.mystack.Stack var53 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var54 = new java.lang.Object();
    java.lang.Object var55 = var53.push(var54);
    boolean var56 = var53.empty();
    br.ufal.ic.test.mystack.Stack var58 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var59 = new java.lang.Object();
    java.lang.Object var60 = var58.push(var59);
    java.lang.Object var61 = var53.push(var59);
    java.lang.Object var62 = var53.pop();
    java.lang.Object var63 = var53.pop();
    java.lang.Object var64 = var42.push(var63);
    br.ufal.ic.test.mystack.Stack var66 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var67 = var66.empty();
    java.lang.Object var69 = var66.push((java.lang.Object)(-1));
    java.lang.Object var70 = var66.pop();
    java.lang.Object var71 = var42.push((java.lang.Object)var66);
    java.lang.Object var72 = var25.push((java.lang.Object)var66);
    java.lang.Object var73 = var25.pop();
    java.lang.Object var74 = var1.push(var73);
    boolean var75 = var1.empty();
    java.lang.Object var76 = var1.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + (-1.0d)+ "'", var18.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + false+ "'", var21.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + (-1)+ "'", var28.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + (-1)+ "'", var29.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + (-1)+ "'", var30.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + 10.0f+ "'", var32.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + (-1)+ "'", var33.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var40 + "' != '" + (byte)0+ "'", var40.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + (short)0+ "'", var44.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var69 + "' != '" + (-1)+ "'", var69.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var70 + "' != '" + (-1)+ "'", var70.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var73 + "' != '" + 10.0f+ "'", var73.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var74 + "' != '" + 10.0f+ "'", var74.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var76 + "' != '" + false+ "'", var76.equals(false));

  }

  public void test54() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test54");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var3 = var1.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var5 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var6 = new java.lang.Object();
    java.lang.Object var7 = var5.push(var6);
    java.lang.Object var8 = var5.peek();
    boolean var9 = var5.empty();
    java.lang.Object var10 = var5.peek();
    java.lang.Object var11 = var1.push(var10);
    java.lang.Object var12 = var1.peek();
    br.ufal.ic.test.mystack.Stack var14 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var15 = new java.lang.Object();
    java.lang.Object var16 = var14.push(var15);
    java.lang.Object var17 = var14.peek();
    java.lang.Object var19 = var14.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var21 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var22 = new java.lang.Object();
    java.lang.Object var23 = var21.push(var22);
    java.lang.Object var24 = var21.pop();
    boolean var25 = var21.empty();
    java.lang.Object var27 = var21.push((java.lang.Object)(-1.0d));
    java.lang.Object var28 = var21.pop();
    br.ufal.ic.test.mystack.Stack var30 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var31 = new java.lang.Object();
    java.lang.Object var32 = var30.push(var31);
    boolean var33 = var30.empty();
    br.ufal.ic.test.mystack.Stack var35 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var36 = new java.lang.Object();
    java.lang.Object var37 = var35.push(var36);
    java.lang.Object var38 = var30.push(var36);
    java.lang.Object var39 = var21.push((java.lang.Object)var30);
    java.lang.Object var40 = var14.push((java.lang.Object)var30);
    java.lang.Object var41 = var1.push((java.lang.Object)var30);
    boolean var42 = var1.empty();
    boolean var43 = var1.empty();
    boolean var44 = var1.empty();
    java.lang.Object var45 = var1.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 100.0d+ "'", var3.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100.0d+ "'", var12.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + (-1)+ "'", var19.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + (-1.0d)+ "'", var27.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + (-1.0d)+ "'", var28.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + 100.0d+ "'", var45.equals(100.0d));

  }

  public void test55() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test55");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(byte)0);
    boolean var5 = var1.empty();
    br.ufal.ic.test.mystack.Stack var7 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var8 = new java.lang.Object();
    java.lang.Object var9 = var7.push(var8);
    boolean var10 = var7.empty();
    br.ufal.ic.test.mystack.Stack var12 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var13 = new java.lang.Object();
    java.lang.Object var14 = var12.push(var13);
    java.lang.Object var15 = var7.push(var13);
    java.lang.Object var16 = var7.pop();
    java.lang.Object var17 = var7.peek();
    java.lang.Object var18 = var1.push((java.lang.Object)var7);
    java.lang.Object var20 = var1.push((java.lang.Object)0.0d);
    java.lang.Object var21 = var1.peek();
    java.lang.Object var22 = var1.peek();
    boolean var23 = var1.empty();
    boolean var24 = var1.empty();
    java.lang.Object var25 = var1.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)0+ "'", var4.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + 0.0d+ "'", var20.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (byte)0+ "'", var21.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + (byte)0+ "'", var22.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + (byte)0+ "'", var25.equals((byte)0));

  }

  public void test56() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test56");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var3 = var1.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var5 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var6 = new java.lang.Object();
    java.lang.Object var7 = var5.push(var6);
    java.lang.Object var8 = var5.peek();
    boolean var9 = var5.empty();
    java.lang.Object var10 = var5.peek();
    java.lang.Object var11 = var1.push(var10);
    java.lang.Object var12 = var1.peek();
    br.ufal.ic.test.mystack.Stack var14 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var15 = new java.lang.Object();
    java.lang.Object var16 = var14.push(var15);
    java.lang.Object var17 = var14.peek();
    java.lang.Object var19 = var14.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var21 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var22 = new java.lang.Object();
    java.lang.Object var23 = var21.push(var22);
    java.lang.Object var24 = var21.pop();
    boolean var25 = var21.empty();
    java.lang.Object var27 = var21.push((java.lang.Object)(-1.0d));
    java.lang.Object var28 = var21.pop();
    br.ufal.ic.test.mystack.Stack var30 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var31 = new java.lang.Object();
    java.lang.Object var32 = var30.push(var31);
    boolean var33 = var30.empty();
    br.ufal.ic.test.mystack.Stack var35 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var36 = new java.lang.Object();
    java.lang.Object var37 = var35.push(var36);
    java.lang.Object var38 = var30.push(var36);
    java.lang.Object var39 = var21.push((java.lang.Object)var30);
    java.lang.Object var40 = var14.push((java.lang.Object)var30);
    java.lang.Object var41 = var1.push((java.lang.Object)var30);
    java.lang.Object var42 = var1.peek();
    java.lang.Object var43 = var1.pop();
    br.ufal.ic.test.mystack.Stack var45 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var46 = new java.lang.Object();
    java.lang.Object var47 = var45.push(var46);
    java.lang.Object var48 = var45.pop();
    boolean var49 = var45.empty();
    java.lang.Object var51 = var45.push((java.lang.Object)(-1.0d));
    java.lang.Object var52 = var45.pop();
    br.ufal.ic.test.mystack.Stack var54 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var55 = new java.lang.Object();
    java.lang.Object var56 = var54.push(var55);
    boolean var57 = var54.empty();
    br.ufal.ic.test.mystack.Stack var59 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var60 = new java.lang.Object();
    java.lang.Object var61 = var59.push(var60);
    java.lang.Object var62 = var54.push(var60);
    java.lang.Object var63 = var45.push((java.lang.Object)var54);
    java.lang.Object var64 = var54.pop();
    br.ufal.ic.test.mystack.Stack var66 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var67 = new java.lang.Object();
    java.lang.Object var68 = var66.push(var67);
    java.lang.Object var69 = var66.pop();
    java.lang.Object var70 = var54.push((java.lang.Object)var66);
    br.ufal.ic.test.mystack.Stack var72 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var73 = var72.empty();
    java.lang.Object var75 = var72.push((java.lang.Object)(-1));
    java.lang.Object var76 = var72.pop();
    br.ufal.ic.test.mystack.Stack var78 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var80 = var78.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var82 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var83 = new java.lang.Object();
    java.lang.Object var84 = var82.push(var83);
    java.lang.Object var85 = var82.peek();
    boolean var86 = var82.empty();
    java.lang.Object var87 = var82.peek();
    java.lang.Object var88 = var78.push(var87);
    java.lang.Object var89 = var72.push(var88);
    java.lang.Object var90 = var66.push(var89);
    boolean var91 = var66.empty();
    java.lang.Object var92 = var1.push((java.lang.Object)var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 100.0d+ "'", var3.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100.0d+ "'", var12.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + (-1)+ "'", var19.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + (-1.0d)+ "'", var27.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + (-1.0d)+ "'", var28.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + 100.0d+ "'", var42.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + 100.0d+ "'", var43.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + (-1.0d)+ "'", var51.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var52 + "' != '" + (-1.0d)+ "'", var52.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var75 + "' != '" + (-1)+ "'", var75.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var76 + "' != '" + (-1)+ "'", var76.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var80 + "' != '" + 100.0d+ "'", var80.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var92 + "' != '" + false+ "'", var92.equals(false));

  }

  public void test57() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test57");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(-1));
    java.lang.Object var5 = var1.peek();
    java.lang.Object var6 = var1.peek();
    java.lang.Object var8 = var1.push((java.lang.Object)10.0f);
    java.lang.Object var9 = var1.pop();
    boolean var10 = var1.empty();
    boolean var11 = var1.empty();
    br.ufal.ic.test.mystack.Stack var13 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var14 = var13.empty();
    br.ufal.ic.test.mystack.Stack var16 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var17 = var16.empty();
    java.lang.Object var19 = var16.push((java.lang.Object)(-1));
    java.lang.Object var20 = var13.push((java.lang.Object)(-1));
    boolean var21 = var13.empty();
    java.lang.Object var22 = var13.pop();
    br.ufal.ic.test.mystack.Stack var24 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var25 = new java.lang.Object();
    java.lang.Object var26 = var24.push(var25);
    java.lang.Object var27 = var24.pop();
    boolean var28 = var24.empty();
    java.lang.Object var30 = var24.push((java.lang.Object)(-1.0d));
    java.lang.Object var31 = var24.pop();
    br.ufal.ic.test.mystack.Stack var33 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var34 = new java.lang.Object();
    java.lang.Object var35 = var33.push(var34);
    boolean var36 = var33.empty();
    br.ufal.ic.test.mystack.Stack var38 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var39 = new java.lang.Object();
    java.lang.Object var40 = var38.push(var39);
    java.lang.Object var41 = var33.push(var39);
    java.lang.Object var42 = var24.push((java.lang.Object)var33);
    java.lang.Object var43 = var33.pop();
    br.ufal.ic.test.mystack.Stack var45 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var46 = new java.lang.Object();
    java.lang.Object var47 = var45.push(var46);
    java.lang.Object var48 = var45.pop();
    java.lang.Object var49 = var33.push((java.lang.Object)var45);
    java.lang.Object var50 = var33.peek();
    java.lang.Object var51 = var33.peek();
    java.lang.Object var52 = var13.push((java.lang.Object)var33);
    java.lang.Object var53 = var33.pop();
    java.lang.Object var54 = var33.pop();
    java.lang.Object var55 = var1.push(var54);
    br.ufal.ic.test.mystack.Stack var57 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var59 = var57.push((java.lang.Object)(short)0);
    java.lang.Object var60 = var57.pop();
    br.ufal.ic.test.mystack.Stack var62 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var63 = new java.lang.Object();
    java.lang.Object var64 = var62.push(var63);
    boolean var65 = var62.empty();
    br.ufal.ic.test.mystack.Stack var67 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var68 = new java.lang.Object();
    java.lang.Object var69 = var67.push(var68);
    java.lang.Object var70 = var62.push(var68);
    java.lang.Object var71 = var62.pop();
    java.lang.Object var72 = var62.peek();
    java.lang.Object var73 = var57.push((java.lang.Object)var62);
    java.lang.Object var74 = var57.peek();
    java.lang.Object var75 = var1.push(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1)+ "'", var4.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1)+ "'", var5.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10.0f+ "'", var8.equals(10.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (-1)+ "'", var9.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + (-1)+ "'", var19.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + (-1)+ "'", var20.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + (-1)+ "'", var22.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + (-1.0d)+ "'", var30.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + (-1.0d)+ "'", var31.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var59 + "' != '" + (short)0+ "'", var59.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var60 + "' != '" + (short)0+ "'", var60.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test58() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test58");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(-1));
    java.lang.Object var5 = var1.pop();
    boolean var6 = var1.empty();
    java.lang.Object var8 = var1.push((java.lang.Object)"");
    java.lang.Object var9 = var1.peek();
    boolean var10 = var1.empty();
    br.ufal.ic.test.mystack.Stack var12 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var13 = new java.lang.Object();
    java.lang.Object var14 = var12.push(var13);
    boolean var15 = var12.empty();
    boolean var16 = var12.empty();
    br.ufal.ic.test.mystack.Stack var18 = new br.ufal.ic.test.mystack.Stack(1);
    java.lang.Object var19 = var12.push((java.lang.Object)1);
    java.lang.Object var20 = var12.peek();
    java.lang.Object var21 = var1.push((java.lang.Object)var12);
    boolean var22 = var12.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1)+ "'", var4.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1)+ "'", var5.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + ""+ "'", var8.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + ""+ "'", var9.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + 1+ "'", var19.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test59() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test59");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.peek();
    java.lang.Object var6 = var1.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var8 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var9 = new java.lang.Object();
    java.lang.Object var10 = var8.push(var9);
    java.lang.Object var11 = var8.pop();
    boolean var12 = var8.empty();
    java.lang.Object var14 = var8.push((java.lang.Object)(-1.0d));
    java.lang.Object var15 = var8.pop();
    br.ufal.ic.test.mystack.Stack var17 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var18 = new java.lang.Object();
    java.lang.Object var19 = var17.push(var18);
    boolean var20 = var17.empty();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var17.push(var23);
    java.lang.Object var26 = var8.push((java.lang.Object)var17);
    java.lang.Object var27 = var1.push((java.lang.Object)var17);
    boolean var28 = var17.empty();
    br.ufal.ic.test.mystack.Stack var30 = new br.ufal.ic.test.mystack.Stack(0);
    java.lang.Object var31 = var17.push((java.lang.Object)var30);
    boolean var32 = var17.empty();
    java.lang.Object var33 = var17.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1.0d)+ "'", var14.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1.0d)+ "'", var15.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test60() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test60");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var3 = var1.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var5 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var6 = new java.lang.Object();
    java.lang.Object var7 = var5.push(var6);
    java.lang.Object var8 = var5.peek();
    boolean var9 = var5.empty();
    java.lang.Object var10 = var5.peek();
    java.lang.Object var11 = var1.push(var10);
    java.lang.Object var12 = var1.pop();
    java.lang.Object var13 = var1.peek();
    boolean var14 = var1.empty();
    boolean var15 = var1.empty();
    java.lang.Object var16 = var1.peek();
    boolean var17 = var1.empty();
    boolean var18 = var1.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 100.0d+ "'", var3.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100.0d+ "'", var12.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test61() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test61");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var3 = var1.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var5 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var6 = new java.lang.Object();
    java.lang.Object var7 = var5.push(var6);
    java.lang.Object var8 = var5.peek();
    boolean var9 = var5.empty();
    java.lang.Object var10 = var5.peek();
    java.lang.Object var11 = var1.push(var10);
    boolean var12 = var1.empty();
    br.ufal.ic.test.mystack.Stack var14 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var15 = new java.lang.Object();
    java.lang.Object var16 = var14.push(var15);
    java.lang.Object var17 = var1.push((java.lang.Object)var14);
    java.lang.Object var18 = var1.peek();
    java.lang.Object var19 = var1.pop();
    boolean var20 = var1.empty();
    java.lang.Object var21 = var1.peek();
    java.lang.Object var22 = var1.pop();
    boolean var23 = var1.empty();
    java.lang.Object var24 = var1.peek();
    java.lang.Object var25 = var1.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 100.0d+ "'", var3.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + 100.0d+ "'", var18.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + 100.0d+ "'", var19.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test62() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test62");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(-1));
    java.lang.Object var5 = var1.peek();
    java.lang.Object var6 = var1.peek();
    boolean var7 = var1.empty();
    br.ufal.ic.test.mystack.Stack var9 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var10 = var9.empty();
    java.lang.Object var12 = var9.push((java.lang.Object)(-1));
    boolean var13 = var9.empty();
    java.lang.Object var14 = var1.push((java.lang.Object)var9);
    boolean var15 = var1.empty();
    boolean var16 = var1.empty();
    br.ufal.ic.test.mystack.Stack var18 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var19 = var18.empty();
    br.ufal.ic.test.mystack.Stack var21 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var22 = var21.empty();
    java.lang.Object var24 = var21.push((java.lang.Object)(-1));
    java.lang.Object var25 = var18.push((java.lang.Object)(-1));
    boolean var26 = var18.empty();
    java.lang.Object var27 = var1.push((java.lang.Object)var18);
    br.ufal.ic.test.mystack.Stack var29 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var30 = new java.lang.Object();
    java.lang.Object var31 = var29.push(var30);
    boolean var32 = var29.empty();
    br.ufal.ic.test.mystack.Stack var34 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var35 = new java.lang.Object();
    java.lang.Object var36 = var34.push(var35);
    java.lang.Object var37 = var29.push(var35);
    boolean var38 = var29.empty();
    br.ufal.ic.test.mystack.Stack var40 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var41 = new java.lang.Object();
    java.lang.Object var42 = var40.push(var41);
    java.lang.Object var43 = var40.pop();
    boolean var44 = var40.empty();
    java.lang.Object var46 = var40.push((java.lang.Object)(-1.0d));
    boolean var47 = var40.empty();
    boolean var48 = var40.empty();
    java.lang.Object var49 = var29.push((java.lang.Object)var48);
    java.lang.Object var50 = var1.push((java.lang.Object)var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1)+ "'", var4.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1)+ "'", var5.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (-1)+ "'", var12.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (-1)+ "'", var24.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + (-1)+ "'", var25.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + (-1.0d)+ "'", var46.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + false+ "'", var49.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test63() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test63");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    br.ufal.ic.test.mystack.Stack var4 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var5 = var4.empty();
    java.lang.Object var7 = var4.push((java.lang.Object)(-1));
    java.lang.Object var8 = var1.push((java.lang.Object)(-1));
    boolean var9 = var1.empty();
    java.lang.Object var10 = var1.pop();
    br.ufal.ic.test.mystack.Stack var12 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var13 = new java.lang.Object();
    java.lang.Object var14 = var12.push(var13);
    java.lang.Object var15 = var12.pop();
    boolean var16 = var12.empty();
    java.lang.Object var18 = var12.push((java.lang.Object)(-1.0d));
    java.lang.Object var19 = var12.pop();
    br.ufal.ic.test.mystack.Stack var21 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var22 = new java.lang.Object();
    java.lang.Object var23 = var21.push(var22);
    boolean var24 = var21.empty();
    br.ufal.ic.test.mystack.Stack var26 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var27 = new java.lang.Object();
    java.lang.Object var28 = var26.push(var27);
    java.lang.Object var29 = var21.push(var27);
    java.lang.Object var30 = var12.push((java.lang.Object)var21);
    java.lang.Object var31 = var21.pop();
    br.ufal.ic.test.mystack.Stack var33 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var34 = new java.lang.Object();
    java.lang.Object var35 = var33.push(var34);
    java.lang.Object var36 = var33.pop();
    java.lang.Object var37 = var21.push((java.lang.Object)var33);
    java.lang.Object var38 = var21.peek();
    java.lang.Object var39 = var21.peek();
    java.lang.Object var40 = var1.push((java.lang.Object)var21);
    java.lang.Object var41 = var21.pop();
    java.lang.Object var42 = var21.pop();
    br.ufal.ic.test.mystack.Stack var44 = new br.ufal.ic.test.mystack.Stack(100);
    br.ufal.ic.test.mystack.Stack var46 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var48 = var46.push((java.lang.Object)(short)0);
    br.ufal.ic.test.mystack.Stack var50 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var51 = new java.lang.Object();
    java.lang.Object var52 = var50.push(var51);
    java.lang.Object var53 = var50.pop();
    java.lang.Object var54 = var46.push((java.lang.Object)var50);
    br.ufal.ic.test.mystack.Stack var56 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var57 = new java.lang.Object();
    java.lang.Object var58 = var56.push(var57);
    java.lang.Object var59 = var56.peek();
    java.lang.Object var60 = var50.push((java.lang.Object)var56);
    boolean var61 = var56.empty();
    java.lang.Object var62 = var44.push((java.lang.Object)var56);
    boolean var63 = var44.empty();
    java.lang.Object var64 = var21.push((java.lang.Object)var44);
    java.lang.Object var65 = var21.peek();
    java.lang.Object var66 = var21.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1)+ "'", var7.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1)+ "'", var8.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (-1)+ "'", var10.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + (-1.0d)+ "'", var18.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + (-1.0d)+ "'", var19.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + (short)0+ "'", var48.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test64() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test64");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(byte)0);
    boolean var5 = var1.empty();
    br.ufal.ic.test.mystack.Stack var7 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var8 = new java.lang.Object();
    java.lang.Object var9 = var7.push(var8);
    boolean var10 = var7.empty();
    br.ufal.ic.test.mystack.Stack var12 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var13 = new java.lang.Object();
    java.lang.Object var14 = var12.push(var13);
    java.lang.Object var15 = var7.push(var13);
    java.lang.Object var16 = var7.pop();
    java.lang.Object var17 = var7.peek();
    java.lang.Object var18 = var1.push((java.lang.Object)var7);
    java.lang.Object var20 = var1.push((java.lang.Object)0.0d);
    java.lang.Object var21 = var1.peek();
    java.lang.Object var22 = var1.peek();
    boolean var23 = var1.empty();
    boolean var24 = var1.empty();
    br.ufal.ic.test.mystack.Stack var26 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var27 = new java.lang.Object();
    java.lang.Object var28 = var26.push(var27);
    java.lang.Object var29 = var26.pop();
    boolean var30 = var26.empty();
    java.lang.Object var32 = var26.push((java.lang.Object)(-1.0d));
    java.lang.Object var33 = var26.pop();
    br.ufal.ic.test.mystack.Stack var35 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var36 = new java.lang.Object();
    java.lang.Object var37 = var35.push(var36);
    boolean var38 = var35.empty();
    br.ufal.ic.test.mystack.Stack var40 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var41 = new java.lang.Object();
    java.lang.Object var42 = var40.push(var41);
    java.lang.Object var43 = var35.push(var41);
    java.lang.Object var44 = var26.push((java.lang.Object)var35);
    java.lang.Object var45 = var35.pop();
    br.ufal.ic.test.mystack.Stack var47 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var48 = new java.lang.Object();
    java.lang.Object var49 = var47.push(var48);
    java.lang.Object var50 = var47.pop();
    java.lang.Object var51 = var35.push((java.lang.Object)var47);
    java.lang.Object var52 = var35.pop();
    java.lang.Object var53 = var1.push((java.lang.Object)var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)0+ "'", var4.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + 0.0d+ "'", var20.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (byte)0+ "'", var21.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + (byte)0+ "'", var22.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + (-1.0d)+ "'", var32.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + (-1.0d)+ "'", var33.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test65() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test65");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(byte)0);
    boolean var5 = var1.empty();
    br.ufal.ic.test.mystack.Stack var7 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var8 = new java.lang.Object();
    java.lang.Object var9 = var7.push(var8);
    boolean var10 = var7.empty();
    br.ufal.ic.test.mystack.Stack var12 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var13 = new java.lang.Object();
    java.lang.Object var14 = var12.push(var13);
    java.lang.Object var15 = var7.push(var13);
    java.lang.Object var16 = var7.pop();
    java.lang.Object var17 = var7.peek();
    java.lang.Object var18 = var1.push((java.lang.Object)var7);
    java.lang.Object var20 = var1.push((java.lang.Object)0.0d);
    java.lang.Object var21 = var1.peek();
    java.lang.Object var22 = var1.peek();
    boolean var23 = var1.empty();
    br.ufal.ic.test.mystack.Stack var25 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var26 = new java.lang.Object();
    java.lang.Object var27 = var25.push(var26);
    java.lang.Object var28 = var25.pop();
    boolean var29 = var25.empty();
    java.lang.Object var31 = var25.push((java.lang.Object)(-1.0d));
    boolean var32 = var25.empty();
    boolean var33 = var25.empty();
    br.ufal.ic.test.mystack.Stack var35 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var36 = new java.lang.Object();
    java.lang.Object var37 = var35.push(var36);
    java.lang.Object var38 = var35.peek();
    java.lang.Object var40 = var35.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var42 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var43 = var42.empty();
    java.lang.Object var45 = var42.push((java.lang.Object)(-1));
    java.lang.Object var46 = var42.peek();
    java.lang.Object var48 = var42.push((java.lang.Object)(short)(-1));
    br.ufal.ic.test.mystack.Stack var50 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var51 = new java.lang.Object();
    java.lang.Object var52 = var50.push(var51);
    java.lang.Object var53 = var50.peek();
    java.lang.Object var54 = var42.push(var53);
    java.lang.Object var55 = var42.peek();
    java.lang.Object var56 = var35.push(var55);
    java.lang.Object var57 = var35.peek();
    java.lang.Object var58 = var25.push((java.lang.Object)var35);
    java.lang.Object var59 = var1.push((java.lang.Object)var25);
    boolean var60 = var25.empty();
    java.lang.Object var61 = var25.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)0+ "'", var4.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + 0.0d+ "'", var20.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (byte)0+ "'", var21.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + (byte)0+ "'", var22.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + (-1.0d)+ "'", var31.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var40 + "' != '" + (-1)+ "'", var40.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + (-1)+ "'", var45.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + (-1)+ "'", var46.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + (short)(-1)+ "'", var48.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + (-1)+ "'", var55.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var56 + "' != '" + (-1)+ "'", var56.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var61 + "' != '" + (-1.0d)+ "'", var61.equals((-1.0d)));

  }

  public void test66() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test66");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)"hi!");
    br.ufal.ic.test.mystack.Stack var6 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var7 = new java.lang.Object();
    java.lang.Object var8 = var6.push(var7);
    java.lang.Object var9 = var6.pop();
    boolean var10 = var6.empty();
    java.lang.Object var12 = var6.push((java.lang.Object)(-1.0d));
    java.lang.Object var14 = var6.push((java.lang.Object)(-1L));
    java.lang.Object var15 = var1.push(var14);
    java.lang.Object var16 = var1.pop();
    java.lang.Object var17 = var1.peek();
    boolean var18 = var1.empty();
    java.lang.Object var19 = var1.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "hi!"+ "'", var4.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (-1.0d)+ "'", var12.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1L)+ "'", var14.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1L)+ "'", var15.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "hi!"+ "'", var16.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + (-1L)+ "'", var17.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + (-1L)+ "'", var19.equals((-1L)));

  }

  public void test67() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test67");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var8 = var1.pop();
    br.ufal.ic.test.mystack.Stack var10 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var11 = new java.lang.Object();
    java.lang.Object var12 = var10.push(var11);
    boolean var13 = var10.empty();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var16 = new java.lang.Object();
    java.lang.Object var17 = var15.push(var16);
    java.lang.Object var18 = var10.push(var16);
    java.lang.Object var19 = var1.push((java.lang.Object)var10);
    java.lang.Object var20 = var1.peek();
    boolean var21 = var1.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test68() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test68");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    br.ufal.ic.test.mystack.Stack var4 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var5 = var4.empty();
    java.lang.Object var7 = var4.push((java.lang.Object)(-1));
    java.lang.Object var8 = var1.push((java.lang.Object)(-1));
    java.lang.Object var9 = var1.peek();
    boolean var10 = var1.empty();
    br.ufal.ic.test.mystack.Stack var12 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var13 = new java.lang.Object();
    java.lang.Object var14 = var12.push(var13);
    boolean var15 = var12.empty();
    br.ufal.ic.test.mystack.Stack var17 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var18 = new java.lang.Object();
    java.lang.Object var19 = var17.push(var18);
    java.lang.Object var20 = var12.push(var18);
    java.lang.Object var21 = var12.pop();
    java.lang.Object var22 = var12.peek();
    java.lang.Object var23 = var1.push(var22);
    br.ufal.ic.test.mystack.Stack var25 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var26 = new java.lang.Object();
    java.lang.Object var27 = var25.push(var26);
    java.lang.Object var28 = var25.pop();
    boolean var29 = var25.empty();
    java.lang.Object var31 = var25.push((java.lang.Object)(-1.0d));
    java.lang.Object var32 = var25.pop();
    br.ufal.ic.test.mystack.Stack var34 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var35 = new java.lang.Object();
    java.lang.Object var36 = var34.push(var35);
    boolean var37 = var34.empty();
    br.ufal.ic.test.mystack.Stack var39 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var40 = new java.lang.Object();
    java.lang.Object var41 = var39.push(var40);
    java.lang.Object var42 = var34.push(var40);
    java.lang.Object var43 = var25.push((java.lang.Object)var34);
    java.lang.Object var44 = var34.pop();
    br.ufal.ic.test.mystack.Stack var46 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var47 = new java.lang.Object();
    java.lang.Object var48 = var46.push(var47);
    java.lang.Object var49 = var46.pop();
    java.lang.Object var50 = var34.push((java.lang.Object)var46);
    br.ufal.ic.test.mystack.Stack var52 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var53 = var52.empty();
    java.lang.Object var55 = var52.push((java.lang.Object)(-1));
    java.lang.Object var56 = var52.pop();
    br.ufal.ic.test.mystack.Stack var58 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var60 = var58.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var62 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var63 = new java.lang.Object();
    java.lang.Object var64 = var62.push(var63);
    java.lang.Object var65 = var62.peek();
    boolean var66 = var62.empty();
    java.lang.Object var67 = var62.peek();
    java.lang.Object var68 = var58.push(var67);
    java.lang.Object var69 = var52.push(var68);
    java.lang.Object var70 = var46.push(var69);
    java.lang.Object var71 = var1.push((java.lang.Object)var46);
    java.lang.Object var72 = var1.pop();
    java.lang.Object var73 = var1.peek();
    java.lang.Object var74 = var1.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1)+ "'", var7.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1)+ "'", var8.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (-1)+ "'", var9.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + (-1.0d)+ "'", var31.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + (-1.0d)+ "'", var32.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + (-1)+ "'", var55.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var56 + "' != '" + (-1)+ "'", var56.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var60 + "' != '" + 100.0d+ "'", var60.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var72 + "' != '" + (-1)+ "'", var72.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test69() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test69");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.peek();
    boolean var5 = var1.empty();
    java.lang.Object var6 = var1.peek();
    br.ufal.ic.test.mystack.Stack var8 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var9 = new java.lang.Object();
    java.lang.Object var10 = var8.push(var9);
    java.lang.Object var11 = var8.pop();
    boolean var12 = var8.empty();
    java.lang.Object var14 = var8.push((java.lang.Object)(-1.0d));
    boolean var15 = var8.empty();
    boolean var16 = var8.empty();
    br.ufal.ic.test.mystack.Stack var18 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var19 = new java.lang.Object();
    java.lang.Object var20 = var18.push(var19);
    boolean var21 = var18.empty();
    br.ufal.ic.test.mystack.Stack var23 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var24 = new java.lang.Object();
    java.lang.Object var25 = var23.push(var24);
    java.lang.Object var26 = var18.push(var24);
    java.lang.Object var27 = var8.push(var24);
    br.ufal.ic.test.mystack.Stack var29 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var30 = new java.lang.Object();
    java.lang.Object var31 = var29.push(var30);
    java.lang.Object var32 = var29.pop();
    boolean var33 = var29.empty();
    java.lang.Object var35 = var29.push((java.lang.Object)(-1.0d));
    java.lang.Object var36 = var29.pop();
    br.ufal.ic.test.mystack.Stack var38 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var39 = new java.lang.Object();
    java.lang.Object var40 = var38.push(var39);
    boolean var41 = var38.empty();
    br.ufal.ic.test.mystack.Stack var43 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var44 = new java.lang.Object();
    java.lang.Object var45 = var43.push(var44);
    java.lang.Object var46 = var38.push(var44);
    java.lang.Object var47 = var29.push((java.lang.Object)var38);
    java.lang.Object var48 = var38.pop();
    br.ufal.ic.test.mystack.Stack var50 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var51 = new java.lang.Object();
    java.lang.Object var52 = var50.push(var51);
    boolean var53 = var50.empty();
    br.ufal.ic.test.mystack.Stack var55 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var56 = new java.lang.Object();
    java.lang.Object var57 = var55.push(var56);
    java.lang.Object var58 = var50.push(var56);
    java.lang.Object var59 = var50.pop();
    br.ufal.ic.test.mystack.Stack var61 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var62 = new java.lang.Object();
    java.lang.Object var63 = var61.push(var62);
    java.lang.Object var64 = var61.peek();
    java.lang.Object var66 = var61.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var68 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var69 = new java.lang.Object();
    java.lang.Object var70 = var68.push(var69);
    java.lang.Object var71 = var68.pop();
    boolean var72 = var68.empty();
    java.lang.Object var74 = var68.push((java.lang.Object)(-1.0d));
    java.lang.Object var75 = var68.pop();
    br.ufal.ic.test.mystack.Stack var77 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var78 = new java.lang.Object();
    java.lang.Object var79 = var77.push(var78);
    boolean var80 = var77.empty();
    br.ufal.ic.test.mystack.Stack var82 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var83 = new java.lang.Object();
    java.lang.Object var84 = var82.push(var83);
    java.lang.Object var85 = var77.push(var83);
    java.lang.Object var86 = var68.push((java.lang.Object)var77);
    java.lang.Object var87 = var61.push((java.lang.Object)var77);
    boolean var88 = var77.empty();
    br.ufal.ic.test.mystack.Stack var90 = new br.ufal.ic.test.mystack.Stack(0);
    java.lang.Object var91 = var77.push((java.lang.Object)var90);
    java.lang.Object var92 = var50.push(var91);
    java.lang.Object var93 = var38.push((java.lang.Object)var50);
    java.lang.Object var94 = var8.push((java.lang.Object)var38);
    java.lang.Object var95 = var38.peek();
    java.lang.Object var96 = var1.push((java.lang.Object)var38);
    java.lang.Object var97 = var1.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1.0d)+ "'", var14.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + (-1.0d)+ "'", var35.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + (-1.0d)+ "'", var36.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var66 + "' != '" + (-1)+ "'", var66.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var74 + "' != '" + (-1.0d)+ "'", var74.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var75 + "' != '" + (-1.0d)+ "'", var75.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);

  }

  public void test70() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test70");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    boolean var4 = var1.empty();
    java.lang.Object var5 = var1.peek();
    java.lang.Object var6 = var1.peek();
    br.ufal.ic.test.mystack.Stack var8 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var9 = new java.lang.Object();
    java.lang.Object var10 = var8.push(var9);
    boolean var11 = var8.empty();
    java.lang.Object var12 = var8.peek();
    boolean var13 = var8.empty();
    java.lang.Object var14 = var1.push((java.lang.Object)var8);
    boolean var15 = var8.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test71() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test71");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var8 = var1.pop();
    br.ufal.ic.test.mystack.Stack var10 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var11 = new java.lang.Object();
    java.lang.Object var12 = var10.push(var11);
    boolean var13 = var10.empty();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var16 = new java.lang.Object();
    java.lang.Object var17 = var15.push(var16);
    java.lang.Object var18 = var10.push(var16);
    java.lang.Object var19 = var1.push((java.lang.Object)var10);
    java.lang.Object var20 = var10.pop();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var22.pop();
    java.lang.Object var26 = var10.push((java.lang.Object)var22);
    java.lang.Object var28 = var22.push((java.lang.Object)(byte)1);
    br.ufal.ic.test.mystack.Stack var30 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var32 = var30.push((java.lang.Object)(short)0);
    java.lang.Object var33 = var30.pop();
    java.lang.Object var34 = var22.push((java.lang.Object)var30);
    br.ufal.ic.test.mystack.Stack var36 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var37 = new java.lang.Object();
    java.lang.Object var38 = var36.push(var37);
    java.lang.Object var39 = var36.pop();
    boolean var40 = var36.empty();
    java.lang.Object var42 = var36.push((java.lang.Object)(-1.0d));
    java.lang.Object var43 = var36.pop();
    br.ufal.ic.test.mystack.Stack var45 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var46 = new java.lang.Object();
    java.lang.Object var47 = var45.push(var46);
    boolean var48 = var45.empty();
    br.ufal.ic.test.mystack.Stack var50 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var51 = new java.lang.Object();
    java.lang.Object var52 = var50.push(var51);
    java.lang.Object var53 = var45.push(var51);
    java.lang.Object var54 = var36.push((java.lang.Object)var45);
    boolean var55 = var45.empty();
    br.ufal.ic.test.mystack.Stack var57 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var58 = var57.empty();
    java.lang.Object var60 = var57.push((java.lang.Object)(-1));
    java.lang.Object var61 = var57.peek();
    java.lang.Object var62 = var57.peek();
    boolean var63 = var57.empty();
    java.lang.Object var64 = var57.peek();
    java.lang.Object var65 = var45.push((java.lang.Object)var57);
    boolean var66 = var45.empty();
    java.lang.Object var67 = var22.push((java.lang.Object)var66);
    java.lang.Object var68 = var22.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + (byte)1+ "'", var28.equals((byte)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + (short)0+ "'", var32.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + (short)0+ "'", var33.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + (-1.0d)+ "'", var42.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + (-1.0d)+ "'", var43.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var60 + "' != '" + (-1)+ "'", var60.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var61 + "' != '" + (-1)+ "'", var61.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var62 + "' != '" + (-1)+ "'", var62.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var64 + "' != '" + (-1)+ "'", var64.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var67 + "' != '" + false+ "'", var67.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var68 + "' != '" + (byte)1+ "'", var68.equals((byte)1));

  }

  public void test72() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test72");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var8 = var1.pop();
    br.ufal.ic.test.mystack.Stack var10 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var11 = new java.lang.Object();
    java.lang.Object var12 = var10.push(var11);
    boolean var13 = var10.empty();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var16 = new java.lang.Object();
    java.lang.Object var17 = var15.push(var16);
    java.lang.Object var18 = var10.push(var16);
    java.lang.Object var19 = var1.push((java.lang.Object)var10);
    java.lang.Object var20 = var10.pop();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var23 = var22.empty();
    java.lang.Object var25 = var22.push((java.lang.Object)(-1));
    java.lang.Object var26 = var22.pop();
    java.lang.Object var27 = var10.push(var26);
    br.ufal.ic.test.mystack.Stack var29 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var30 = var29.empty();
    java.lang.Object var32 = var29.push((java.lang.Object)"hi!");
    br.ufal.ic.test.mystack.Stack var34 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var35 = new java.lang.Object();
    java.lang.Object var36 = var34.push(var35);
    java.lang.Object var37 = var34.pop();
    boolean var38 = var34.empty();
    java.lang.Object var40 = var34.push((java.lang.Object)(-1.0d));
    java.lang.Object var42 = var34.push((java.lang.Object)(-1L));
    java.lang.Object var43 = var29.push(var42);
    java.lang.Object var44 = var29.pop();
    boolean var45 = var29.empty();
    br.ufal.ic.test.mystack.Stack var47 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var48 = var47.empty();
    java.lang.Object var50 = var47.push((java.lang.Object)(byte)0);
    br.ufal.ic.test.mystack.Stack var52 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var54 = var52.push((java.lang.Object)(short)0);
    br.ufal.ic.test.mystack.Stack var56 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var57 = new java.lang.Object();
    java.lang.Object var58 = var56.push(var57);
    java.lang.Object var59 = var56.pop();
    java.lang.Object var60 = var52.push((java.lang.Object)var56);
    java.lang.Object var61 = var47.push((java.lang.Object)var52);
    br.ufal.ic.test.mystack.Stack var63 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var64 = new java.lang.Object();
    java.lang.Object var65 = var63.push(var64);
    boolean var66 = var63.empty();
    br.ufal.ic.test.mystack.Stack var68 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var69 = new java.lang.Object();
    java.lang.Object var70 = var68.push(var69);
    java.lang.Object var71 = var63.push(var69);
    java.lang.Object var72 = var63.pop();
    java.lang.Object var73 = var63.pop();
    java.lang.Object var74 = var52.push(var73);
    java.lang.Object var75 = var29.push(var73);
    java.lang.Object var76 = var29.peek();
    java.lang.Object var77 = var10.push(var76);
    boolean var78 = var10.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + (-1)+ "'", var25.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + (-1)+ "'", var27.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "hi!"+ "'", var32.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var40 + "' != '" + (-1.0d)+ "'", var40.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + (-1L)+ "'", var42.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + (-1L)+ "'", var43.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "hi!"+ "'", var44.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var50 + "' != '" + (byte)0+ "'", var50.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + (short)0+ "'", var54.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var76 + "' != '" + (-1L)+ "'", var76.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var77 + "' != '" + (-1L)+ "'", var77.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);

  }

  public void test73() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test73");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    boolean var8 = var1.empty();
    boolean var9 = var1.empty();
    br.ufal.ic.test.mystack.Stack var11 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var12 = new java.lang.Object();
    java.lang.Object var13 = var11.push(var12);
    java.lang.Object var14 = var11.peek();
    java.lang.Object var16 = var11.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var18 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var19 = var18.empty();
    java.lang.Object var21 = var18.push((java.lang.Object)(-1));
    java.lang.Object var22 = var18.peek();
    java.lang.Object var24 = var18.push((java.lang.Object)(short)(-1));
    br.ufal.ic.test.mystack.Stack var26 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var27 = new java.lang.Object();
    java.lang.Object var28 = var26.push(var27);
    java.lang.Object var29 = var26.peek();
    java.lang.Object var30 = var18.push(var29);
    java.lang.Object var31 = var18.peek();
    java.lang.Object var32 = var11.push(var31);
    java.lang.Object var33 = var11.peek();
    java.lang.Object var34 = var1.push((java.lang.Object)var11);
    java.lang.Object var35 = var11.pop();
    java.lang.Object var36 = var11.pop();
    boolean var37 = var11.empty();
    java.lang.Object var38 = var11.pop();
    br.ufal.ic.test.mystack.Stack var40 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var42 = var40.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var44 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var45 = new java.lang.Object();
    java.lang.Object var46 = var44.push(var45);
    java.lang.Object var47 = var44.peek();
    boolean var48 = var44.empty();
    java.lang.Object var49 = var44.peek();
    java.lang.Object var50 = var40.push(var49);
    java.lang.Object var51 = var40.pop();
    java.lang.Object var52 = var40.peek();
    java.lang.Object var53 = var40.peek();
    boolean var54 = var40.empty();
    java.lang.Object var55 = var11.push((java.lang.Object)var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (-1)+ "'", var16.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (-1)+ "'", var21.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + (-1)+ "'", var22.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (short)(-1)+ "'", var24.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + (-1)+ "'", var31.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + (-1)+ "'", var32.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + (-1)+ "'", var36.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + (-1)+ "'", var38.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + 100.0d+ "'", var42.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + 100.0d+ "'", var51.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + false+ "'", var55.equals(false));

  }

  public void test74() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test74");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    boolean var4 = var1.empty();
    br.ufal.ic.test.mystack.Stack var6 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var7 = new java.lang.Object();
    java.lang.Object var8 = var6.push(var7);
    java.lang.Object var9 = var1.push(var7);
    java.lang.Object var10 = var1.pop();
    java.lang.Object var11 = var1.peek();
    br.ufal.ic.test.mystack.Stack var13 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var14 = new java.lang.Object();
    java.lang.Object var15 = var13.push(var14);
    boolean var16 = var13.empty();
    br.ufal.ic.test.mystack.Stack var18 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var19 = new java.lang.Object();
    java.lang.Object var20 = var18.push(var19);
    java.lang.Object var21 = var13.push(var19);
    boolean var22 = var13.empty();
    br.ufal.ic.test.mystack.Stack var24 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var25 = new java.lang.Object();
    java.lang.Object var26 = var24.push(var25);
    java.lang.Object var27 = var24.pop();
    boolean var28 = var24.empty();
    java.lang.Object var30 = var24.push((java.lang.Object)(-1.0d));
    boolean var31 = var24.empty();
    boolean var32 = var24.empty();
    java.lang.Object var33 = var13.push((java.lang.Object)var32);
    java.lang.Object var34 = var1.push((java.lang.Object)var13);
    java.lang.Object var35 = var13.peek();
    boolean var36 = var13.empty();
    br.ufal.ic.test.mystack.Stack var38 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var39 = new java.lang.Object();
    java.lang.Object var40 = var38.push(var39);
    java.lang.Object var41 = var38.pop();
    boolean var42 = var38.empty();
    java.lang.Object var44 = var38.push((java.lang.Object)(-1.0d));
    boolean var45 = var38.empty();
    java.lang.Object var46 = var38.pop();
    java.lang.Object var48 = var38.push((java.lang.Object)1L);
    br.ufal.ic.test.mystack.Stack var50 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var51 = new java.lang.Object();
    java.lang.Object var52 = var50.push(var51);
    java.lang.Object var53 = var50.peek();
    java.lang.Object var55 = var50.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var57 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var58 = new java.lang.Object();
    java.lang.Object var59 = var57.push(var58);
    java.lang.Object var60 = var57.pop();
    boolean var61 = var57.empty();
    java.lang.Object var63 = var57.push((java.lang.Object)(-1.0d));
    java.lang.Object var64 = var57.pop();
    br.ufal.ic.test.mystack.Stack var66 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var67 = new java.lang.Object();
    java.lang.Object var68 = var66.push(var67);
    boolean var69 = var66.empty();
    br.ufal.ic.test.mystack.Stack var71 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var72 = new java.lang.Object();
    java.lang.Object var73 = var71.push(var72);
    java.lang.Object var74 = var66.push(var72);
    java.lang.Object var75 = var57.push((java.lang.Object)var66);
    java.lang.Object var76 = var50.push((java.lang.Object)var66);
    java.lang.Object var77 = var66.pop();
    java.lang.Object var78 = var66.peek();
    boolean var79 = var66.empty();
    java.lang.Object var80 = var38.push((java.lang.Object)var66);
    java.lang.Object var81 = var13.push(var80);
    java.lang.Object var82 = var13.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + (-1.0d)+ "'", var30.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + false+ "'", var33.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + (-1.0d)+ "'", var44.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + (-1.0d)+ "'", var46.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + 1L+ "'", var48.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + (-1)+ "'", var55.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var63 + "' != '" + (-1.0d)+ "'", var63.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var64 + "' != '" + (-1.0d)+ "'", var64.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);

  }

  public void test75() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test75");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var3 = var1.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var5 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var6 = new java.lang.Object();
    java.lang.Object var7 = var5.push(var6);
    java.lang.Object var8 = var5.peek();
    boolean var9 = var5.empty();
    java.lang.Object var10 = var5.peek();
    java.lang.Object var11 = var1.push(var10);
    boolean var12 = var1.empty();
    br.ufal.ic.test.mystack.Stack var14 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var15 = new java.lang.Object();
    java.lang.Object var16 = var14.push(var15);
    java.lang.Object var17 = var1.push((java.lang.Object)var14);
    br.ufal.ic.test.mystack.Stack var19 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var20 = var19.empty();
    java.lang.Object var22 = var19.push((java.lang.Object)(-1));
    java.lang.Object var23 = var19.peek();
    java.lang.Object var24 = var19.peek();
    boolean var25 = var19.empty();
    br.ufal.ic.test.mystack.Stack var27 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var28 = var27.empty();
    java.lang.Object var30 = var27.push((java.lang.Object)"hi!");
    java.lang.Object var31 = var19.push((java.lang.Object)var27);
    java.lang.Object var32 = var1.push((java.lang.Object)var19);
    java.lang.Object var33 = var1.peek();
    java.lang.Object var34 = var1.peek();
    br.ufal.ic.test.mystack.Stack var36 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var37 = var36.empty();
    java.lang.Object var39 = var36.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var41 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var42 = new java.lang.Object();
    java.lang.Object var43 = var41.push(var42);
    java.lang.Object var44 = var41.peek();
    java.lang.Object var46 = var41.push((java.lang.Object)(-1));
    java.lang.Object var47 = var36.push((java.lang.Object)(-1));
    boolean var48 = var36.empty();
    java.lang.Object var49 = var1.push((java.lang.Object)var36);
    java.lang.Object var50 = var36.pop();
    br.ufal.ic.test.mystack.Stack var52 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var54 = var52.push((java.lang.Object)(short)0);
    boolean var55 = var52.empty();
    java.lang.Object var56 = var52.pop();
    boolean var57 = var52.empty();
    boolean var58 = var52.empty();
    java.lang.Object var59 = var36.push((java.lang.Object)var58);
    java.lang.Object var60 = var36.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 100.0d+ "'", var3.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + (-1)+ "'", var22.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + (-1)+ "'", var23.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (-1)+ "'", var24.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "hi!"+ "'", var30.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + 100.0d+ "'", var33.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + 100.0d+ "'", var34.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + (-1)+ "'", var39.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + (-1)+ "'", var46.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + (-1)+ "'", var47.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var50 + "' != '" + (-1)+ "'", var50.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + (short)0+ "'", var54.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var56 + "' != '" + (short)0+ "'", var56.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var59 + "' != '" + true+ "'", var59.equals(true));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var60 + "' != '" + (-1)+ "'", var60.equals((-1)));

  }

  public void test76() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test76");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var3 = var1.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var5 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var6 = var5.empty();
    java.lang.Object var8 = var5.push((java.lang.Object)(byte)0);
    java.lang.Object var9 = var5.pop();
    boolean var10 = var5.empty();
    java.lang.Object var11 = var1.push((java.lang.Object)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var12 = var5.peek();
      fail("Expected exception of type java.util.EmptyStackException");
    } catch (java.util.EmptyStackException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 100.0d+ "'", var3.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (byte)0+ "'", var8.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (byte)0+ "'", var9.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test77() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test77");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var8 = var1.pop();
    br.ufal.ic.test.mystack.Stack var10 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var11 = new java.lang.Object();
    java.lang.Object var12 = var10.push(var11);
    boolean var13 = var10.empty();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var16 = new java.lang.Object();
    java.lang.Object var17 = var15.push(var16);
    java.lang.Object var18 = var10.push(var16);
    java.lang.Object var19 = var1.push((java.lang.Object)var10);
    java.lang.Object var20 = var10.peek();
    java.lang.Object var21 = var10.pop();
    boolean var22 = var10.empty();
    java.lang.Object var23 = var10.pop();
    br.ufal.ic.test.mystack.Stack var25 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var26 = new java.lang.Object();
    java.lang.Object var27 = var25.push(var26);
    java.lang.Object var28 = var25.pop();
    boolean var29 = var25.empty();
    java.lang.Object var31 = var25.push((java.lang.Object)(-1.0d));
    java.lang.Object var32 = var25.pop();
    br.ufal.ic.test.mystack.Stack var34 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var35 = new java.lang.Object();
    java.lang.Object var36 = var34.push(var35);
    boolean var37 = var34.empty();
    br.ufal.ic.test.mystack.Stack var39 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var40 = new java.lang.Object();
    java.lang.Object var41 = var39.push(var40);
    java.lang.Object var42 = var34.push(var40);
    java.lang.Object var43 = var25.push((java.lang.Object)var34);
    boolean var44 = var34.empty();
    br.ufal.ic.test.mystack.Stack var46 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var47 = var46.empty();
    java.lang.Object var49 = var46.push((java.lang.Object)(-1));
    java.lang.Object var50 = var46.peek();
    java.lang.Object var51 = var46.peek();
    boolean var52 = var46.empty();
    java.lang.Object var53 = var46.peek();
    java.lang.Object var54 = var34.push((java.lang.Object)var46);
    boolean var55 = var46.empty();
    java.lang.Object var56 = var10.push((java.lang.Object)var46);
    br.ufal.ic.test.mystack.Stack var58 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var59 = new java.lang.Object();
    java.lang.Object var60 = var58.push(var59);
    java.lang.Object var61 = var58.pop();
    boolean var62 = var58.empty();
    java.lang.Object var64 = var58.push((java.lang.Object)(-1.0d));
    java.lang.Object var65 = var58.pop();
    br.ufal.ic.test.mystack.Stack var67 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var68 = new java.lang.Object();
    java.lang.Object var69 = var67.push(var68);
    boolean var70 = var67.empty();
    br.ufal.ic.test.mystack.Stack var72 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var73 = new java.lang.Object();
    java.lang.Object var74 = var72.push(var73);
    java.lang.Object var75 = var67.push(var73);
    java.lang.Object var76 = var58.push((java.lang.Object)var67);
    java.lang.Object var77 = var67.pop();
    br.ufal.ic.test.mystack.Stack var79 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var80 = new java.lang.Object();
    java.lang.Object var81 = var79.push(var80);
    java.lang.Object var82 = var79.pop();
    java.lang.Object var83 = var67.push((java.lang.Object)var79);
    java.lang.Object var84 = var67.peek();
    br.ufal.ic.test.mystack.Stack var86 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var87 = new java.lang.Object();
    java.lang.Object var88 = var86.push(var87);
    java.lang.Object var89 = var86.peek();
    boolean var90 = var86.empty();
    java.lang.Object var91 = var86.pop();
    boolean var92 = var86.empty();
    java.lang.Object var93 = var67.push((java.lang.Object)var86);
    java.lang.Object var94 = var10.push((java.lang.Object)var86);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var95 = var86.pop();
      fail("Expected exception of type java.util.EmptyStackException");
    } catch (java.util.EmptyStackException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + (-1.0d)+ "'", var31.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + (-1.0d)+ "'", var32.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + (-1)+ "'", var49.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var50 + "' != '" + (-1)+ "'", var50.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + (-1)+ "'", var51.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + (-1)+ "'", var53.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var64 + "' != '" + (-1.0d)+ "'", var64.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var65 + "' != '" + (-1.0d)+ "'", var65.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);

  }

  public void test78() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test78");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    br.ufal.ic.test.mystack.Stack var4 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var5 = var4.empty();
    java.lang.Object var7 = var4.push((java.lang.Object)(-1));
    java.lang.Object var8 = var1.push((java.lang.Object)(-1));
    java.lang.Object var9 = var1.peek();
    boolean var10 = var1.empty();
    br.ufal.ic.test.mystack.Stack var12 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var13 = new java.lang.Object();
    java.lang.Object var14 = var12.push(var13);
    boolean var15 = var12.empty();
    br.ufal.ic.test.mystack.Stack var17 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var18 = new java.lang.Object();
    java.lang.Object var19 = var17.push(var18);
    java.lang.Object var20 = var12.push(var18);
    java.lang.Object var21 = var12.pop();
    java.lang.Object var22 = var12.peek();
    java.lang.Object var23 = var1.push(var22);
    java.lang.Object var24 = var1.peek();
    boolean var25 = var1.empty();
    boolean var26 = var1.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1)+ "'", var7.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1)+ "'", var8.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (-1)+ "'", var9.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (-1)+ "'", var24.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test79() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test79");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)"hi!");
    br.ufal.ic.test.mystack.Stack var6 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var7 = new java.lang.Object();
    java.lang.Object var8 = var6.push(var7);
    java.lang.Object var9 = var6.pop();
    boolean var10 = var6.empty();
    java.lang.Object var11 = var1.push((java.lang.Object)var10);
    java.lang.Object var12 = var1.pop();
    boolean var13 = var1.empty();
    boolean var14 = var1.empty();
    java.lang.Object var15 = var1.peek();
    java.lang.Object var16 = var1.peek();
    java.lang.Object var17 = var1.pop();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var18 = var1.peek();
      fail("Expected exception of type java.util.EmptyStackException");
    } catch (java.util.EmptyStackException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "hi!"+ "'", var4.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + true+ "'", var11.equals(true));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "hi!"+ "'", var12.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + true+ "'", var15.equals(true));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + true+ "'", var16.equals(true));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + true+ "'", var17.equals(true));

  }

  public void test80() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test80");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var9 = var1.push((java.lang.Object)(-1L));
    java.lang.Object var10 = var1.pop();
    br.ufal.ic.test.mystack.Stack var12 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var13 = var12.empty();
    java.lang.Object var15 = var12.push((java.lang.Object)(-1));
    java.lang.Object var16 = var12.pop();
    boolean var17 = var12.empty();
    boolean var18 = var12.empty();
    br.ufal.ic.test.mystack.Stack var20 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var21 = var20.empty();
    java.lang.Object var22 = var12.push((java.lang.Object)var20);
    java.lang.Object var23 = var1.push((java.lang.Object)var20);
    boolean var24 = var1.empty();
    java.lang.Object var25 = var1.peek();
    br.ufal.ic.test.mystack.Stack var27 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var28 = var27.empty();
    java.lang.Object var30 = var27.push((java.lang.Object)(-1));
    java.lang.Object var31 = var27.peek();
    java.lang.Object var33 = var27.push((java.lang.Object)(short)(-1));
    br.ufal.ic.test.mystack.Stack var35 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var36 = new java.lang.Object();
    java.lang.Object var37 = var35.push(var36);
    java.lang.Object var38 = var35.pop();
    boolean var39 = var35.empty();
    java.lang.Object var41 = var35.push((java.lang.Object)(-1.0d));
    java.lang.Object var42 = var35.pop();
    br.ufal.ic.test.mystack.Stack var44 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var45 = new java.lang.Object();
    java.lang.Object var46 = var44.push(var45);
    boolean var47 = var44.empty();
    br.ufal.ic.test.mystack.Stack var49 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var50 = new java.lang.Object();
    java.lang.Object var51 = var49.push(var50);
    java.lang.Object var52 = var44.push(var50);
    java.lang.Object var53 = var35.push((java.lang.Object)var44);
    java.lang.Object var54 = var44.peek();
    java.lang.Object var55 = var44.pop();
    java.lang.Object var56 = var27.push(var55);
    java.lang.Object var57 = var1.push((java.lang.Object)var27);
    java.lang.Object var58 = var27.pop();
    boolean var59 = var27.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (-1L)+ "'", var9.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (-1.0d)+ "'", var10.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1)+ "'", var15.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (-1)+ "'", var16.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + (-1L)+ "'", var25.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + (-1)+ "'", var30.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + (-1)+ "'", var31.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + (short)(-1)+ "'", var33.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + (-1.0d)+ "'", var41.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + (-1.0d)+ "'", var42.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var58 + "' != '" + (-1)+ "'", var58.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);

  }

  public void test81() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test81");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.peek();
    java.lang.Object var6 = var1.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var8 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var9 = new java.lang.Object();
    java.lang.Object var10 = var8.push(var9);
    java.lang.Object var11 = var8.pop();
    boolean var12 = var8.empty();
    java.lang.Object var14 = var8.push((java.lang.Object)(-1.0d));
    java.lang.Object var15 = var8.pop();
    br.ufal.ic.test.mystack.Stack var17 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var18 = new java.lang.Object();
    java.lang.Object var19 = var17.push(var18);
    boolean var20 = var17.empty();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var17.push(var23);
    java.lang.Object var26 = var8.push((java.lang.Object)var17);
    java.lang.Object var27 = var1.push((java.lang.Object)var17);
    java.lang.Object var28 = var17.pop();
    java.lang.Object var29 = var17.peek();
    boolean var30 = var17.empty();
    java.lang.Object var31 = var17.pop();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var32 = var17.peek();
      fail("Expected exception of type java.util.EmptyStackException");
    } catch (java.util.EmptyStackException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1.0d)+ "'", var14.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1.0d)+ "'", var15.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test82() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test82");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(-1));
    java.lang.Object var5 = var1.peek();
    java.lang.Object var7 = var1.push((java.lang.Object)(short)(-1));
    br.ufal.ic.test.mystack.Stack var9 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var10 = new java.lang.Object();
    java.lang.Object var11 = var9.push(var10);
    java.lang.Object var12 = var9.peek();
    java.lang.Object var13 = var1.push(var12);
    java.lang.Object var14 = var1.pop();
    java.lang.Object var15 = var1.pop();
    boolean var16 = var1.empty();
    java.lang.Object var17 = var1.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1)+ "'", var4.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1)+ "'", var5.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)(-1)+ "'", var7.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (short)(-1)+ "'", var15.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test83() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test83");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.peek();
    java.lang.Object var5 = var1.pop();
    boolean var6 = var1.empty();
    br.ufal.ic.test.mystack.Stack var8 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var9 = new java.lang.Object();
    java.lang.Object var10 = var8.push(var9);
    boolean var11 = var8.empty();
    java.lang.Object var13 = var8.push((java.lang.Object)'#');
    java.lang.Object var14 = var8.pop();
    br.ufal.ic.test.mystack.Stack var16 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var17 = var16.empty();
    java.lang.Object var19 = var16.push((java.lang.Object)(-1));
    java.lang.Object var20 = var16.peek();
    java.lang.Object var21 = var16.peek();
    java.lang.Object var22 = var16.peek();
    br.ufal.ic.test.mystack.Stack var24 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var25 = new java.lang.Object();
    java.lang.Object var26 = var24.push(var25);
    java.lang.Object var27 = var24.pop();
    boolean var28 = var24.empty();
    java.lang.Object var30 = var24.push((java.lang.Object)(-1.0d));
    boolean var31 = var24.empty();
    boolean var32 = var24.empty();
    br.ufal.ic.test.mystack.Stack var34 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var35 = new java.lang.Object();
    java.lang.Object var36 = var34.push(var35);
    boolean var37 = var34.empty();
    br.ufal.ic.test.mystack.Stack var39 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var40 = new java.lang.Object();
    java.lang.Object var41 = var39.push(var40);
    java.lang.Object var42 = var34.push(var40);
    java.lang.Object var43 = var24.push(var40);
    java.lang.Object var44 = var16.push((java.lang.Object)var24);
    boolean var45 = var24.empty();
    java.lang.Object var46 = var8.push((java.lang.Object)var45);
    java.lang.Object var47 = var8.pop();
    br.ufal.ic.test.mystack.Stack var49 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var50 = new java.lang.Object();
    java.lang.Object var51 = var49.push(var50);
    boolean var52 = var49.empty();
    br.ufal.ic.test.mystack.Stack var54 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var55 = new java.lang.Object();
    java.lang.Object var56 = var54.push(var55);
    java.lang.Object var57 = var49.push(var55);
    java.lang.Object var58 = var49.pop();
    java.lang.Object var59 = var49.pop();
    boolean var60 = var49.empty();
    boolean var61 = var49.empty();
    boolean var62 = var49.empty();
    br.ufal.ic.test.mystack.Stack var64 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var66 = var64.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var68 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var69 = new java.lang.Object();
    java.lang.Object var70 = var68.push(var69);
    java.lang.Object var71 = var68.peek();
    boolean var72 = var68.empty();
    java.lang.Object var73 = var68.peek();
    java.lang.Object var74 = var64.push(var73);
    java.lang.Object var75 = var64.pop();
    java.lang.Object var76 = var64.peek();
    java.lang.Object var77 = var64.peek();
    java.lang.Object var78 = var64.peek();
    boolean var79 = var64.empty();
    java.lang.Object var80 = var64.pop();
    java.lang.Object var81 = var49.push((java.lang.Object)var64);
    java.lang.Object var82 = var8.push((java.lang.Object)var64);
    java.lang.Object var83 = var1.push(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + '#'+ "'", var13.equals('#'));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + (-1)+ "'", var19.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + (-1)+ "'", var20.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (-1)+ "'", var21.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + (-1)+ "'", var22.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + (-1.0d)+ "'", var30.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + false+ "'", var46.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + '#'+ "'", var47.equals('#'));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var66 + "' != '" + 100.0d+ "'", var66.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var75 + "' != '" + 100.0d+ "'", var75.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);

  }

  public void test84() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test84");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(byte)0);
    boolean var5 = var1.empty();
    br.ufal.ic.test.mystack.Stack var7 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var8 = new java.lang.Object();
    java.lang.Object var9 = var7.push(var8);
    boolean var10 = var7.empty();
    br.ufal.ic.test.mystack.Stack var12 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var13 = new java.lang.Object();
    java.lang.Object var14 = var12.push(var13);
    java.lang.Object var15 = var7.push(var13);
    java.lang.Object var16 = var7.pop();
    java.lang.Object var17 = var7.peek();
    java.lang.Object var18 = var1.push((java.lang.Object)var7);
    java.lang.Object var20 = var1.push((java.lang.Object)0.0d);
    java.lang.Object var21 = var1.peek();
    java.lang.Object var22 = var1.peek();
    java.lang.Object var23 = var1.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)0+ "'", var4.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + 0.0d+ "'", var20.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (byte)0+ "'", var21.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + (byte)0+ "'", var22.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + (byte)0+ "'", var23.equals((byte)0));

  }

  public void test85() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test85");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(-1));
    boolean var5 = var1.empty();
    boolean var6 = var1.empty();
    br.ufal.ic.test.mystack.Stack var8 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var9 = new java.lang.Object();
    java.lang.Object var10 = var8.push(var9);
    boolean var11 = var8.empty();
    br.ufal.ic.test.mystack.Stack var13 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var14 = new java.lang.Object();
    java.lang.Object var15 = var13.push(var14);
    java.lang.Object var16 = var8.push(var14);
    java.lang.Object var17 = var8.pop();
    java.lang.Object var18 = var1.push((java.lang.Object)var8);
    java.lang.Object var19 = var1.peek();
    boolean var20 = var1.empty();
    java.lang.Object var21 = var1.pop();
    java.lang.Object var22 = var1.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1)+ "'", var4.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + (-1)+ "'", var19.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (-1)+ "'", var21.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test86() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test86");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var3 = var1.push((java.lang.Object)(short)0);
    br.ufal.ic.test.mystack.Stack var5 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var6 = new java.lang.Object();
    java.lang.Object var7 = var5.push(var6);
    java.lang.Object var8 = var5.pop();
    java.lang.Object var9 = var1.push((java.lang.Object)var5);
    br.ufal.ic.test.mystack.Stack var11 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var12 = new java.lang.Object();
    java.lang.Object var13 = var11.push(var12);
    java.lang.Object var14 = var11.peek();
    java.lang.Object var15 = var5.push((java.lang.Object)var11);
    br.ufal.ic.test.mystack.Stack var17 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var18 = new java.lang.Object();
    java.lang.Object var19 = var17.push(var18);
    boolean var20 = var17.empty();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var17.push(var23);
    java.lang.Object var26 = var5.push(var25);
    br.ufal.ic.test.mystack.Stack var28 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var29 = var28.empty();
    java.lang.Object var31 = var28.push((java.lang.Object)"hi!");
    br.ufal.ic.test.mystack.Stack var33 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var34 = new java.lang.Object();
    java.lang.Object var35 = var33.push(var34);
    java.lang.Object var36 = var33.pop();
    boolean var37 = var33.empty();
    java.lang.Object var39 = var33.push((java.lang.Object)(-1.0d));
    java.lang.Object var41 = var33.push((java.lang.Object)(-1L));
    java.lang.Object var42 = var28.push(var41);
    java.lang.Object var43 = var28.pop();
    java.lang.Object var44 = var28.pop();
    br.ufal.ic.test.mystack.Stack var46 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var47 = new java.lang.Object();
    java.lang.Object var48 = var46.push(var47);
    java.lang.Object var49 = var46.peek();
    java.lang.Object var51 = var46.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var53 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var54 = var53.empty();
    java.lang.Object var56 = var53.push((java.lang.Object)(-1));
    java.lang.Object var57 = var53.peek();
    java.lang.Object var59 = var53.push((java.lang.Object)(short)(-1));
    br.ufal.ic.test.mystack.Stack var61 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var62 = new java.lang.Object();
    java.lang.Object var63 = var61.push(var62);
    java.lang.Object var64 = var61.peek();
    java.lang.Object var65 = var53.push(var64);
    java.lang.Object var66 = var53.peek();
    java.lang.Object var67 = var46.push(var66);
    boolean var68 = var46.empty();
    boolean var69 = var46.empty();
    java.lang.Object var70 = var46.peek();
    java.lang.Object var71 = var28.push(var70);
    java.lang.Object var72 = var28.peek();
    java.lang.Object var73 = var28.peek();
    java.lang.Object var74 = var5.push((java.lang.Object)var28);
    br.ufal.ic.test.mystack.Stack var76 = new br.ufal.ic.test.mystack.Stack(100);
    br.ufal.ic.test.mystack.Stack var78 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var80 = var78.push((java.lang.Object)(short)0);
    br.ufal.ic.test.mystack.Stack var82 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var83 = new java.lang.Object();
    java.lang.Object var84 = var82.push(var83);
    java.lang.Object var85 = var82.pop();
    java.lang.Object var86 = var78.push((java.lang.Object)var82);
    br.ufal.ic.test.mystack.Stack var88 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var89 = new java.lang.Object();
    java.lang.Object var90 = var88.push(var89);
    java.lang.Object var91 = var88.peek();
    java.lang.Object var92 = var82.push((java.lang.Object)var88);
    boolean var93 = var88.empty();
    java.lang.Object var94 = var76.push((java.lang.Object)var88);
    java.lang.Object var95 = var88.pop();
    java.lang.Object var96 = var5.push(var95);
    java.lang.Object var97 = var5.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (short)0+ "'", var3.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "hi!"+ "'", var31.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + (-1.0d)+ "'", var39.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + (-1L)+ "'", var41.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + (-1L)+ "'", var42.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "hi!"+ "'", var43.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + (-1L)+ "'", var44.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + (-1)+ "'", var51.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var56 + "' != '" + (-1)+ "'", var56.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var57 + "' != '" + (-1)+ "'", var57.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var59 + "' != '" + (short)(-1)+ "'", var59.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var66 + "' != '" + (-1)+ "'", var66.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var67 + "' != '" + (-1)+ "'", var67.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var80 + "' != '" + (short)0+ "'", var80.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);

  }

  public void test87() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test87");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var8 = var1.pop();
    br.ufal.ic.test.mystack.Stack var10 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var11 = new java.lang.Object();
    java.lang.Object var12 = var10.push(var11);
    boolean var13 = var10.empty();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var16 = new java.lang.Object();
    java.lang.Object var17 = var15.push(var16);
    java.lang.Object var18 = var10.push(var16);
    java.lang.Object var19 = var1.push((java.lang.Object)var10);
    java.lang.Object var20 = var10.pop();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var22.pop();
    java.lang.Object var26 = var10.push((java.lang.Object)var22);
    br.ufal.ic.test.mystack.Stack var28 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var29 = var28.empty();
    java.lang.Object var31 = var28.push((java.lang.Object)(-1));
    java.lang.Object var32 = var28.pop();
    br.ufal.ic.test.mystack.Stack var34 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var36 = var34.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var38 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var39 = new java.lang.Object();
    java.lang.Object var40 = var38.push(var39);
    java.lang.Object var41 = var38.peek();
    boolean var42 = var38.empty();
    java.lang.Object var43 = var38.peek();
    java.lang.Object var44 = var34.push(var43);
    java.lang.Object var45 = var28.push(var44);
    java.lang.Object var46 = var22.push(var45);
    java.lang.Object var47 = var22.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + (-1)+ "'", var31.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + (-1)+ "'", var32.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + 100.0d+ "'", var36.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test88() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test88");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(-1));
    java.lang.Object var5 = var1.peek();
    java.lang.Object var6 = var1.peek();
    boolean var7 = var1.empty();
    java.lang.Object var8 = var1.peek();
    java.lang.Object var9 = var1.peek();
    br.ufal.ic.test.mystack.Stack var11 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var12 = new java.lang.Object();
    java.lang.Object var13 = var11.push(var12);
    java.lang.Object var14 = var11.peek();
    java.lang.Object var16 = var11.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var18 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var19 = new java.lang.Object();
    java.lang.Object var20 = var18.push(var19);
    java.lang.Object var21 = var18.pop();
    boolean var22 = var18.empty();
    java.lang.Object var24 = var18.push((java.lang.Object)(-1.0d));
    java.lang.Object var25 = var18.pop();
    br.ufal.ic.test.mystack.Stack var27 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var28 = new java.lang.Object();
    java.lang.Object var29 = var27.push(var28);
    boolean var30 = var27.empty();
    br.ufal.ic.test.mystack.Stack var32 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var33 = new java.lang.Object();
    java.lang.Object var34 = var32.push(var33);
    java.lang.Object var35 = var27.push(var33);
    java.lang.Object var36 = var18.push((java.lang.Object)var27);
    java.lang.Object var37 = var11.push((java.lang.Object)var27);
    boolean var38 = var27.empty();
    br.ufal.ic.test.mystack.Stack var40 = new br.ufal.ic.test.mystack.Stack(0);
    java.lang.Object var41 = var27.push((java.lang.Object)var40);
    java.lang.Object var42 = var1.push(var41);
    boolean var43 = var1.empty();
    java.lang.Object var44 = var1.peek();
    java.lang.Object var46 = var1.push((java.lang.Object)(short)10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1)+ "'", var4.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1)+ "'", var5.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1)+ "'", var8.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (-1)+ "'", var9.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (-1)+ "'", var16.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (-1.0d)+ "'", var24.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + (-1.0d)+ "'", var25.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + (-1)+ "'", var44.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + (short)10+ "'", var46.equals((short)10));

  }

  public void test89() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test89");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(-1));
    java.lang.Object var5 = var1.peek();
    java.lang.Object var7 = var1.push((java.lang.Object)(short)(-1));
    boolean var8 = var1.empty();
    boolean var9 = var1.empty();
    boolean var10 = var1.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1)+ "'", var4.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1)+ "'", var5.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)(-1)+ "'", var7.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test90() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test90");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(-1));
    java.lang.Object var5 = var1.peek();
    java.lang.Object var7 = var1.push((java.lang.Object)(short)(-1));
    br.ufal.ic.test.mystack.Stack var9 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var10 = new java.lang.Object();
    java.lang.Object var11 = var9.push(var10);
    java.lang.Object var12 = var9.peek();
    java.lang.Object var13 = var1.push(var12);
    java.lang.Object var14 = var1.peek();
    boolean var15 = var1.empty();
    java.lang.Object var16 = var1.peek();
    java.lang.Object var17 = var1.pop();
    boolean var18 = var1.empty();
    br.ufal.ic.test.mystack.Stack var20 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var22 = var20.push((java.lang.Object)(short)0);
    br.ufal.ic.test.mystack.Stack var24 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var25 = new java.lang.Object();
    java.lang.Object var26 = var24.push(var25);
    java.lang.Object var27 = var24.pop();
    boolean var28 = var24.empty();
    java.lang.Object var30 = var24.push((java.lang.Object)(-1.0d));
    java.lang.Object var31 = var24.pop();
    br.ufal.ic.test.mystack.Stack var33 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var34 = new java.lang.Object();
    java.lang.Object var35 = var33.push(var34);
    boolean var36 = var33.empty();
    br.ufal.ic.test.mystack.Stack var38 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var39 = new java.lang.Object();
    java.lang.Object var40 = var38.push(var39);
    java.lang.Object var41 = var33.push(var39);
    java.lang.Object var42 = var24.push((java.lang.Object)var33);
    java.lang.Object var43 = var33.pop();
    br.ufal.ic.test.mystack.Stack var45 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var46 = new java.lang.Object();
    java.lang.Object var47 = var45.push(var46);
    java.lang.Object var48 = var45.pop();
    java.lang.Object var49 = var33.push((java.lang.Object)var45);
    java.lang.Object var50 = var33.peek();
    java.lang.Object var51 = var33.peek();
    java.lang.Object var52 = var20.push(var51);
    java.lang.Object var53 = var20.peek();
    java.lang.Object var54 = var1.push(var53);
    boolean var55 = var1.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1)+ "'", var4.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1)+ "'", var5.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)(-1)+ "'", var7.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1)+ "'", var14.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (-1)+ "'", var16.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + (-1)+ "'", var17.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + (short)0+ "'", var22.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + (-1.0d)+ "'", var30.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + (-1.0d)+ "'", var31.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + (short)0+ "'", var53.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + (short)0+ "'", var54.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);

  }

  public void test91() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test91");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    boolean var4 = var1.empty();
    br.ufal.ic.test.mystack.Stack var6 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var7 = new java.lang.Object();
    java.lang.Object var8 = var6.push(var7);
    java.lang.Object var9 = var1.push(var7);
    java.lang.Object var10 = var1.pop();
    java.lang.Object var11 = var1.peek();
    java.lang.Object var12 = var1.peek();
    boolean var13 = var1.empty();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var16 = var15.empty();
    java.lang.Object var18 = var15.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var20 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var21 = new java.lang.Object();
    java.lang.Object var22 = var20.push(var21);
    java.lang.Object var23 = var20.peek();
    java.lang.Object var25 = var20.push((java.lang.Object)(-1));
    java.lang.Object var26 = var15.push((java.lang.Object)(-1));
    java.lang.Object var27 = var15.peek();
    java.lang.Object var28 = var15.pop();
    java.lang.Object var29 = var15.pop();
    java.lang.Object var30 = var1.push((java.lang.Object)var15);
    br.ufal.ic.test.mystack.Stack var32 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var33 = var32.empty();
    java.lang.Object var35 = var32.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var37 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var38 = new java.lang.Object();
    java.lang.Object var39 = var37.push(var38);
    java.lang.Object var40 = var37.peek();
    java.lang.Object var42 = var37.push((java.lang.Object)(-1));
    java.lang.Object var43 = var32.push((java.lang.Object)(-1));
    java.lang.Object var44 = var32.pop();
    boolean var45 = var32.empty();
    java.lang.Object var46 = var15.push((java.lang.Object)var32);
    br.ufal.ic.test.mystack.Stack var48 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var50 = var48.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var52 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var53 = new java.lang.Object();
    java.lang.Object var54 = var52.push(var53);
    java.lang.Object var55 = var52.peek();
    boolean var56 = var52.empty();
    java.lang.Object var57 = var52.peek();
    java.lang.Object var58 = var48.push(var57);
    java.lang.Object var59 = var48.peek();
    br.ufal.ic.test.mystack.Stack var61 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var62 = new java.lang.Object();
    java.lang.Object var63 = var61.push(var62);
    java.lang.Object var64 = var61.peek();
    java.lang.Object var66 = var61.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var68 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var69 = new java.lang.Object();
    java.lang.Object var70 = var68.push(var69);
    java.lang.Object var71 = var68.pop();
    boolean var72 = var68.empty();
    java.lang.Object var74 = var68.push((java.lang.Object)(-1.0d));
    java.lang.Object var75 = var68.pop();
    br.ufal.ic.test.mystack.Stack var77 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var78 = new java.lang.Object();
    java.lang.Object var79 = var77.push(var78);
    boolean var80 = var77.empty();
    br.ufal.ic.test.mystack.Stack var82 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var83 = new java.lang.Object();
    java.lang.Object var84 = var82.push(var83);
    java.lang.Object var85 = var77.push(var83);
    java.lang.Object var86 = var68.push((java.lang.Object)var77);
    java.lang.Object var87 = var61.push((java.lang.Object)var77);
    java.lang.Object var88 = var48.push((java.lang.Object)var77);
    java.lang.Object var89 = var77.peek();
    java.lang.Object var90 = var32.push((java.lang.Object)var77);
    java.lang.Object var91 = var77.peek();
    java.lang.Object var92 = var77.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + (-1)+ "'", var18.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + (-1)+ "'", var25.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + (-1)+ "'", var27.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + (-1)+ "'", var28.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + (-1)+ "'", var29.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + (-1)+ "'", var35.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + (-1)+ "'", var42.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + (-1)+ "'", var43.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + (-1)+ "'", var44.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var50 + "' != '" + 100.0d+ "'", var50.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var59 + "' != '" + 100.0d+ "'", var59.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var66 + "' != '" + (-1)+ "'", var66.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var74 + "' != '" + (-1.0d)+ "'", var74.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var75 + "' != '" + (-1.0d)+ "'", var75.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);

  }

  public void test92() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test92");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.peek();
    boolean var5 = var1.empty();
    boolean var6 = var1.empty();
    boolean var7 = var1.empty();
    java.lang.Object var8 = var1.pop();
    boolean var9 = var1.empty();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var10 = var1.peek();
      fail("Expected exception of type java.util.EmptyStackException");
    } catch (java.util.EmptyStackException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test93() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test93");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)"hi!");
    boolean var5 = var1.empty();
    br.ufal.ic.test.mystack.Stack var7 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var8 = new java.lang.Object();
    java.lang.Object var9 = var7.push(var8);
    java.lang.Object var10 = var7.peek();
    java.lang.Object var12 = var7.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var14 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var15 = new java.lang.Object();
    java.lang.Object var16 = var14.push(var15);
    java.lang.Object var17 = var14.pop();
    boolean var18 = var14.empty();
    java.lang.Object var20 = var14.push((java.lang.Object)(-1.0d));
    java.lang.Object var21 = var14.pop();
    br.ufal.ic.test.mystack.Stack var23 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var24 = new java.lang.Object();
    java.lang.Object var25 = var23.push(var24);
    boolean var26 = var23.empty();
    br.ufal.ic.test.mystack.Stack var28 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var29 = new java.lang.Object();
    java.lang.Object var30 = var28.push(var29);
    java.lang.Object var31 = var23.push(var29);
    java.lang.Object var32 = var14.push((java.lang.Object)var23);
    java.lang.Object var33 = var7.push((java.lang.Object)var23);
    java.lang.Object var34 = var1.push(var33);
    java.lang.Object var35 = var1.peek();
    br.ufal.ic.test.mystack.Stack var37 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var38 = var37.empty();
    java.lang.Object var40 = var37.push((java.lang.Object)(byte)0);
    boolean var41 = var37.empty();
    br.ufal.ic.test.mystack.Stack var43 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var44 = new java.lang.Object();
    java.lang.Object var45 = var43.push(var44);
    boolean var46 = var43.empty();
    br.ufal.ic.test.mystack.Stack var48 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var49 = new java.lang.Object();
    java.lang.Object var50 = var48.push(var49);
    java.lang.Object var51 = var43.push(var49);
    java.lang.Object var52 = var43.pop();
    java.lang.Object var53 = var43.peek();
    java.lang.Object var54 = var37.push((java.lang.Object)var43);
    java.lang.Object var55 = var37.peek();
    br.ufal.ic.test.mystack.Stack var57 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var59 = var57.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var61 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var62 = new java.lang.Object();
    java.lang.Object var63 = var61.push(var62);
    java.lang.Object var64 = var61.peek();
    boolean var65 = var61.empty();
    java.lang.Object var66 = var61.peek();
    java.lang.Object var67 = var57.push(var66);
    boolean var68 = var57.empty();
    br.ufal.ic.test.mystack.Stack var70 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var71 = new java.lang.Object();
    java.lang.Object var72 = var70.push(var71);
    java.lang.Object var73 = var57.push((java.lang.Object)var70);
    br.ufal.ic.test.mystack.Stack var75 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var76 = var75.empty();
    java.lang.Object var78 = var75.push((java.lang.Object)(-1));
    java.lang.Object var79 = var75.peek();
    java.lang.Object var80 = var75.peek();
    boolean var81 = var75.empty();
    br.ufal.ic.test.mystack.Stack var83 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var84 = var83.empty();
    java.lang.Object var86 = var83.push((java.lang.Object)"hi!");
    java.lang.Object var87 = var75.push((java.lang.Object)var83);
    java.lang.Object var88 = var57.push((java.lang.Object)var75);
    java.lang.Object var89 = var37.push(var88);
    java.lang.Object var90 = var1.push((java.lang.Object)var37);
    java.lang.Object var91 = var1.peek();
    boolean var92 = var1.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "hi!"+ "'", var4.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (-1)+ "'", var12.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + (-1.0d)+ "'", var20.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (-1.0d)+ "'", var21.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "hi!"+ "'", var35.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var40 + "' != '" + (byte)0+ "'", var40.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + (byte)0+ "'", var55.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var59 + "' != '" + 100.0d+ "'", var59.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var78 + "' != '" + (-1)+ "'", var78.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var79 + "' != '" + (-1)+ "'", var79.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var80 + "' != '" + (-1)+ "'", var80.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var86 + "' != '" + "hi!"+ "'", var86.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var91 + "' != '" + "hi!"+ "'", var91.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == false);

  }

  public void test94() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test94");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var8 = var1.pop();
    br.ufal.ic.test.mystack.Stack var10 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var11 = new java.lang.Object();
    java.lang.Object var12 = var10.push(var11);
    boolean var13 = var10.empty();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var16 = new java.lang.Object();
    java.lang.Object var17 = var15.push(var16);
    java.lang.Object var18 = var10.push(var16);
    java.lang.Object var19 = var1.push((java.lang.Object)var10);
    java.lang.Object var20 = var10.peek();
    java.lang.Object var21 = var10.peek();
    br.ufal.ic.test.mystack.Stack var23 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var25 = var23.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var27 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var28 = new java.lang.Object();
    java.lang.Object var29 = var27.push(var28);
    java.lang.Object var30 = var27.peek();
    boolean var31 = var27.empty();
    java.lang.Object var32 = var27.peek();
    java.lang.Object var33 = var23.push(var32);
    java.lang.Object var34 = var23.pop();
    java.lang.Object var35 = var23.peek();
    java.lang.Object var36 = var10.push((java.lang.Object)var23);
    br.ufal.ic.test.mystack.Stack var38 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var39 = new java.lang.Object();
    java.lang.Object var40 = var38.push(var39);
    java.lang.Object var41 = var38.pop();
    boolean var42 = var38.empty();
    java.lang.Object var44 = var38.push((java.lang.Object)(-1.0d));
    java.lang.Object var45 = var38.pop();
    br.ufal.ic.test.mystack.Stack var47 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var48 = new java.lang.Object();
    java.lang.Object var49 = var47.push(var48);
    boolean var50 = var47.empty();
    br.ufal.ic.test.mystack.Stack var52 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var53 = new java.lang.Object();
    java.lang.Object var54 = var52.push(var53);
    java.lang.Object var55 = var47.push(var53);
    java.lang.Object var56 = var38.push((java.lang.Object)var47);
    java.lang.Object var57 = var47.pop();
    br.ufal.ic.test.mystack.Stack var59 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var60 = new java.lang.Object();
    java.lang.Object var61 = var59.push(var60);
    java.lang.Object var62 = var59.pop();
    java.lang.Object var63 = var47.push((java.lang.Object)var59);
    java.lang.Object var64 = var23.push((java.lang.Object)var59);
    boolean var65 = var23.empty();
    java.lang.Object var66 = var23.pop();
    java.lang.Object var67 = var23.pop();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var68 = var23.peek();
      fail("Expected exception of type java.util.EmptyStackException");
    } catch (java.util.EmptyStackException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + 100.0d+ "'", var25.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + 100.0d+ "'", var34.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + (-1.0d)+ "'", var44.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + (-1.0d)+ "'", var45.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test95() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test95");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var3 = var1.push((java.lang.Object)(short)0);
    java.lang.Object var4 = var1.pop();
    br.ufal.ic.test.mystack.Stack var6 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var7 = new java.lang.Object();
    java.lang.Object var8 = var6.push(var7);
    boolean var9 = var6.empty();
    br.ufal.ic.test.mystack.Stack var11 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var12 = new java.lang.Object();
    java.lang.Object var13 = var11.push(var12);
    java.lang.Object var14 = var6.push(var12);
    java.lang.Object var15 = var6.pop();
    java.lang.Object var16 = var6.peek();
    java.lang.Object var17 = var1.push((java.lang.Object)var6);
    br.ufal.ic.test.mystack.Stack var19 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var20 = new java.lang.Object();
    java.lang.Object var21 = var19.push(var20);
    java.lang.Object var22 = var19.pop();
    boolean var23 = var19.empty();
    java.lang.Object var25 = var19.push((java.lang.Object)(-1.0d));
    java.lang.Object var27 = var19.push((java.lang.Object)(-1L));
    br.ufal.ic.test.mystack.Stack var29 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var30 = new java.lang.Object();
    java.lang.Object var31 = var29.push(var30);
    java.lang.Object var32 = var29.peek();
    java.lang.Object var33 = var29.pop();
    java.lang.Object var34 = var19.push(var33);
    java.lang.Object var35 = var6.push(var33);
    boolean var36 = var6.empty();
    java.lang.Object var37 = var6.peek();
    java.lang.Object var38 = var6.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (short)0+ "'", var3.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)0+ "'", var4.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + (-1.0d)+ "'", var25.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + (-1L)+ "'", var27.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test96() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test96");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var8 = var1.pop();
    br.ufal.ic.test.mystack.Stack var10 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var11 = new java.lang.Object();
    java.lang.Object var12 = var10.push(var11);
    boolean var13 = var10.empty();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var16 = new java.lang.Object();
    java.lang.Object var17 = var15.push(var16);
    java.lang.Object var18 = var10.push(var16);
    java.lang.Object var19 = var1.push((java.lang.Object)var10);
    java.lang.Object var20 = var10.pop();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var22.pop();
    java.lang.Object var26 = var10.push((java.lang.Object)var22);
    java.lang.Object var28 = var22.push((java.lang.Object)(byte)1);
    java.lang.Object var29 = var22.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + (byte)1+ "'", var28.equals((byte)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + (byte)1+ "'", var29.equals((byte)1));

  }

  public void test97() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test97");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.peek();
    java.lang.Object var6 = var1.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var8 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var9 = var8.empty();
    java.lang.Object var11 = var8.push((java.lang.Object)(-1));
    java.lang.Object var12 = var8.peek();
    java.lang.Object var14 = var8.push((java.lang.Object)(short)(-1));
    br.ufal.ic.test.mystack.Stack var16 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var17 = new java.lang.Object();
    java.lang.Object var18 = var16.push(var17);
    java.lang.Object var19 = var16.peek();
    java.lang.Object var20 = var8.push(var19);
    java.lang.Object var21 = var8.peek();
    java.lang.Object var22 = var1.push(var21);
    boolean var23 = var1.empty();
    boolean var24 = var1.empty();
    java.lang.Object var25 = var1.pop();
    boolean var26 = var1.empty();
    boolean var27 = var1.empty();
    java.lang.Object var28 = var1.peek();
    java.lang.Object var29 = var1.peek();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1)+ "'", var6.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (-1)+ "'", var11.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + (-1)+ "'", var12.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (short)(-1)+ "'", var14.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (-1)+ "'", var21.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + (-1)+ "'", var22.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + (-1)+ "'", var28.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + (-1)+ "'", var29.equals((-1)));

  }

  public void test98() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test98");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    br.ufal.ic.test.mystack.Stack var4 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var5 = var4.empty();
    java.lang.Object var7 = var4.push((java.lang.Object)(-1));
    java.lang.Object var8 = var1.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var10 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var11 = new java.lang.Object();
    java.lang.Object var12 = var10.push(var11);
    java.lang.Object var13 = var10.peek();
    java.lang.Object var15 = var10.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var17 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var18 = new java.lang.Object();
    java.lang.Object var19 = var17.push(var18);
    java.lang.Object var20 = var17.pop();
    boolean var21 = var17.empty();
    java.lang.Object var23 = var17.push((java.lang.Object)(-1.0d));
    java.lang.Object var24 = var17.pop();
    br.ufal.ic.test.mystack.Stack var26 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var27 = new java.lang.Object();
    java.lang.Object var28 = var26.push(var27);
    boolean var29 = var26.empty();
    br.ufal.ic.test.mystack.Stack var31 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var32 = new java.lang.Object();
    java.lang.Object var33 = var31.push(var32);
    java.lang.Object var34 = var26.push(var32);
    java.lang.Object var35 = var17.push((java.lang.Object)var26);
    java.lang.Object var36 = var10.push((java.lang.Object)var26);
    java.lang.Object var37 = var26.pop();
    java.lang.Object var38 = var1.push(var37);
    java.lang.Object var39 = var1.pop();
    br.ufal.ic.test.mystack.Stack var41 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var42 = var41.empty();
    java.lang.Object var44 = var41.push((java.lang.Object)(byte)0);
    boolean var45 = var41.empty();
    br.ufal.ic.test.mystack.Stack var47 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var48 = new java.lang.Object();
    java.lang.Object var49 = var47.push(var48);
    boolean var50 = var47.empty();
    br.ufal.ic.test.mystack.Stack var52 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var53 = new java.lang.Object();
    java.lang.Object var54 = var52.push(var53);
    java.lang.Object var55 = var47.push(var53);
    java.lang.Object var56 = var47.pop();
    java.lang.Object var57 = var47.peek();
    java.lang.Object var58 = var41.push((java.lang.Object)var47);
    java.lang.Object var59 = var47.peek();
    java.lang.Object var60 = var47.peek();
    boolean var61 = var47.empty();
    java.lang.Object var62 = var47.peek();
    java.lang.Object var63 = var47.pop();
    java.lang.Object var64 = var1.push((java.lang.Object)var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1)+ "'", var7.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1)+ "'", var8.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1)+ "'", var15.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + (-1.0d)+ "'", var23.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + (-1.0d)+ "'", var24.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + (-1)+ "'", var39.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + (byte)0+ "'", var44.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test99() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test99");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    br.ufal.ic.test.mystack.Stack var3 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var5 = var3.push((java.lang.Object)(short)0);
    br.ufal.ic.test.mystack.Stack var7 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var8 = new java.lang.Object();
    java.lang.Object var9 = var7.push(var8);
    java.lang.Object var10 = var7.pop();
    java.lang.Object var11 = var3.push((java.lang.Object)var7);
    br.ufal.ic.test.mystack.Stack var13 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var14 = new java.lang.Object();
    java.lang.Object var15 = var13.push(var14);
    java.lang.Object var16 = var13.peek();
    java.lang.Object var17 = var7.push((java.lang.Object)var13);
    boolean var18 = var13.empty();
    java.lang.Object var19 = var1.push((java.lang.Object)var13);
    java.lang.Object var20 = var13.pop();
    boolean var21 = var13.empty();
    boolean var22 = var13.empty();
    br.ufal.ic.test.mystack.Stack var24 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var25 = new java.lang.Object();
    java.lang.Object var26 = var24.push(var25);
    java.lang.Object var27 = var24.pop();
    boolean var28 = var24.empty();
    java.lang.Object var30 = var24.push((java.lang.Object)(-1.0d));
    java.lang.Object var32 = var24.push((java.lang.Object)(-1L));
    java.lang.Object var33 = var24.pop();
    br.ufal.ic.test.mystack.Stack var35 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var36 = new java.lang.Object();
    java.lang.Object var37 = var35.push(var36);
    java.lang.Object var38 = var35.pop();
    boolean var39 = var35.empty();
    java.lang.Object var41 = var35.push((java.lang.Object)(-1.0d));
    java.lang.Object var42 = var35.pop();
    br.ufal.ic.test.mystack.Stack var44 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var45 = new java.lang.Object();
    java.lang.Object var46 = var44.push(var45);
    boolean var47 = var44.empty();
    br.ufal.ic.test.mystack.Stack var49 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var50 = new java.lang.Object();
    java.lang.Object var51 = var49.push(var50);
    java.lang.Object var52 = var44.push(var50);
    java.lang.Object var53 = var35.push((java.lang.Object)var44);
    java.lang.Object var54 = var44.pop();
    java.lang.Object var55 = var24.push((java.lang.Object)var44);
    boolean var56 = var44.empty();
    java.lang.Object var57 = var44.peek();
    java.lang.Object var58 = var13.push((java.lang.Object)var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)0+ "'", var5.equals((short)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + (-1.0d)+ "'", var30.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + (-1L)+ "'", var32.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + (-1.0d)+ "'", var33.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + (-1.0d)+ "'", var41.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + (-1.0d)+ "'", var42.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test100() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test100");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var8 = var1.pop();
    br.ufal.ic.test.mystack.Stack var10 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var11 = new java.lang.Object();
    java.lang.Object var12 = var10.push(var11);
    boolean var13 = var10.empty();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var16 = new java.lang.Object();
    java.lang.Object var17 = var15.push(var16);
    java.lang.Object var18 = var10.push(var16);
    java.lang.Object var19 = var1.push((java.lang.Object)var10);
    java.lang.Object var20 = var10.pop();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    java.lang.Object var25 = var22.pop();
    java.lang.Object var26 = var10.push((java.lang.Object)var22);
    java.lang.Object var27 = var10.peek();
    br.ufal.ic.test.mystack.Stack var29 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var30 = new java.lang.Object();
    java.lang.Object var31 = var29.push(var30);
    java.lang.Object var32 = var29.peek();
    boolean var33 = var29.empty();
    java.lang.Object var34 = var29.pop();
    boolean var35 = var29.empty();
    java.lang.Object var36 = var10.push((java.lang.Object)var29);
    java.lang.Object var37 = var10.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test101() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test101");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var8 = var1.pop();
    br.ufal.ic.test.mystack.Stack var10 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var11 = new java.lang.Object();
    java.lang.Object var12 = var10.push(var11);
    boolean var13 = var10.empty();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var16 = new java.lang.Object();
    java.lang.Object var17 = var15.push(var16);
    java.lang.Object var18 = var10.push(var16);
    java.lang.Object var19 = var1.push((java.lang.Object)var10);
    boolean var20 = var10.empty();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var23 = var22.empty();
    java.lang.Object var25 = var22.push((java.lang.Object)(-1));
    java.lang.Object var26 = var22.peek();
    java.lang.Object var27 = var22.peek();
    boolean var28 = var22.empty();
    java.lang.Object var29 = var22.peek();
    java.lang.Object var30 = var10.push((java.lang.Object)var22);
    java.lang.Object var31 = var10.pop();
    br.ufal.ic.test.mystack.Stack var33 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var34 = new java.lang.Object();
    java.lang.Object var35 = var33.push(var34);
    boolean var36 = var33.empty();
    br.ufal.ic.test.mystack.Stack var38 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var39 = new java.lang.Object();
    java.lang.Object var40 = var38.push(var39);
    java.lang.Object var41 = var33.push(var39);
    java.lang.Object var42 = var33.peek();
    java.lang.Object var43 = var10.push(var42);
    java.lang.Object var44 = var10.pop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + (-1)+ "'", var25.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + (-1)+ "'", var27.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + (-1)+ "'", var29.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test102() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test102");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.peek();
    boolean var5 = var1.empty();
    java.lang.Object var6 = var1.pop();
    br.ufal.ic.test.mystack.Stack var8 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var9 = new java.lang.Object();
    java.lang.Object var10 = var8.push(var9);
    java.lang.Object var11 = var8.pop();
    boolean var12 = var8.empty();
    java.lang.Object var14 = var8.push((java.lang.Object)(-1.0d));
    java.lang.Object var16 = var8.push((java.lang.Object)(-1L));
    java.lang.Object var17 = var8.pop();
    br.ufal.ic.test.mystack.Stack var19 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var20 = var19.empty();
    java.lang.Object var22 = var19.push((java.lang.Object)(-1));
    java.lang.Object var23 = var19.pop();
    boolean var24 = var19.empty();
    boolean var25 = var19.empty();
    br.ufal.ic.test.mystack.Stack var27 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var28 = var27.empty();
    java.lang.Object var29 = var19.push((java.lang.Object)var27);
    java.lang.Object var30 = var8.push((java.lang.Object)var27);
    boolean var31 = var8.empty();
    java.lang.Object var32 = var8.peek();
    java.lang.Object var33 = var8.pop();
    java.lang.Object var34 = var1.push((java.lang.Object)var8);
    java.lang.Object var35 = var1.pop();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var36 = var1.peek();
      fail("Expected exception of type java.util.EmptyStackException");
    } catch (java.util.EmptyStackException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + (-1.0d)+ "'", var14.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + (-1L)+ "'", var16.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + (-1.0d)+ "'", var17.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + (-1)+ "'", var22.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + (-1)+ "'", var23.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + (-1L)+ "'", var32.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + (-1L)+ "'", var33.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test103() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test103");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var2 = var1.empty();
    java.lang.Object var4 = var1.push((java.lang.Object)(byte)0);
    boolean var5 = var1.empty();
    br.ufal.ic.test.mystack.Stack var7 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var8 = new java.lang.Object();
    java.lang.Object var9 = var7.push(var8);
    boolean var10 = var7.empty();
    br.ufal.ic.test.mystack.Stack var12 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var13 = new java.lang.Object();
    java.lang.Object var14 = var12.push(var13);
    java.lang.Object var15 = var7.push(var13);
    java.lang.Object var16 = var7.pop();
    java.lang.Object var17 = var7.peek();
    java.lang.Object var18 = var1.push((java.lang.Object)var7);
    boolean var19 = var1.empty();
    boolean var20 = var1.empty();
    boolean var21 = var1.empty();
    br.ufal.ic.test.mystack.Stack var23 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var24 = var23.empty();
    java.lang.Object var26 = var23.push((java.lang.Object)(-1));
    java.lang.Object var27 = var23.pop();
    boolean var28 = var23.empty();
    boolean var29 = var23.empty();
    br.ufal.ic.test.mystack.Stack var31 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var32 = new java.lang.Object();
    java.lang.Object var33 = var31.push(var32);
    java.lang.Object var34 = var31.pop();
    boolean var35 = var31.empty();
    java.lang.Object var37 = var31.push((java.lang.Object)(-1.0d));
    java.lang.Object var38 = var31.pop();
    br.ufal.ic.test.mystack.Stack var40 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var41 = new java.lang.Object();
    java.lang.Object var42 = var40.push(var41);
    boolean var43 = var40.empty();
    br.ufal.ic.test.mystack.Stack var45 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var46 = new java.lang.Object();
    java.lang.Object var47 = var45.push(var46);
    java.lang.Object var48 = var40.push(var46);
    java.lang.Object var49 = var31.push((java.lang.Object)var40);
    br.ufal.ic.test.mystack.Stack var51 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var52 = var51.empty();
    java.lang.Object var54 = var51.push((java.lang.Object)(-1));
    java.lang.Object var55 = var51.pop();
    br.ufal.ic.test.mystack.Stack var57 = new br.ufal.ic.test.mystack.Stack((-1));
    java.lang.Object var59 = var57.push((java.lang.Object)100.0d);
    br.ufal.ic.test.mystack.Stack var61 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var62 = new java.lang.Object();
    java.lang.Object var63 = var61.push(var62);
    java.lang.Object var64 = var61.peek();
    boolean var65 = var61.empty();
    java.lang.Object var66 = var61.peek();
    java.lang.Object var67 = var57.push(var66);
    java.lang.Object var68 = var51.push(var67);
    java.lang.Object var69 = var40.push((java.lang.Object)var51);
    java.lang.Object var70 = var23.push(var69);
    java.lang.Object var71 = var1.push((java.lang.Object)var23);
    java.lang.Object var72 = var23.peek();
    boolean var73 = var23.empty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (byte)0+ "'", var4.equals((byte)0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + (-1)+ "'", var26.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + (-1)+ "'", var27.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + (-1.0d)+ "'", var37.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + (-1.0d)+ "'", var38.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + (-1)+ "'", var54.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + (-1)+ "'", var55.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var59 + "' != '" + 100.0d+ "'", var59.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);

  }

  public void test104() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest2.test104");


    br.ufal.ic.test.mystack.Stack var1 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var2 = new java.lang.Object();
    java.lang.Object var3 = var1.push(var2);
    java.lang.Object var4 = var1.pop();
    boolean var5 = var1.empty();
    java.lang.Object var7 = var1.push((java.lang.Object)(-1.0d));
    java.lang.Object var8 = var1.pop();
    br.ufal.ic.test.mystack.Stack var10 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var11 = new java.lang.Object();
    java.lang.Object var12 = var10.push(var11);
    boolean var13 = var10.empty();
    br.ufal.ic.test.mystack.Stack var15 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var16 = new java.lang.Object();
    java.lang.Object var17 = var15.push(var16);
    java.lang.Object var18 = var10.push(var16);
    java.lang.Object var19 = var1.push((java.lang.Object)var10);
    java.lang.Object var20 = var10.pop();
    br.ufal.ic.test.mystack.Stack var22 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var23 = new java.lang.Object();
    java.lang.Object var24 = var22.push(var23);
    boolean var25 = var22.empty();
    br.ufal.ic.test.mystack.Stack var27 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var28 = new java.lang.Object();
    java.lang.Object var29 = var27.push(var28);
    java.lang.Object var30 = var22.push(var28);
    java.lang.Object var31 = var22.pop();
    br.ufal.ic.test.mystack.Stack var33 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var34 = new java.lang.Object();
    java.lang.Object var35 = var33.push(var34);
    java.lang.Object var36 = var33.peek();
    java.lang.Object var38 = var33.push((java.lang.Object)(-1));
    br.ufal.ic.test.mystack.Stack var40 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var41 = new java.lang.Object();
    java.lang.Object var42 = var40.push(var41);
    java.lang.Object var43 = var40.pop();
    boolean var44 = var40.empty();
    java.lang.Object var46 = var40.push((java.lang.Object)(-1.0d));
    java.lang.Object var47 = var40.pop();
    br.ufal.ic.test.mystack.Stack var49 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var50 = new java.lang.Object();
    java.lang.Object var51 = var49.push(var50);
    boolean var52 = var49.empty();
    br.ufal.ic.test.mystack.Stack var54 = new br.ufal.ic.test.mystack.Stack(100);
    java.lang.Object var55 = new java.lang.Object();
    java.lang.Object var56 = var54.push(var55);
    java.lang.Object var57 = var49.push(var55);
    java.lang.Object var58 = var40.push((java.lang.Object)var49);
    java.lang.Object var59 = var33.push((java.lang.Object)var49);
    boolean var60 = var49.empty();
    br.ufal.ic.test.mystack.Stack var62 = new br.ufal.ic.test.mystack.Stack(0);
    java.lang.Object var63 = var49.push((java.lang.Object)var62);
    java.lang.Object var64 = var22.push(var63);
    java.lang.Object var65 = var10.push((java.lang.Object)var22);
    java.lang.Object var66 = var10.pop();
    boolean var67 = var10.empty();
    br.ufal.ic.test.mystack.Stack var69 = new br.ufal.ic.test.mystack.Stack((-1));
    boolean var70 = var69.empty();
    java.lang.Object var72 = var69.push((java.lang.Object)"hi!");
    java.lang.Object var73 = var69.peek();
    java.lang.Object var74 = var69.pop();
    java.lang.Object var75 = var10.push((java.lang.Object)var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1.0d)+ "'", var7.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + (-1)+ "'", var38.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + (-1.0d)+ "'", var46.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + (-1.0d)+ "'", var47.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var72 + "' != '" + "hi!"+ "'", var72.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var73 + "' != '" + "hi!"+ "'", var73.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var74 + "' != '" + "hi!"+ "'", var74.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

}
