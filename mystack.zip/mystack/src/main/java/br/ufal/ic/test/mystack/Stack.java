package br.ufal.ic.test.mystack;

import java.util.ArrayDeque;
import java.util.EmptyStackException;

public class Stack {

	private final ArrayDeque<Object> stack;
	
	public Stack(int numElements) {
		stack = new ArrayDeque<Object>(numElements);
	}
	
	public boolean empty() {
		
		return stack.isEmpty();
	}
	
	public Object push(Object o) {
		
		stack.push(o);
		return o;
	}
	
	public Object pop() {
		
		if (empty()) throw new EmptyStackException();
		
		return stack.removeLast();
	}
	
	public Object peek() {
		
		if (empty()) throw new EmptyStackException();
		
		return stack.getLast();
	}
}
